package app.morrow

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.TextDecrease
import androidx.compose.material.icons.rounded.TextIncrease
import androidx.compose.material.icons.rounded.WrapText
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

private fun displayNameOf(ctx: Context, uri: Uri, fallback: String): String {
    try {
        ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val n = c.getString(0)
                if (!n.isNullOrBlank()) return n
            }
        }
    } catch (_: Exception) {
    }
    return fallback
}

/** Copies a document picked by the user into the app and returns the new file id. */
private fun importDocument(ctx: Context, uri: Uri): Long? {
    return try {
        val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return null
        if (bytes.size > 2_000_000) {
            ctx.toast("Файл больше 2 МБ — он слишком велик для редактора")
            return null
        }
        val name = displayNameOf(ctx, uri, "imported.txt")
        val f = Repo.newCode(name, languageForName(name), String(bytes, Charsets.UTF_8))
        f.id
    } catch (e: Exception) {
        ctx.toast("Не удалось открыть файл")
        null
    }
}

@Composable
fun CodeScreen() {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    var showNew by remember { mutableStateOf(false) }
    val opener = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val id = importDocument(ctx, uri)
            if (id != null) Nav.route = Route.CodeEdit(id)
        }
    }
    val files = Repo.codeFiles.sortedByDescending { it.modified }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            ScreenHeader(
                "Code",
                "Карманный редактор · подсветка, поиск, автосохранение",
                trailing = {
                    IconButton(onClick = { opener.launch(arrayOf("*/*")) }) {
                        Icon(Icons.Rounded.FolderOpen, "Открыть файл", tint = cs.primary)
                    }
                }
            )
            if (files.isEmpty()) {
                Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.TopCenter) {
                    Hint("Файлов пока нет. Создайте новый или откройте файл с телефона.")
                }
            } else {
                LazyColumn(
                    Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 96.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(files, key = { it.id }) { f ->
                        MCard(onClick = { Nav.route = Route.CodeEdit(f.id) }, padding = 14.dp) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Rounded.Description, null, tint = cs.primary)
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(
                                        f.name,
                                        style = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.Medium, fontFamily = FontFamily.Monospace),
                                        color = cs.onSurface,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Hint(languageTitle(f.language) + " · " + fmtStamp(f.modified))
                                }
                            }
                        }
                    }
                }
            }
        }
        ExtendedFloatingActionButton(
            onClick = { showNew = true },
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(16.dp),
            containerColor = cs.primary,
            contentColor = cs.onPrimary,
            icon = { Icon(Icons.Rounded.Add, null) },
            text = { Text("Файл") }
        )
    }

    if (showNew) {
        NewFileDialog(
            onDismiss = { showNew = false },
            onCreate = { name, lang ->
                showNew = false
                val f = Repo.newCode(name, lang, "")
                Nav.route = Route.CodeEdit(f.id)
            }
        )
    }
}

@Composable
private fun NewFileDialog(onDismiss: () -> Unit, onCreate: (String, String) -> Unit) {
    var name by remember { mutableStateOf("main.kt") }
    var lang by remember { mutableStateOf("kotlin") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Новый файл") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = {
                        name = it
                        val ext = it.substringAfterLast('.', "")
                        if (ext.isNotEmpty()) lang = languageForName(it)
                    },
                    label = { Text("Имя файла") },
                    singleLine = true
                )
                ChipRow(Languages.map { it.title }, Languages.indexOfFirst { it.id == lang }) { i ->
                    val l = Languages[i]
                    lang = l.id
                    val base = if (name.contains('.')) name.substringBeforeLast('.') else name
                    name = base + "." + l.ext[0]
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = { onCreate(name.trim(), lang) },
                enabled = name.isNotBlank()
            ) { Text("Создать") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )
}

// =====================================================================================
//  Editor
// =====================================================================================

@Composable
fun CodeEditor(id: Long, onClose: () -> Unit) {
    val file = Repo.codeFiles.firstOrNull { it.id == id }
    if (file == null) {
        LaunchedEffect(Unit) { onClose() }
        return
    }
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val extras = LocalExtras.current
    val scope = rememberCoroutineScope()

    val tfvState = remember(id) { mutableStateOf(TextFieldValue(Repo.readCode(id))) }
    val lastSaved = remember(id) { mutableStateOf(tfvState.value.text) }
    var showFind by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var matchIdx by remember { mutableIntStateOf(-1) }
    var layout by remember { mutableStateOf<TextLayoutResult?>(null) }
    var showMenu by remember { mutableStateOf(false) }
    var showLang by remember { mutableStateOf(false) }
    var showRename by remember { mutableStateOf(false) }
    var showDelete by remember { mutableStateOf(false) }
    val vScroll = rememberScrollState()
    val hScroll = rememberScrollState()

    val exporter = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null) {
            try {
                ctx.contentResolver.openOutputStream(uri)?.use { it.write(tfvState.value.text.toByteArray(Charsets.UTF_8)) }
                ctx.toast("Файл сохранён")
            } catch (_: Exception) {
                ctx.toast("Не удалось сохранить файл")
            }
        }
    }

    fun saveNow() {
        val t = tfvState.value.text
        if (t != lastSaved.value) {
            Repo.writeCode(id, t)
            lastSaved.value = t
        }
    }

    LaunchedEffect(tfvState.value.text) {
        delay(800)
        saveNow()
    }
    DisposableEffect(id) {
        onDispose {
            saveNow()
            Repo.saveNow()
        }
    }

    val text = tfvState.value.text
    val wrap = Prefs.codeWrap
    val fontSize = Prefs.codeFontSize
    val lineHeight = fontSize * 1.45f
    val effectiveQuery = if (showFind) query else ""
    val matches = remember(text, effectiveQuery) { findAllIndices(text, effectiveQuery) }
    val matchBg = cs.primary.copy(alpha = 0.30f)
    val transformation = remember(file.language, extras.dark, Prefs.redOne, extras.red, effectiveQuery, matchBg) {
        CodeTransformation(file.language, extras.code, Prefs.redOne, extras.red, effectiveQuery, matchBg)
    }
    val style = TextStyle(
        fontFamily = FontFamily.Monospace,
        fontSize = fontSize.sp,
        lineHeight = lineHeight.sp,
        color = cs.onSurface
    )
    val gutterStyle = TextStyle(
        fontFamily = FontFamily.Monospace,
        fontSize = fontSize.sp,
        lineHeight = lineHeight.sp,
        color = cs.onSurfaceVariant.copy(alpha = 0.7f),
        textAlign = TextAlign.End
    )
    val lineCount = text.count { it == '\n' } + 1
    val gutterWidth = (lineCount.toString().length * fontSize * 0.62f + 16f).dp

    fun goTo(i: Int) {
        if (matches.isEmpty()) return
        val idx = ((i % matches.size) + matches.size) % matches.size
        matchIdx = idx
        val s = matches[idx]
        tfvState.value = tfvState.value.copy(selection = TextRange(s, s + effectiveQuery.length))
        val l = layout
        if (l != null) {
            val len = l.layoutInput.text.length
            val line = l.getLineForOffset(s.coerceAtMost(len))
            val y = l.getLineTop(line)
            scope.launch { vScroll.animateScrollTo((y - 160f).toInt().coerceAtLeast(0)) }
        }
    }

    EditorFrame {
        TopBarRow(file.name, onClose) {
            IconButton(onClick = { showFind = !showFind }) {
                Icon(Icons.Rounded.Search, "Поиск", tint = if (showFind) cs.primary else cs.onBackground)
            }
            IconButton(onClick = {
                saveNow()
                Repo.saveNow()
                ctx.toast("Сохранено")
            }) { Icon(Icons.Rounded.Save, "Сохранить", tint = cs.onBackground) }
            Box {
                IconButton(onClick = { showMenu = true }) { Icon(Icons.Rounded.MoreVert, "Меню", tint = cs.onBackground) }
                DropdownMenu(expanded = showMenu, onDismissRequest = { showMenu = false }) {
                    DropdownMenuItem(text = { Text("Переименовать") }, onClick = { showMenu = false; showRename = true })
                    DropdownMenuItem(text = { Text("Сохранить на телефон…") }, onClick = {
                        showMenu = false
                        saveNow()
                        exporter.launch(file.name)
                    })
                    DropdownMenuItem(text = { Text("Удалить файл") }, onClick = { showMenu = false; showDelete = true })
                }
            }
        }
        Row(
            Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Box {
                AssistChip(onClick = { showLang = true }, label = { Text(languageTitle(file.language)) })
                DropdownMenu(expanded = showLang, onDismissRequest = { showLang = false }) {
                    for (l in Languages) {
                        DropdownMenuItem(
                            text = { Text(l.title) },
                            onClick = {
                                showLang = false
                                Repo.updateCode(id) { it.copy(language = l.id) }
                            }
                        )
                    }
                }
            }
            IconButton(onClick = { Prefs.setCodeFontSize(fontSize - 1) }) { Icon(Icons.Rounded.TextDecrease, "Меньше") }
            Text("$fontSize", color = cs.onSurfaceVariant, style = TextStyle(fontSize = 13.sp))
            IconButton(onClick = { Prefs.setCodeFontSize(fontSize + 1) }) { Icon(Icons.Rounded.TextIncrease, "Больше") }
            FilterChip(
                selected = wrap,
                onClick = { Prefs.setCodeWrap(!wrap) },
                label = { Text("Перенос") },
                leadingIcon = { Icon(Icons.Rounded.WrapText, null, Modifier.size(18.dp)) }
            )
            AssistChip(onClick = {
                val v = tfvState.value
                val s = v.selection.min
                val e = v.selection.max
                val nt = v.text.substring(0, s) + "    " + v.text.substring(e)
                tfvState.value = v.copy(text = nt, selection = TextRange(s + 4))
            }, label = { Text("Tab") })
            Hint("$lineCount стр. · ${text.length} симв.")
        }
        if (showFind) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = query,
                    onValueChange = {
                        query = it
                        matchIdx = -1
                    },
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    placeholder = { Text("Найти") }
                )
                Text(
                    if (effectiveQuery.isEmpty()) "" else if (matches.isEmpty()) "0" else "${matchIdx + 1}/${matches.size}",
                    modifier = Modifier.padding(horizontal = 6.dp),
                    color = cs.onSurfaceVariant
                )
                IconButton(onClick = { goTo(if (matchIdx < 0) 0 else matchIdx - 1) }) { Icon(Icons.Rounded.KeyboardArrowUp, "Предыдущее") }
                IconButton(onClick = { goTo(matchIdx + 1) }) { Icon(Icons.Rounded.KeyboardArrowDown, "Следующее") }
                IconButton(onClick = { showFind = false }) { Icon(Icons.Rounded.Close, "Закрыть") }
            }
        }
        HorizontalDivider()
        BoxWithConstraints(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .background(cs.surface)
        ) {
            val viewportH = maxHeight
            val viewportW = maxWidth
            Row(Modifier.verticalScroll(vScroll)) {
                // line numbers
                if (!wrap) {
                    Text(
                        (1..lineCount).joinToString("\n"),
                        modifier = Modifier
                            .width(gutterWidth)
                            .padding(end = 6.dp),
                        style = gutterStyle
                    )
                } else {
                    Box(Modifier.width(gutterWidth)) {
                        val l = layout
                        if (l != null) {
                            val len = l.layoutInput.text.length
                            var n = 0
                            var start = 0
                            while (n < 4000) {
                                val top = l.getLineTop(l.getLineForOffset(start.coerceAtMost(len)))
                                Text(
                                    (n + 1).toString(),
                                    modifier = Modifier
                                        .offset { IntOffset(0, top.roundToInt()) }
                                        .width(gutterWidth)
                                        .padding(end = 6.dp),
                                    style = gutterStyle
                                )
                                val nl = text.indexOf('\n', start)
                                if (nl < 0) break
                                start = nl + 1
                                n++
                            }
                        }
                    }
                }
                Box(
                    Modifier
                        .weight(1f)
                        .then(if (wrap) Modifier else Modifier.horizontalScroll(hScroll))
                ) {
                    BasicTextField(
                        value = tfvState.value,
                        onValueChange = { tfvState.value = it },
                        modifier = Modifier
                            .heightIn(min = viewportH)
                            .then(if (wrap) Modifier.fillMaxWidth() else Modifier.widthIn(min = viewportW - gutterWidth)),
                        textStyle = style,
                        cursorBrush = SolidColor(cs.primary),
                        visualTransformation = transformation,
                        onTextLayout = { layout = it },
                        keyboardOptions = KeyboardOptions(
                            capitalization = KeyboardCapitalization.None,
                            autoCorrect = false
                        )
                    )
                }
            }
        }
    }

    if (showRename) {
        var newName by remember { mutableStateOf(file.name) }
        AlertDialog(
            onDismissRequest = { showRename = false },
            title = { Text("Переименовать") },
            text = {
                OutlinedTextField(value = newName, onValueChange = { newName = it }, singleLine = true)
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        val n = newName.trim()
                        if (n.isNotEmpty()) {
                            val recognized = languageForName(n)
                            Repo.updateCode(id) {
                                it.copy(name = n, language = if (recognized != "text") recognized else it.language)
                            }
                        }
                        showRename = false
                    },
                    enabled = newName.isNotBlank()
                ) { Text("OK") }
            },
            dismissButton = { TextButton(onClick = { showRename = false }) { Text("Отмена") } }
        )
    }
    if (showDelete) {
        ConfirmDialog(
            title = "Удалить файл?",
            text = "Файл «" + file.name + "» будет удалён без возможности восстановления.",
            confirmLabel = "Удалить",
            onConfirm = {
                showDelete = false
                lastSaved.value = tfvState.value.text
                Repo.deleteCode(id)
                onClose()
            },
            onDismiss = { showDelete = false }
        )
    }
}
