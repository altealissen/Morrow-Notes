package app.morrow

import android.content.Context
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.mutableStateListOf
import org.json.JSONObject
import java.io.File
import java.time.LocalDate
import java.util.concurrent.Executors

/**
 * Single source of truth for user data. Everything is kept in Compose-observable lists and
 * written to filesDir/data.json atomically (tmp file + rename, previous copy kept as .bak).
 * Code files keep their text in separate files so that big sources do not slow down saves.
 */
object Repo {
    private var ctx: Context? = null
    private val io = Executors.newSingleThreadExecutor()
    private val handler = Handler(Looper.getMainLooper())
    private var lastId = 0L

    val events = mutableStateListOf<Event>()
    val notes = mutableStateListOf<Note>()
    val categories = mutableStateListOf<Category>()
    val alarms = mutableStateListOf<AlarmItem>()
    val codeFiles = mutableStateListOf<CodeFile>()

    private const val DAY = 24L * 60L * 60L * 1000L

    @Synchronized
    fun init(context: Context) {
        if (ctx != null) return
        ctx = context.applicationContext
        load()
        snapshotIfNeeded()
    }

    @Synchronized
    fun newId(): Long {
        val now = System.currentTimeMillis()
        lastId = if (now > lastId) now else lastId + 1
        return lastId
    }

    private fun dataFile(): File = File(ctx!!.filesDir, "data.json")
    private fun codeDir(): File = File(ctx!!.filesDir, "code").also { it.mkdirs() }
    private fun snapDir(): File = File(ctx!!.filesDir, "backups").also { it.mkdirs() }

    // ---------------------------------------------------------------- loading

    private fun load() {
        val main = dataFile()
        val bak = File(main.path + ".bak")
        var loaded = false
        for (f in listOf(main, bak)) {
            if (loaded || !f.exists()) continue
            try {
                applyJson(JSONObject(f.readText()), replace = true)
                loaded = true
            } catch (_: Exception) {
            }
        }
        if (!loaded) {
            seedDefaults()
            migrateFromV02()
            writeNow()
        }
        // notes stay in the trash for 30 days
        val limit = System.currentTimeMillis() - 30 * DAY
        val expired = notes.filter { it.trashedAt in 1..limit }
        if (expired.isNotEmpty()) {
            notes.removeAll(expired.toSet())
            saveLater()
        }
        for (e in events) lastId = maxOf(lastId, e.id)
        for (n in notes) lastId = maxOf(lastId, n.id)
        for (a in alarms) lastId = maxOf(lastId, a.id)
        for (c in codeFiles) lastId = maxOf(lastId, c.id)
        for (c in categories) lastId = maxOf(lastId, c.id)
    }

    private fun seedDefaults() {
        val names = listOf("Личное", "Работа", "Учёба", "Идеи", "Проекты", "Другое")
        names.forEachIndexed { i, n -> categories.add(Category(newId(), n, Swatches[i % Swatches.size])) }
    }

    private fun migrateFromV02() {
        try {
            val now = System.currentTimeMillis()
            val cat = categories.first().id
            val note = Prefs.legacyNote
            val plan = Prefs.legacyPlan
            val code = Prefs.legacyCode
            if (note.isNotBlank()) {
                notes.add(Note(newId(), "Заметка из Morrow 0.2", note, cat, now, now))
            }
            if (plan.isNotBlank()) {
                notes.add(Note(newId(), "План из Morrow 0.2", plan, cat, now, now))
            }
            if (code.isNotBlank() && !code.startsWith("// Morrow")) {
                newCode("morrow-0.2.kt", "kotlin", code)
            }
            val prefs = ctx!!.getSharedPreferences("morrow_settings", Context.MODE_PRIVATE)
            if (prefs.getBoolean("alarm_enabled", false)) {
                val parts = (prefs.getString("alarm_time", "07:30") ?: "07:30").split(":")
                val h = parts.getOrNull(0)?.toIntOrNull() ?: 7
                val m = parts.getOrNull(1)?.toIntOrNull() ?: 30
                val sound = prefs.getString("alarm_sound", null) ?: ""
                alarms.add(
                    AlarmItem(
                        newId(), h.coerceIn(0, 23), m.coerceIn(0, 59),
                        prefs.getString("alarm_label", "") ?: "", 127, true, sound,
                        if (sound.isEmpty()) "" else "Свой звук"
                    )
                )
            }
            Prefs.clearLegacy()
        } catch (_: Exception) {
        }
    }

    // ------------------------------------------------------------- persistence

    private val saveRunnable = Runnable { writeNow() }

    fun saveLater() {
        handler.removeCallbacks(saveRunnable)
        handler.postDelayed(saveRunnable, 400)
    }

    fun saveNow() {
        handler.removeCallbacks(saveRunnable)
        writeNow()
    }

    private fun writeNow() {
        if (ctx == null) return
        val text = toJson(all = false).toString()
        val target = dataFile()
        io.execute { atomicWrite(target, text) }
    }

    private fun atomicWrite(target: File, text: String) {
        try {
            val tmp = File(target.path + ".tmp")
            tmp.writeText(text)
            if (target.exists()) {
                try {
                    target.copyTo(File(target.path + ".bak"), overwrite = true)
                } catch (_: Exception) {
                }
            }
            if (!tmp.renameTo(target)) {
                target.writeText(text)
                tmp.delete()
            }
        } catch (_: Exception) {
        }
    }

    /** Serialises the data. With [all] = true code contents and settings are included (backup). */
    fun toJson(all: Boolean, sections: Set<String> = emptySet()): JSONObject {
        fun want(s: String) = sections.isEmpty() || s in sections
        val o = JSONObject()
        o.put("type", "morrow-backup")
        o.put("version", 1)
        o.put("exportedAt", System.currentTimeMillis())
        if (want("events")) o.put("events", events.toList().toJsonArray { it.toJson() })
        if (want("notes")) {
            o.put("notes", notes.toList().toJsonArray { it.toJson() })
            o.put("categories", categories.toList().toJsonArray { it.toJson() })
        }
        if (want("alarms")) o.put("alarms", alarms.toList().toJsonArray { it.toJson() })
        if (want("code")) {
            if (all) {
                o.put("code", codeFiles.toList().toJsonArray { f ->
                    f.toJson().put("content", readCode(f.id))
                })
            } else {
                o.put("code", codeFiles.toList().toJsonArray { it.toJson() })
            }
        }
        if (all && want("settings")) o.put("settings", Prefs.toJson())
        return o
    }

    /** Replaces the sections that are present in [o]. */
    private fun applyJson(o: JSONObject, replace: Boolean) {
        val ev = o.optJSONArray("events")
        if (ev != null) {
            val list = ev.objects().map { eventFromJson(it) }
            if (replace) events.clear()
            events.addAll(list)
        }
        val cats = o.optJSONArray("categories")
        if (cats != null) {
            val list = cats.objects().map { categoryFromJson(it) }
            if (replace) categories.clear()
            categories.addAll(list)
        }
        val nts = o.optJSONArray("notes")
        if (nts != null) {
            val list = nts.objects().map { noteFromJson(it) }
            if (replace) notes.clear()
            notes.addAll(list)
        }
        val als = o.optJSONArray("alarms")
        if (als != null) {
            val list = als.objects().map { alarmFromJson(it) }
            if (replace) alarms.clear()
            alarms.addAll(list)
        }
        val code = o.optJSONArray("code")
        if (code != null) {
            val objs = code.objects()
            if (replace) codeFiles.clear()
            for (c in objs) {
                val f = codeFromJson(c)
                codeFiles.add(f)
                if (c.has("content")) {
                    try {
                        codeFileOf(f.id).writeText(c.optString("content", ""))
                    } catch (_: Exception) {
                    }
                }
            }
        }
        if (categories.isEmpty()) seedDefaults()
    }

    /** Restores a backup file. Returns a short human readable summary. */
    fun restore(o: JSONObject): String {
        if (o.optString("type") != "morrow-backup") throw IllegalArgumentException("not a Morrow file")
        applyJson(o, replace = true)
        val st = o.optJSONObject("settings")
        if (st != null) Prefs.restore(st)
        for (e in events) lastId = maxOf(lastId, e.id)
        for (n in notes) lastId = maxOf(lastId, n.id)
        for (a in alarms) lastId = maxOf(lastId, a.id)
        for (c in codeFiles) lastId = maxOf(lastId, c.id)
        for (c in categories) lastId = maxOf(lastId, c.id)
        saveNow()
        ctx?.let { Scheduler.rescheduleAll(it) }
        return "События: ${events.size}, заметки: ${notes.size}, будильники: ${alarms.size}, файлы: ${codeFiles.size}"
    }

    // ------------------------------------------------------------- snapshots

    private fun snapshotIfNeeded() {
        if (ctx == null) return
        val name = "morrow-${LocalDate.now()}.json"
        val dir = snapDir()
        val target = File(dir, name)
        if (target.exists()) return
        val text = try {
            toJson(all = true).toString()
        } catch (_: Exception) {
            return
        }
        io.execute {
            try {
                target.writeText(text)
                val all = dir.listFiles { f -> f.name.startsWith("morrow-") && f.name.endsWith(".json") }
                    ?.sortedByDescending { it.name } ?: emptyList()
                for (old in all.drop(7)) old.delete()
            } catch (_: Exception) {
            }
        }
    }

    fun snapshots(): List<File> =
        snapDir().listFiles { f -> f.name.startsWith("morrow-") && f.name.endsWith(".json") }
            ?.sortedByDescending { it.name } ?: emptyList()

    // ------------------------------------------------------------- events

    fun eventById(id: Long): Event? = events.firstOrNull { it.id == id }

    fun upsertEvent(e: Event) {
        val i = events.indexOfFirst { it.id == e.id }
        if (i >= 0) events[i] = e else events.add(e)
        saveLater()
    }

    fun deleteEvent(id: Long) {
        events.removeAll { it.id == id }
        saveLater()
    }

    fun eventsOn(epochDay: Long): List<Event> =
        events.filter { it.epochDay == epochDay }.sortedBy { it.startMin }

    // ------------------------------------------------------------- notes

    fun noteById(id: Long): Note? = notes.firstOrNull { it.id == id }

    fun newNote(categoryId: Long = 0L, body: String = ""): Note {
        val now = System.currentTimeMillis()
        val cat = if (categories.any { it.id == categoryId }) categoryId else categories.firstOrNull()?.id ?: 0L
        val n = Note(newId(), "", body, cat, now, now)
        notes.add(n)
        saveLater()
        return n
    }

    fun updateNote(id: Long, f: (Note) -> Note) {
        val i = notes.indexOfFirst { it.id == id }
        if (i < 0) return
        val old = notes[i]
        val updated = f(old)
        if (updated == old) return
        notes[i] = updated
        saveLater()
    }

    fun trashNote(id: Long) = updateNote(id) { it.copy(trashedAt = System.currentTimeMillis(), pinned = false) }
    fun restoreNote(id: Long) = updateNote(id) { it.copy(trashedAt = 0L) }

    fun deleteNoteForever(id: Long) {
        notes.removeAll { it.id == id }
        saveLater()
    }

    fun emptyTrash() {
        notes.removeAll { it.trashedAt > 0L }
        saveLater()
    }

    fun categoryById(id: Long): Category? = categories.firstOrNull { it.id == id }

    fun addCategory(name: String, color: Int) {
        categories.add(Category(newId(), name.trim(), color))
        saveLater()
    }

    fun updateCategory(id: Long, f: (Category) -> Category) {
        val i = categories.indexOfFirst { it.id == id }
        if (i < 0) return
        categories[i] = f(categories[i])
        saveLater()
    }

    fun deleteCategory(id: Long) {
        if (categories.size <= 1) return
        categories.removeAll { it.id == id }
        val fallback = categories.first().id
        for (i in notes.indices) {
            if (notes[i].categoryId == id) notes[i] = notes[i].copy(categoryId = fallback)
        }
        saveLater()
    }

    // ------------------------------------------------------------- alarms

    fun upsertAlarm(a: AlarmItem) {
        val i = alarms.indexOfFirst { it.id == a.id }
        if (i >= 0) alarms[i] = a else alarms.add(a)
        saveNow()
    }

    fun deleteAlarm(id: Long) {
        alarms.removeAll { it.id == id }
        saveNow()
    }

    // ------------------------------------------------------------- code files

    private fun codeFileOf(id: Long): File = File(codeDir(), "$id.txt")

    fun newCode(name: String, language: String, content: String = ""): CodeFile {
        val f = CodeFile(newId(), name, language, System.currentTimeMillis())
        codeFiles.add(f)
        try {
            codeFileOf(f.id).writeText(content)
        } catch (_: Exception) {
        }
        saveNow()
        return f
    }

    fun readCode(id: Long): String = try {
        val f = codeFileOf(id)
        if (f.exists()) f.readText() else ""
    } catch (_: Exception) {
        ""
    }

    fun writeCode(id: Long, text: String) {
        try {
            val target = codeFileOf(id)
            val tmp = File(target.path + ".tmp")
            tmp.writeText(text)
            if (!tmp.renameTo(target)) {
                target.writeText(text)
                tmp.delete()
            }
        } catch (_: Exception) {
        }
        val i = codeFiles.indexOfFirst { it.id == id }
        if (i >= 0) {
            codeFiles[i] = codeFiles[i].copy(modified = System.currentTimeMillis())
            saveLater()
        }
    }

    fun updateCode(id: Long, f: (CodeFile) -> CodeFile) {
        val i = codeFiles.indexOfFirst { it.id == id }
        if (i < 0) return
        codeFiles[i] = f(codeFiles[i])
        saveLater()
    }

    fun deleteCode(id: Long) {
        codeFiles.removeAll { it.id == id }
        try {
            codeFileOf(id).delete()
        } catch (_: Exception) {
        }
        saveNow()
    }
}
