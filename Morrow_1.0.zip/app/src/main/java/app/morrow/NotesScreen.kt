package app.morrow

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.ClickableText
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Checklist
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.DeleteForever
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.FormatBold
import androidx.compose.material.icons.rounded.FormatItalic
import androidx.compose.material.icons.rounded.FormatListBulleted
import androidx.compose.material.icons.rounded.FormatUnderlined
import androidx.compose.material.icons.rounded.Label
import androidx.compose.material.icons.rounded.Link
import androidx.compose.material.icons.rounded.PushPin
import androidx.compose.material.icons.rounded.Restore
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Sort
import androidx.compose.material.icons.rounded.Title
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

/** Colors only the digit 1 of [s]. */
fun redDigits(s: String, red: Boolean, color: Color): AnnotatedString {
    val b = AnnotatedString.Builder(s)
    if (red) {
        for (i in s.indices) {
            if (s[i] == '1') b.addStyle(SpanStyle(color = color), i, i + 1)
        }
    }
    return b.toAnnotatedString()
}

@Composable
fun MarkupText(text: String, style: TextStyle, modifier: Modifier = Modifier) {
    val extras = LocalExtras.current
    val link = MaterialTheme.colorScheme.primary
    val uri = LocalUriHandler.current
    val red = Prefs.redOne
    val annotated = remember(text, red, extras.red, link) { renderInline(text, red, extras.red, link) }
    ClickableText(
        text = annotated,
        style = style,
        modifier = modifier,
        onClick = { off ->
            val a = annotated.getStringAnnotations("URL", off, off).firstOrNull()
            if (a != null) {
                try {
                    uri.openUri(a.item)
                } catch (_: Exception) {
                }
            }
        }
    )
}

// =====================================================================================
//  Notes list
// =====================================================================================

@Composable
fun NotesScreen() {
    val cs = MaterialTheme.colorScheme
    val filter = UiState.notesFilter
    val trash = filter == -1L
    val query = UiState.notesQuery
    var showCats by remember { mutableStateOf(false) }
    var showSort by remember { mutableStateOf(false) }
    var confirmEmpty by remember { mutableStateOf(false) }

    val base = Repo.notes.filter { if (trash) it.trashedAt > 0L else it.trashedAt == 0L }
    val byCat = if (filter > 0L) base.filter { it.categoryId == filter } else base
    val searched = if (query.isBlank()) byCat else byCat.filter {
        it.title.contains(query, ignoreCase = true) || it.body.contains(query, ignoreCase = true)
    }
    val sorted = when (UiState.notesSort) {
        1 -> searched.sortedByDescending { it.created }
        2 -> searched.sortedBy { it.title.lowercase() }
        else -> searched.sortedByDescending { it.modified }
    }
    val list = if (trash) sorted else sorted.sortedByDescending { it.pinned }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            ScreenHeader(
                "Notes",
                if (trash) "Корзина · хранится 30 дней" else "${base.size} " + noteWord(base.size),
                trailing = {
                    Box {
                        IconButton(onClick = { showSort = true }) { Icon(Icons.Rounded.Sort, "Сортировка") }
                        DropdownMenu(expanded = showSort, onDismissRequest = { showSort = false }) {
                            val labels = listOf("Сначала изменённые", "Сначала новые", "По названию")
                            labels.forEachIndexed { i, l ->
                                DropdownMenuItem(
                                    text = { Text(if (UiState.notesSort == i) "✓ $l" else l) },
                                    onClick = {
                                        UiState.notesSort = i
                                        showSort = false
                                    }
                                )
                            }
                        }
                    }
                    IconButton(onClick = { showCats = true }) { Icon(Icons.Rounded.Label, "Категории") }
                }
            )
            OutlinedTextField(
                value = query,
                onValueChange = { UiState.notesQuery = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                singleLine = true,
                placeholder = { Text("Поиск по заметкам") },
                leadingIcon = { Icon(Icons.Rounded.Search, null) },
                trailingIcon = {
                    if (query.isNotEmpty()) {
                        IconButton(onClick = { UiState.notesQuery = "" }) { Icon(Icons.Rounded.Close, "Очистить") }
                    }
                }
            )
            Spacer(Modifier.height(8.dp))
            Row(
                Modifier
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = filter == 0L,
                    onClick = { UiState.notesFilter = 0L },
                    label = { Text("Все") }
                )
                for (c in Repo.categories) {
                    FilterChip(
                        selected = filter == c.id,
                        onClick = { UiState.notesFilter = c.id },
                        label = { Text(c.name) },
                        leadingIcon = { ColorDot(c.color, 10.dp) }
                    )
                }
                FilterChip(
                    selected = trash,
                    onClick = { UiState.notesFilter = -1L },
                    label = { Text("Корзина") },
                    leadingIcon = { Icon(Icons.Rounded.Delete, null, Modifier.size(16.dp)) }
                )
            }
            if (trash && list.isNotEmpty()) {
                TextButton(
                    onClick = { confirmEmpty = true },
                    modifier = Modifier.padding(horizontal = 8.dp)
                ) { Text("Очистить корзину") }
            }
            Spacer(Modifier.height(8.dp))
            if (list.isEmpty()) {
                Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.TopCenter) {
                    Hint(
                        when {
                            trash -> "Корзина пуста."
                            query.isNotBlank() -> "Ничего не найдено."
                            else -> "Пока нет заметок. Нажмите «Заметка», чтобы начать."
                        }
                    )
                }
            } else {
                LazyColumn(
                    Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 96.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(list, key = { it.id }) { n ->
                        NoteCard(n, trash)
                    }
                }
            }
        }
        if (!trash) {
            ExtendedFloatingActionButton(
                onClick = {
                    val cat = if (filter > 0L) filter else 0L
                    val n = Repo.newNote(cat)
                    Nav.route = Route.NoteEdit(n.id)
                },
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(16.dp),
                containerColor = cs.primary,
                contentColor = cs.onPrimary,
                icon = { Icon(Icons.Rounded.Add, null) },
                text = { Text("Заметка") }
            )
        }
    }

    if (showCats) CategoriesDialog { showCats = false }
    if (confirmEmpty) {
        ConfirmDialog(
            title = "Очистить корзину?",
            text = "Заметки в корзине будут удалены навсегда.",
            confirmLabel = "Удалить",
            onConfirm = {
                Repo.emptyTrash()
                confirmEmpty = false
            },
            onDismiss = { confirmEmpty = false }
        )
    }
}

private fun noteWord(n: Int): String {
    val m10 = n % 10
    val m100 = n % 100
    return when {
        m100 in 11..14 -> "заметок"
        m10 == 1 -> "заметка"
        m10 in 2..4 -> "заметки"
        else -> "заметок"
    }
}

@Composable
private fun NoteCard(n: Note, trash: Boolean) {
    val cs = MaterialTheme.colorScheme
    val extras = LocalExtras.current
    val cat = Repo.categoryById(n.categoryId)
    val red = Prefs.redOne
    val titleText = n.title.ifBlank { "Без названия" }
    val preview = previewText(n.body, 3)
    val previewAnnotated = remember(preview, red, extras.red, cs.primary) {
        renderInline(preview, red, extras.red, cs.primary)
    }
    MCard(
        onClick = if (trash) null else ({ Nav.route = Route.NoteEdit(n.id) }),
        padding = 14.dp
    ) {
        Row(verticalAlignment = Alignment.Top) {
            Column(Modifier.weight(1f)) {
                Text(
                    redDigits(titleText, red, extras.red),
                    style = TextStyle(fontSize = 17.sp, fontWeight = FontWeight.Medium),
                    color = if (n.title.isBlank()) cs.onSurfaceVariant else cs.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                if (preview.isNotBlank()) {
                    Spacer(Modifier.height(4.dp))
                    Text(
                        previewAnnotated,
                        style = TextStyle(fontSize = 14.sp, lineHeight = 20.sp),
                        color = cs.onSurfaceVariant,
                        maxLines = 3,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (cat != null) {
                        ColorDot(cat.color, 9.dp)
                        Spacer(Modifier.width(6.dp))
                        Text(cat.name, style = TextStyle(fontSize = 12.sp), color = cs.onSurfaceVariant)
                        Spacer(Modifier.width(10.dp))
                    }
                    Text(fmtStamp(n.modified), style = TextStyle(fontSize = 12.sp), color = cs.onSurfaceVariant)
                }
            }
            if (n.pinned && !trash) {
                Icon(Icons.Rounded.PushPin, "Закреплено", tint = cs.primary, modifier = Modifier.size(20.dp))
            }
        }
        if (trash) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                TextButton(onClick = { Repo.restoreNote(n.id) }) {
                    Icon(Icons.Rounded.Restore, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Восстановить")
                }
                TextButton(onClick = { Repo.deleteNoteForever(n.id) }) {
                    Icon(Icons.Rounded.DeleteForever, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Удалить")
                }
            }
        }
    }
}

@Composable
private fun CategoriesDialog(onDismiss: () -> Unit) {
    var newName by remember { mutableStateOf("") }
    var newColor by remember { mutableIntStateOf(Swatches[0]) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Категории") },
        text = {
            Column(
                Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                for (c in Repo.categories.toList()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier
                                .size(32.dp)
                                .background(Color(c.color), RoundedCornerShape(16.dp))
                                .clickable {
                                    val idx = Swatches.indexOf(c.color)
                                    val next = Swatches[(idx + 1) % Swatches.size]
                                    Repo.updateCategory(c.id) { it.copy(color = next) }
                                }
                        )
                        Spacer(Modifier.width(8.dp))
                        OutlinedTextField(
                            value = c.name,
                            onValueChange = { v -> Repo.updateCategory(c.id) { it.copy(name = v) } },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(
                            onClick = { Repo.deleteCategory(c.id) },
                            enabled = Repo.categories.size > 1
                        ) { Icon(Icons.Rounded.Delete, "Удалить") }
                    }
                }
                Hint("Нажмите на цветной кружок, чтобы сменить цвет.")
                HorizontalDivider()
                SmallLabel("Новая категория")
                OutlinedTextField(
                    value = newName,
                    onValueChange = { newName = it },
                    singleLine = true,
                    placeholder = { Text("Название") },
                    modifier = Modifier.fillMaxWidth()
                )
                SwatchPicker(newColor, { newColor = it })
                TextButton(
                    onClick = {
                        if (newName.isNotBlank()) {
                            Repo.addCategory(newName, newColor)
                            newName = ""
                        }
                    },
                    enabled = newName.isNotBlank()
                ) { Text("Добавить") }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Готово") } }
    )
}

// =====================================================================================
//  Note editor
// =====================================================================================

private fun commitNote(id: Long, title: String, body: String) {
    Repo.updateNote(id) {
        if (it.title == title && it.body == body) it
        else it.copy(title = title, body = body, modified = System.currentTimeMillis())
    }
}

@Composable
fun NoteEditor(id: Long, onClose: () -> Unit) {
    val note = Repo.noteById(id)
    if (note == null) {
        LaunchedEffect(Unit) { onClose() }
        return
    }
    val cs = MaterialTheme.colorScheme
    val extras = LocalExtras.current
    val titleState = remember(id) { mutableStateOf(note.title) }
    val bodyState = remember(id) { mutableStateOf(TextFieldValue(note.body)) }
    var preview by remember { mutableStateOf(false) }
    var showDelete by remember { mutableStateOf(false) }

    LaunchedEffect(titleState.value, bodyState.value.text) {
        delay(500)
        commitNote(id, titleState.value, bodyState.value.text)
    }
    DisposableEffect(id) {
        onDispose {
            val t = titleState.value
            val b = bodyState.value.text
            if (t.isBlank() && b.isBlank()) {
                Repo.deleteNoteForever(id)
            } else {
                commitNote(id, t, b)
            }
            Repo.saveNow()
        }
    }

    val transformation = remember(Prefs.redOne, extras.red, cs.onSurfaceVariant, cs.primary) {
        NoteTransformation(
            Prefs.redOne, extras.red,
            cs.onSurfaceVariant.copy(alpha = 0.65f), cs.primary, cs.primary
        )
    }
    val bodyStyle = TextStyle(fontSize = 16.sp, lineHeight = 24.sp, color = cs.onSurface)

    EditorFrame {
        TopBarRow("", onClose) {
            IconButton(onClick = { Repo.updateNote(id) { it.copy(pinned = !it.pinned) } }) {
                Icon(
                    Icons.Rounded.PushPin, "Закрепить",
                    tint = if (note.pinned) cs.primary else cs.onSurfaceVariant
                )
            }
            IconButton(onClick = { preview = !preview }) {
                Icon(
                    if (preview) Icons.Rounded.Edit else Icons.Rounded.Visibility,
                    if (preview) "Редактировать" else "Просмотр",
                    tint = cs.onBackground
                )
            }
            IconButton(onClick = { showDelete = true }) { Icon(Icons.Rounded.Delete, "В корзину", tint = cs.onBackground) }
        }
        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
        ) {
            if (preview) {
                MarkupText(
                    titleState.value.ifBlank { "Без названия" },
                    TextStyle(fontSize = 26.sp, fontWeight = FontWeight.Medium, color = cs.onSurface)
                )
            } else {
                Box {
                    if (titleState.value.isEmpty()) {
                        Text("Название", style = TextStyle(fontSize = 26.sp, fontWeight = FontWeight.Medium), color = cs.onSurfaceVariant)
                    }
                    BasicTextField(
                        value = titleState.value,
                        onValueChange = { titleState.value = it.replace("\n", " ") },
                        modifier = Modifier.fillMaxWidth(),
                        textStyle = TextStyle(fontSize = 26.sp, fontWeight = FontWeight.Medium, color = cs.onSurface),
                        cursorBrush = SolidColor(cs.primary),
                        visualTransformation = remember(Prefs.redOne, extras.red) {
                            RedOneTransformation(Prefs.redOne, extras.red)
                        }
                    )
                }
            }
            Spacer(Modifier.height(6.dp))
            Hint("Изменено: " + fmtStamp(note.modified))
            Spacer(Modifier.height(10.dp))
            Row(
                Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                for (c in Repo.categories) {
                    FilterChip(
                        selected = note.categoryId == c.id,
                        onClick = { Repo.updateNote(id) { it.copy(categoryId = c.id) } },
                        label = { Text(c.name) },
                        leadingIcon = { ColorDot(c.color, 10.dp) }
                    )
                }
            }
            Spacer(Modifier.height(14.dp))
            if (preview) {
                NotePreview(bodyState.value.text) { newText ->
                    bodyState.value = TextFieldValue(newText)
                }
            } else {
                Box(Modifier.fillMaxWidth().heightIn(min = 320.dp)) {
                    if (bodyState.value.text.isEmpty()) {
                        Text("Начните писать…", style = bodyStyle, color = cs.onSurfaceVariant)
                    }
                    BasicTextField(
                        value = bodyState.value,
                        onValueChange = { bodyState.value = it },
                        modifier = Modifier.fillMaxWidth(),
                        textStyle = bodyStyle,
                        cursorBrush = SolidColor(cs.primary),
                        visualTransformation = transformation
                    )
                }
            }
            Spacer(Modifier.height(32.dp))
        }
        if (!preview) {
            HorizontalDivider()
            Row(
                Modifier
                    .fillMaxWidth()
                    .background(cs.surface)
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                FormatButton(Icons.Rounded.FormatBold, "Жирный") { bodyState.value = bodyState.value.wrapSelection("**") }
                FormatButton(Icons.Rounded.FormatItalic, "Курсив") { bodyState.value = bodyState.value.wrapSelection("*") }
                FormatButton(Icons.Rounded.FormatUnderlined, "Подчёркнутый") { bodyState.value = bodyState.value.wrapSelection("__") }
                FormatButton(Icons.Rounded.Title, "Заголовок") { bodyState.value = bodyState.value.cycleHeading() }
                FormatButton(Icons.Rounded.FormatListBulleted, "Список") { bodyState.value = bodyState.value.toggleLinePrefix("- ") }
                FormatButton(Icons.Rounded.Checklist, "Чек-лист") { bodyState.value = bodyState.value.toggleLinePrefix("- [ ] ") }
                FormatButton(Icons.Rounded.Link, "Ссылка") { bodyState.value = bodyState.value.insertLink() }
            }
        }
    }

    if (showDelete) {
        ConfirmDialog(
            title = "Переместить в корзину?",
            text = "Заметку можно будет восстановить в течение 30 дней.",
            confirmLabel = "В корзину",
            onConfirm = {
                showDelete = false
                commitNote(id, titleState.value, bodyState.value.text)
                Repo.trashNote(id)
                onClose()
            },
            onDismiss = { showDelete = false }
        )
    }
}

@Composable
private fun FormatButton(icon: androidx.compose.ui.graphics.vector.ImageVector, desc: String, onClick: () -> Unit) {
    IconButton(onClick = onClick) {
        Icon(icon, desc, tint = MaterialTheme.colorScheme.onSurface)
    }
}

@Composable
private fun NotePreview(body: String, onChange: (String) -> Unit) {
    val cs = MaterialTheme.colorScheme
    val blocks = remember(body) { parseBlocks(body) }
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        for (b in blocks) {
            when (b) {
                is Block.Heading -> MarkupText(
                    b.text,
                    TextStyle(
                        fontSize = if (b.level == 1) 24.sp else 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = cs.onSurface
                    )
                )
                is Block.Bullet -> Row {
                    Text("•", style = TextStyle(fontSize = 16.sp), color = cs.primary, modifier = Modifier.padding(end = 10.dp, start = 4.dp))
                    MarkupText(b.text, TextStyle(fontSize = 16.sp, lineHeight = 24.sp, color = cs.onSurface))
                }
                is Block.Check -> Row(verticalAlignment = Alignment.Top) {
                    Checkbox(
                        checked = b.checked,
                        onCheckedChange = { onChange(toggleCheckLine(body, b.line)) },
                        modifier = Modifier.size(32.dp)
                    )
                    MarkupText(
                        b.text,
                        TextStyle(
                            fontSize = 16.sp,
                            lineHeight = 24.sp,
                            color = if (b.checked) cs.onSurfaceVariant else cs.onSurface,
                            textDecoration = if (b.checked) TextDecoration.LineThrough else TextDecoration.None
                        ),
                        Modifier.padding(top = 4.dp, start = 4.dp)
                    )
                }
                is Block.Para -> MarkupText(b.text, TextStyle(fontSize = 16.sp, lineHeight = 24.sp, color = cs.onSurface))
                is Block.Blank -> Spacer(Modifier.height(8.dp))
            }
        }
    }
}
