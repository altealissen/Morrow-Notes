package app.morrow

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.time.Instant
import java.time.ZoneId
import kotlin.math.sin

/** Header with a calm Pacific Northwest scene: pine silhouettes and drifting fog. */
@Composable
fun FogHeader(modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    val cs = MaterialTheme.colorScheme
    val transition = rememberInfiniteTransition(label = "fog")
    val drift = transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(16000, easing = LinearEasing), RepeatMode.Reverse),
        label = "drift"
    )
    val skyTop = mix(cs.primary, cs.surface, 0.82f)
    val skyBottom = mix(cs.primary, cs.surface, 0.94f)
    val treeBack = mix(cs.primary, cs.surface, 0.62f)
    val treeFront = mix(cs.primary, cs.onSurface, 0.42f)
    val fog = cs.surface.copy(alpha = 0.55f)
    Box(
        modifier
            .fillMaxWidth()
            .height(156.dp)
            .clip(RoundedCornerShape(28.dp))
            .background(Brush.verticalGradient(listOf(skyTop, skyBottom)))
    ) {
        Canvas(Modifier.matchParentSize()) {
            val w = size.width
            val h = size.height

            fun tree(cx: Float, baseY: Float, th: Float, color: Color) {
                for (k in 0..2) {
                    val apex = baseY - th + k * 0.27f * th
                    val bottom = apex + 0.46f * th
                    val half = th * 0.14f + k * th * 0.07f
                    val p = Path()
                    p.moveTo(cx, apex)
                    p.lineTo(cx + half, bottom)
                    p.lineTo(cx - half, bottom)
                    p.close()
                    drawPath(p, color)
                }
            }

            for (i in 0 until 9) {
                val x = w * (i + 0.5f) / 9f
                val th = h * (0.46f + 0.12f * sin(i * 2.1f))
                tree(x, h * 0.94f, th, treeBack)
            }
            val d = drift.value
            drawRect(
                brush = Brush.horizontalGradient(listOf(Color.Transparent, fog, Color.Transparent)),
                topLeft = Offset(-w * 0.4f + w * 0.5f * d, h * 0.48f),
                size = Size(w * 1.1f, h * 0.2f)
            )
            for (i in 0 until 6) {
                val x = w * (i + 0.25f) / 6f
                val th = h * (0.6f + 0.15f * sin(i * 1.3f + 1f))
                tree(x, h * 1.04f, th, treeFront)
            }
            drawRect(
                brush = Brush.horizontalGradient(listOf(Color.Transparent, fog, Color.Transparent)),
                topLeft = Offset(w * 0.3f - w * 0.5f * d, h * 0.72f),
                size = Size(w * 1.0f, h * 0.18f)
            )
        }
        content()
    }
}

private fun zoned(ms: Long) = Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault())

@Composable
fun TodayScreen() {
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(30_000L)
            now = System.currentTimeMillis()
        }
    }
    var editing by remember { mutableStateOf(false) }
    val today = zoned(now).toLocalDate()
    val todayDay = today.toEpochDay()
    val hour = zoned(now).hour
    val order = Prefs.orderedBlocks()
    val hidden = Prefs.hiddenBlocks()
    val extras = LocalExtras.current

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        FogHeader {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(start = 20.dp, end = 8.dp, top = 12.dp),
                verticalAlignment = Alignment.Top
            ) {
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.Bottom) {
                        Text(
                            "morrow",
                            style = TextStyle(fontSize = 30.sp, fontWeight = FontWeight.Light),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        if (Prefs.redOne) {
                            Text(
                                "1",
                                modifier = Modifier.padding(start = 4.dp, bottom = 2.dp),
                                style = TextStyle(fontSize = 22.sp, fontWeight = FontWeight.Bold),
                                color = extras.red
                            )
                        }
                    }
                    Text(
                        fmtLongDate(today),
                        style = TextStyle(fontSize = 13.sp),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                IconButton(onClick = { editing = !editing }) {
                    Icon(Icons.Rounded.Tune, "Настроить экран", tint = MaterialTheme.colorScheme.onSurface)
                }
                IconButton(onClick = { Nav.route = Route.SettingsScreen }) {
                    Icon(Icons.Rounded.Settings, "Настройки", tint = MaterialTheme.colorScheme.onSurface)
                }
            }
        }

        if (editing) {
            Hint("Меняйте порядок блоков и скрывайте ненужные.", Modifier.padding(horizontal = 8.dp))
        }

        for ((index, id) in order.withIndex()) {
            val isHidden = id in hidden
            if (isHidden && !editing) continue
            BlockFrame(
                id = id,
                editing = editing,
                hidden = isHidden,
                canUp = index > 0,
                canDown = index < order.size - 1,
                onUp = {
                    val l = order.toMutableList()
                    val t = l[index]; l[index] = l[index - 1]; l[index - 1] = t
                    Prefs.setTodayOrder(l.joinToString(","))
                },
                onDown = {
                    val l = order.toMutableList()
                    val t = l[index]; l[index] = l[index + 1]; l[index + 1] = t
                    Prefs.setTodayOrder(l.joinToString(","))
                },
                onToggleHidden = {
                    val set = hidden.toMutableSet()
                    if (isHidden) set.remove(id) else set.add(id)
                    Prefs.setTodayHidden(set.joinToString(","))
                }
            ) {
                when (id) {
                    "greeting" -> GreetingBlock(hour, todayDay)
                    "next" -> NextEventBlock(now, todayDay)
                    "plan" -> PlanBlock(todayDay)
                    "reminders" -> RemindersBlock(now, todayDay)
                    "alarm" -> AlarmBlock()
                    "notes" -> NotesBlock()
                    "stats" -> StatsBlock(todayDay)
                }
            }
        }
        if (editing) {
            TextButton(onClick = { Prefs.resetToday() }) { Text("Сбросить порядок и показать все блоки") }
        }
        Spacer(Modifier.height(12.dp))
    }
}

private fun blockTitle(id: String): String = when (id) {
    "greeting" -> "Приветствие"
    "next" -> "Ближайшее событие"
    "plan" -> "Планы на сегодня"
    "reminders" -> "Напоминания"
    "alarm" -> "Будильник"
    "notes" -> "Заметки"
    "stats" -> "Выполнено"
    else -> id
}

@Composable
private fun BlockFrame(
    id: String,
    editing: Boolean,
    hidden: Boolean,
    canUp: Boolean,
    canDown: Boolean,
    onUp: () -> Unit,
    onDown: () -> Unit,
    onToggleHidden: () -> Unit,
    content: @Composable () -> Unit
) {
    MCard(Modifier.alpha(if (hidden) 0.5f else 1f)) {
        if (editing) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                SmallLabel(blockTitle(id), Modifier.weight(1f))
                IconButton(onClick = onUp, enabled = canUp) { Icon(Icons.Rounded.KeyboardArrowUp, "Выше") }
                IconButton(onClick = onDown, enabled = canDown) { Icon(Icons.Rounded.KeyboardArrowDown, "Ниже") }
                IconButton(onClick = onToggleHidden) {
                    Icon(if (hidden) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility, "Показать или скрыть")
                }
            }
        } else if (id != "greeting") {
            SmallLabel(blockTitle(id))
            Spacer(Modifier.height(8.dp))
        }
        content()
    }
}

@Composable
private fun GreetingBlock(hour: Int, todayDay: Long) {
    val events = Repo.eventsOn(todayDay)
    val left = events.count { !it.done }
    Text(
        greetingFor(hour),
        style = TextStyle(fontSize = 26.sp, fontWeight = FontWeight.Light),
        color = MaterialTheme.colorScheme.onSurface
    )
    Spacer(Modifier.height(4.dp))
    Hint(
        when {
            events.isEmpty() -> "На сегодня ничего не запланировано. Можно просто выдохнуть."
            left == 0 -> "Всё на сегодня сделано. Тихий вечер заслужен."
            else -> "Осталось дел на сегодня: $left"
        }
    )
}

@Composable
private fun NextEventBlock(now: Long, todayDay: Long) {
    val next = Repo.events.filter { !it.done && it.endMillis() >= now }.minByOrNull { it.startMillis() }
    if (next == null) {
        Hint("Впереди ничего нет.")
        return
    }
    Row(
        Modifier.clickable { Nav.route = Route.EventEdit(next.id, next.epochDay) },
        verticalAlignment = Alignment.CenterVertically
    ) {
        ColorDot(next.color, 14.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                next.title.ifBlank { "Без названия" },
                style = TextStyle(fontSize = 18.sp, fontWeight = FontWeight.Medium),
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            val start = next.startMillis()
            Hint(
                dateLabel(next.epochDay, todayDay) + ", " + fmtTime(next.startMin) + " · " +
                    if (start <= now) "идёт сейчас" else relativeIn(start - now)
            )
        }
    }
}

@Composable
private fun PlanBlock(todayDay: Long) {
    val events = Repo.eventsOn(todayDay)
    if (events.isEmpty()) {
        Hint("Свободный день.")
    }
    for (e in events) {
        EventRow(e, showDate = false)
    }
    TextButton(onClick = { Nav.route = Route.EventEdit(0L, todayDay) }) {
        Icon(Icons.Rounded.Add, null)
        Spacer(Modifier.width(6.dp))
        Text("Добавить событие")
    }
}

@Composable
private fun RemindersBlock(now: Long, todayDay: Long) {
    val limit = now + 48L * 60L * 60L * 1000L
    val list = Repo.events
        .filter { it.remindMin >= 0 && !it.done && it.startMillis() >= now && it.startMillis() <= limit }
        .sortedBy { it.startMillis() }
        .take(4)
    if (list.isEmpty()) {
        Hint("Активных напоминаний нет.")
        return
    }
    for (e in list) {
        val z = zoned(e.triggerMillis())
        Row(
            Modifier
                .fillMaxWidth()
                .clickable { Nav.route = Route.EventEdit(e.id, e.epochDay) }
                .padding(vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            ColorDot(e.color, 10.dp)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    e.title.ifBlank { "Без названия" },
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Hint(
                    remindLabel(e.remindMin) + " · напомню " +
                        dateLabel(z.toLocalDate().toEpochDay(), todayDay).lowercase() + " в " +
                        pad2(z.hour) + ":" + pad2(z.minute)
                )
            }
        }
    }
}

@Composable
private fun AlarmBlock() {
    val next = Scheduler.nextAlarm()
    Row(
        Modifier
            .fillMaxWidth()
            .clickable { Nav.tab = "Alarm" },
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (next == null) {
            Hint("Будильники выключены.")
        } else {
            val a = next.first
            Text(
                pad2(a.hour) + ":" + pad2(a.minute),
                style = TextStyle(fontSize = 34.sp, fontWeight = FontWeight.Light),
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(Modifier.width(14.dp))
            Column {
                Text(
                    a.label.ifBlank { "Будильник" },
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Hint(relativeIn(next.second - System.currentTimeMillis()))
            }
        }
    }
}

@Composable
private fun NotesBlock() {
    val extras = LocalExtras.current
    val scheme = MaterialTheme.colorScheme
    var quick by remember { mutableStateOf(TextFieldValue("")) }
    val transformation = remember(Prefs.redOne, extras.red, scheme.onSurfaceVariant, scheme.primary) {
        NoteTransformation(Prefs.redOne, extras.red, scheme.onSurfaceVariant.copy(alpha = 0.7f), scheme.primary, scheme.primary)
    }
    OutlinedTextField(
        value = quick,
        onValueChange = { quick = it },
        modifier = Modifier.fillMaxWidth(),
        placeholder = { Text("Поймать мысль…") },
        visualTransformation = transformation,
        minLines = 1,
        maxLines = 4
    )
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
        TextButton(
            onClick = {
                val text = quick.text.trim()
                if (text.isNotEmpty()) {
                    val n = Repo.newNote()
                    Repo.updateNote(n.id) { it.copy(body = text, modified = System.currentTimeMillis()) }
                    quick = TextFieldValue("")
                }
            },
            enabled = quick.text.isNotBlank()
        ) { Text("Сохранить заметкой") }
    }
    val recent = Repo.notes.filter { it.trashedAt == 0L }.sortedByDescending { it.modified }.take(3)
    for (n in recent) {
        Column(
            Modifier
                .fillMaxWidth()
                .clickable { Nav.route = Route.NoteEdit(n.id) }
                .padding(vertical = 6.dp)
        ) {
            Text(
                n.title.ifBlank { previewText(n.body, 1).ifBlank { "Пустая заметка" } },
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
    TextButton(onClick = { Nav.tab = "Notes" }) { Text("Все заметки") }
}

@Composable
private fun StatsBlock(todayDay: Long) {
    val events = Repo.eventsOn(todayDay)
    val done = events.count { it.done }
    val total = events.size
    Text(
        if (total == 0) "Задач на сегодня нет" else "$done из $total",
        style = TextStyle(fontSize = 22.sp, fontWeight = FontWeight.Light),
        color = MaterialTheme.colorScheme.onSurface
    )
    Spacer(Modifier.height(8.dp))
    LinearProgressIndicator(
        progress = { if (total == 0) 0f else done.toFloat() / total.toFloat() },
        modifier = Modifier
            .fillMaxWidth()
            .height(8.dp)
            .clip(RoundedCornerShape(4.dp)),
        color = MaterialTheme.colorScheme.primary,
        trackColor = MaterialTheme.colorScheme.surfaceVariant
    )
}
