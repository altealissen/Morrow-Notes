package app.morrow

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.ServiceCompat
import java.time.Instant
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZonedDateTime

/**
 * Alarms use AlarmManager.setAlarmClock (the most reliable API: works in Doze, survives
 * battery savers, needs no special permission). Event reminders use one exact alarm that always
 * points to the earliest pending reminder and is re-armed after every change, boot, time or
 * time-zone change.
 */
object Scheduler {
    const val CH_ALARM = "morrow_alarm"
    const val CH_REMINDER = "morrow_reminder"
    const val ACTION_ALARM_FIRE = "app.morrow.ALARM_FIRE"
    const val ACTION_REMIND = "app.morrow.REMIND"
    const val ACTION_DONE = "app.morrow.EVENT_DONE"
    const val EXTRA_ID = "id"
    const val EXTRA_SNOOZE = "snooze"
    const val EXTRA_TAB = "tab"

    fun ensureChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java) ?: return
        val alarm = NotificationChannel(CH_ALARM, "Будильники", NotificationManager.IMPORTANCE_HIGH)
        alarm.description = "Сигнал будильника"
        alarm.setSound(null, null)
        alarm.enableVibration(false)
        val rem = NotificationChannel(CH_REMINDER, "Напоминания", NotificationManager.IMPORTANCE_HIGH)
        rem.description = "Напоминания о событиях"
        nm.createNotificationChannel(alarm)
        nm.createNotificationChannel(rem)
    }

    // ------------------------------------------------------------------ alarms

    fun nextAlarmTime(a: AlarmItem, from: Long): Long {
        val zone = ZoneId.systemDefault()
        val today = Instant.ofEpochMilli(from).atZone(zone).toLocalDate()
        for (offset in 0..8) {
            val d = today.plusDays(offset.toLong())
            val dow = d.dayOfWeek.value - 1
            if (a.days != 0 && ((a.days shr dow) and 1) == 0) continue
            val t = ZonedDateTime.of(d, LocalTime.of(a.hour, a.minute), zone).toInstant().toEpochMilli()
            if (t > from) return t
        }
        return from + 24L * 60L * 60L * 1000L
    }

    /** The enabled alarm that will ring first, with its time. */
    fun nextAlarm(): Pair<AlarmItem, Long>? {
        val now = System.currentTimeMillis()
        var best: Pair<AlarmItem, Long>? = null
        for (a in Repo.alarms) {
            if (!a.enabled) continue
            val t = nextAlarmTime(a, now)
            val b = best
            if (b == null || t < b.second) best = Pair(a, t)
        }
        return best
    }

    private fun alarmPi(ctx: Context, id: Long, snooze: Boolean): PendingIntent {
        val i = Intent(ctx, AlarmReceiver::class.java)
            .setAction(ACTION_ALARM_FIRE)
            .setData(Uri.parse((if (snooze) "morrow://snooze/" else "morrow://alarm/") + id))
            .putExtra(EXTRA_ID, id)
            .putExtra(EXTRA_SNOOZE, snooze)
        return PendingIntent.getBroadcast(
            ctx, 0, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun showPi(ctx: Context): PendingIntent {
        val i = Intent(ctx, MainActivity::class.java)
            .putExtra(EXTRA_TAB, "Alarm")
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        return PendingIntent.getActivity(
            ctx, 1, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun setClock(ctx: Context, triggerAt: Long, pi: PendingIntent) {
        val am = ctx.getSystemService(AlarmManager::class.java) ?: return
        try {
            am.setAlarmClock(AlarmManager.AlarmClockInfo(triggerAt, showPi(ctx)), pi)
        } catch (_: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
        }
    }

    fun cancelAlarm(ctx: Context, id: Long) {
        val am = ctx.getSystemService(AlarmManager::class.java) ?: return
        am.cancel(alarmPi(ctx, id, false))
        am.cancel(alarmPi(ctx, id, true))
    }

    fun snooze(ctx: Context, a: AlarmItem) {
        val at = System.currentTimeMillis() + a.snoozeMin.coerceAtLeast(1) * 60_000L
        setClock(ctx, at, alarmPi(ctx, a.id, true))
    }

    fun cancelSnooze(ctx: Context, id: Long) {
        val am = ctx.getSystemService(AlarmManager::class.java) ?: return
        am.cancel(alarmPi(ctx, id, true))
    }

    // --------------------------------------------------------------- reminders

    private fun reminderPi(ctx: Context): PendingIntent {
        val i = Intent(ctx, ReminderReceiver::class.java)
            .setAction(ACTION_REMIND)
            .setData(Uri.parse("morrow://reminder"))
        return PendingIntent.getBroadcast(
            ctx, 0, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun canScheduleExact(ctx: Context): Boolean {
        if (Build.VERSION.SDK_INT < 31) return true
        val am = ctx.getSystemService(AlarmManager::class.java) ?: return false
        return am.canScheduleExactAlarms()
    }

    private fun armReminder(ctx: Context) {
        val am = ctx.getSystemService(AlarmManager::class.java) ?: return
        val pi = reminderPi(ctx)
        val pending = Repo.events.filter { it.remindMin >= 0 && !it.done && !it.reminderFired }
        if (pending.isEmpty()) {
            am.cancel(pi)
            return
        }
        val now = System.currentTimeMillis()
        val next = pending.minOf { it.triggerMillis() }
        val at = maxOf(next, now + 2000L)
        try {
            if (canScheduleExact(ctx)) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            } else {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            }
        } catch (_: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }
    }

    /** Posts notifications for every reminder that is due now. */
    fun fireDueReminders(ctx: Context) {
        val now = System.currentTimeMillis()
        val due = Repo.events.filter {
            it.remindMin >= 0 && !it.done && !it.reminderFired && it.triggerMillis() <= now
        }
        for (e in due) {
            // events that are already over are not worth a notification
            if (e.endMillis() >= now) notifyReminder(ctx, e)
            Repo.upsertEvent(e.copy(reminderFired = true))
        }
        Repo.saveNow()
        armReminder(ctx)
    }

    private fun notifyReminder(ctx: Context, e: Event) {
        ensureChannels(ctx)
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        val reqCode = (e.id % 1_000_000_007L).toInt()
        val open = PendingIntent.getActivity(
            ctx, reqCode,
            Intent(ctx, MainActivity::class.java)
                .setData(Uri.parse("morrow://event/${e.id}"))
                .putExtra(EXTRA_TAB, "Planner")
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            flags
        )
        val done = PendingIntent.getBroadcast(
            ctx, reqCode,
            Intent(ctx, ReminderReceiver::class.java)
                .setAction(ACTION_DONE)
                .setData(Uri.parse("morrow://done/${e.id}"))
                .putExtra(EXTRA_ID, e.id),
            flags
        )
        val time = fmtTime(e.startMin)
        val text = when {
            e.remindMin == 0 -> "Начинается сейчас · $time"
            else -> remindLabel(e.remindMin).replaceFirst("За", "Через") + " · $time"
        }
        val n = NotificationCompat.Builder(ctx, CH_REMINDER)
            .setSmallIcon(R.drawable.ic_stat_morrow)
            .setContentTitle(e.title.ifBlank { "Событие" })
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(if (e.description.isBlank()) text else text + "\n" + e.description))
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(open)
            .addAction(0, "Готово", done)
            .build()
        try {
            NotificationManagerCompat.from(ctx).notify(reqCode, n)
        } catch (_: SecurityException) {
        }
    }

    // ------------------------------------------------------------------ everything

    fun rescheduleAll(ctx: Context) {
        val c = ctx.applicationContext
        Repo.init(c)
        for (a in Repo.alarms) {
            if (a.enabled) {
                setClock(c, nextAlarmTime(a, System.currentTimeMillis()), alarmPi(c, a.id, false))
            } else {
                val am = c.getSystemService(AlarmManager::class.java)
                am?.cancel(alarmPi(c, a.id, false))
            }
        }
        armReminder(c)
    }
}

// ============================================================================ receivers

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent == null) return
        Repo.init(context)
        val id = intent.getLongExtra(Scheduler.EXTRA_ID, -1L)
        val snooze = intent.getBooleanExtra(Scheduler.EXTRA_SNOOZE, false)
        val alarm = Repo.alarms.firstOrNull { it.id == id } ?: return
        if (!snooze && alarm.days == 0) {
            // one-time alarm: switch it off after it rang
            Repo.upsertAlarm(alarm.copy(enabled = false))
        }
        val svc = Intent(context, AlarmService::class.java)
            .setAction(AlarmService.ACTION_START)
            .putExtra(Scheduler.EXTRA_ID, id)
        try {
            context.startForegroundService(svc)
        } catch (_: Exception) {
        }
        Scheduler.rescheduleAll(context)
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        Repo.init(context)
        val action = intent?.action
        val extraId = intent?.getLongExtra(Scheduler.EXTRA_ID, -1L) ?: -1L
        when (action) {
            Scheduler.ACTION_DONE -> {
                val id = extraId
                val e = Repo.eventById(id)
                if (e != null) Repo.upsertEvent(e.copy(done = true))
                Repo.saveNow()
                NotificationManagerCompat.from(context).cancel((id % 1_000_000_007L).toInt())
                Scheduler.rescheduleAll(context)
            }
            else -> Scheduler.fireDueReminders(context)
        }
    }
}

/** Boot, app update, time / time-zone changes: re-arm everything. */
class SystemEventsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        Scheduler.ensureChannels(context)
        Scheduler.rescheduleAll(context)
        Scheduler.fireDueReminders(context)
    }
}

// ============================================================================ ring service

class AlarmService : Service() {
    companion object {
        const val ACTION_START = "app.morrow.ALARM_START"
        const val ACTION_STOP = "app.morrow.ALARM_STOP"
        const val ACTION_SNOOZE = "app.morrow.ALARM_SNOOZE"
        const val NOTIF_ID = 4201
        const val MAX_RING_MS = 10L * 60L * 1000L

        @Volatile
        var ringingId: Long = -1L
    }

    private var player: MediaPlayer? = null
    private var vibrator: Vibrator? = null
    private val handler = Handler(Looper.getMainLooper())
    private var target = 0.8f
    private var step = 0
    private val autoStop = Runnable { stopRinging() }
    private val ramp = object : Runnable {
        override fun run() {
            step++
            val f = (0.1f + 0.9f * step / 30f).coerceAtMost(1f)
            try {
                player?.setVolume(target * f, target * f)
            } catch (_: Exception) {
            }
            if (step < 30) handler.postDelayed(this, 1000L)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Repo.init(this)
        val action = intent?.action
        val extraId = intent?.getLongExtra(Scheduler.EXTRA_ID, -1L) ?: -1L
        when (action) {
            ACTION_STOP -> {
                stopRinging()
                return START_NOT_STICKY
            }
            ACTION_SNOOZE -> {
                val id = if (extraId > 0L) extraId else ringingId
                val a = Repo.alarms.firstOrNull { it.id == id }
                if (a != null) Scheduler.snooze(this, a)
                stopRinging()
                return START_NOT_STICKY
            }
            else -> {
                Scheduler.ensureChannels(this)
                val a = Repo.alarms.firstOrNull { it.id == extraId }
                try {
                    ServiceCompat.startForeground(
                        this, NOTIF_ID, buildNotification(a),
                        ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
                    )
                } catch (_: Exception) {
                    stopSelf()
                    return START_NOT_STICKY
                }
                if (a == null) {
                    stopRinging()
                    return START_NOT_STICKY
                }
                startRinging(a)
            }
        }
        return START_NOT_STICKY
    }

    private fun buildNotification(a: AlarmItem?): android.app.Notification {
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        val id = a?.id ?: -1L
        val ring = PendingIntent.getActivity(
            this, 10, Intent(this, AlarmRingActivity::class.java)
                .putExtra(Scheduler.EXTRA_ID, id)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_USER_ACTION),
            flags
        )
        val stop = PendingIntent.getService(
            this, 11, Intent(this, AlarmService::class.java).setAction(ACTION_STOP), flags
        )
        val snooze = PendingIntent.getService(
            this, 12,
            Intent(this, AlarmService::class.java).setAction(ACTION_SNOOZE).putExtra(Scheduler.EXTRA_ID, id),
            flags
        )
        val title = a?.label?.ifBlank { null } ?: "Будильник"
        val time = if (a != null) pad2(a.hour) + ":" + pad2(a.minute) else ""
        return NotificationCompat.Builder(this, Scheduler.CH_ALARM)
            .setSmallIcon(R.drawable.ic_stat_morrow)
            .setContentTitle(title)
            .setContentText(time)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setOngoing(true)
            .setContentIntent(ring)
            .setFullScreenIntent(ring, true)
            .addAction(0, "Отложить", snooze)
            .addAction(0, "Стоп", stop)
            .build()
    }

    private fun startRinging(a: AlarmItem) {
        stopSound()
        ringingId = a.id
        target = (a.volume / 100f).coerceIn(0.05f, 1f)
        step = 0
        val mp = Sounds.buildPlayer(this, a.soundUri, true)
        if (mp != null) {
            val v0 = if (a.gradual) target * 0.1f else target
            mp.setVolume(v0, v0)
            try {
                mp.start()
                player = mp
                if (a.gradual) handler.postDelayed(ramp, 1000L)
            } catch (_: Exception) {
                try {
                    mp.release()
                } catch (_: Exception) {
                }
            }
        }
        if (a.vibrate) startVibration()
        handler.removeCallbacks(autoStop)
        handler.postDelayed(autoStop, MAX_RING_MS)
    }

    @Suppress("DEPRECATION")
    private fun startVibration() {
        try {
            val v: Vibrator? = if (Build.VERSION.SDK_INT >= 31) {
                getSystemService(VibratorManager::class.java)?.defaultVibrator
            } else {
                getSystemService(Vibrator::class.java)
            }
            vibrator = v
            val effect = VibrationEffect.createWaveform(longArrayOf(0, 700, 500), 0)
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            v?.vibrate(effect, attrs)
        } catch (_: Exception) {
        }
    }

    private fun stopSound() {
        handler.removeCallbacks(ramp)
        handler.removeCallbacks(autoStop)
        try {
            player?.stop()
        } catch (_: Exception) {
        }
        try {
            player?.release()
        } catch (_: Exception) {
        }
        player = null
        try {
            vibrator?.cancel()
        } catch (_: Exception) {
        }
        vibrator = null
    }

    private fun stopRinging() {
        stopSound()
        ringingId = -1L
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        stopSound()
        ringingId = -1L
        super.onDestroy()
    }
}
