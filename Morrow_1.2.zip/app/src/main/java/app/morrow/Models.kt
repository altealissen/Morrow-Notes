package app.morrow

import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId

/** Colors offered for events and categories (ARGB ints). */
val Swatches: List<Int> = listOf(
    0xFF3E8E6AL, 0xFF3F7FB5L, 0xFFC9473FL, 0xFF8A5CC2L,
    0xFFD08A1EL, 0xFFC4476BL, 0xFF2E9AA8L, 0xFF6B7A86L
).map { it.toInt() }

data class Event(
    val id: Long,
    val title: String,
    val description: String = "",
    val epochDay: Long,
    val startMin: Int,
    val durationMin: Int = 60,
    val color: Int,
    val done: Boolean = false,
    val remindMin: Int = -1,
    val reminderFired: Boolean = false
) {
    val date: LocalDate get() = LocalDate.ofEpochDay(epochDay)

    fun startMillis(): Long =
        LocalDateTime.of(date, LocalTime.of((startMin / 60) % 24, startMin % 60))
            .atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()

    fun endMillis(): Long = startMillis() + durationMin * 60_000L
    fun triggerMillis(): Long = startMillis() - remindMin * 60_000L
}

data class Note(
    val id: Long,
    val title: String,
    val body: String,
    val categoryId: Long,
    val created: Long,
    val modified: Long,
    val pinned: Boolean = false,
    val trashedAt: Long = 0L
)

data class Category(val id: Long, val name: String, val color: Int)

data class AlarmItem(
    val id: Long,
    val hour: Int,
    val minute: Int,
    val label: String = "",
    val days: Int = 0,            // bit 0 = Monday ... bit 6 = Sunday; 0 = one time
    val enabled: Boolean = true,
    val soundUri: String = "",    // empty = system default alarm sound
    val soundName: String = "",
    val volume: Int = 80,         // 0..100
    val gradual: Boolean = true,
    val vibrate: Boolean = true,
    val snoozeMin: Int = 10
)

data class CodeFile(
    val id: Long,
    val name: String,
    val language: String,
    val modified: Long
)

fun Event.toJson(): JSONObject = JSONObject()
    .put("id", id).put("title", title).put("description", description)
    .put("epochDay", epochDay).put("startMin", startMin).put("durationMin", durationMin)
    .put("color", color).put("done", done).put("remindMin", remindMin)
    .put("reminderFired", reminderFired)

fun eventFromJson(o: JSONObject): Event = Event(
    id = o.getLong("id"),
    title = o.optString("title", ""),
    description = o.optString("description", ""),
    epochDay = o.getLong("epochDay"),
    startMin = o.optInt("startMin", 540),
    durationMin = o.optInt("durationMin", 60),
    color = o.optInt("color", Swatches[0]),
    done = o.optBoolean("done", false),
    remindMin = o.optInt("remindMin", -1),
    reminderFired = o.optBoolean("reminderFired", false)
)

fun Note.toJson(): JSONObject = JSONObject()
    .put("id", id).put("title", title).put("body", body).put("categoryId", categoryId)
    .put("created", created).put("modified", modified).put("pinned", pinned)
    .put("trashedAt", trashedAt)

fun noteFromJson(o: JSONObject): Note = Note(
    id = o.getLong("id"),
    title = o.optString("title", ""),
    body = o.optString("body", ""),
    categoryId = o.optLong("categoryId", 0L),
    created = o.optLong("created", System.currentTimeMillis()),
    modified = o.optLong("modified", System.currentTimeMillis()),
    pinned = o.optBoolean("pinned", false),
    trashedAt = o.optLong("trashedAt", 0L)
)

fun Category.toJson(): JSONObject = JSONObject().put("id", id).put("name", name).put("color", color)

fun categoryFromJson(o: JSONObject): Category =
    Category(o.getLong("id"), o.optString("name", "?"), o.optInt("color", Swatches[0]))

fun AlarmItem.toJson(): JSONObject = JSONObject()
    .put("id", id).put("hour", hour).put("minute", minute).put("label", label)
    .put("days", days).put("enabled", enabled).put("soundUri", soundUri)
    .put("soundName", soundName).put("volume", volume).put("gradual", gradual)
    .put("vibrate", vibrate).put("snoozeMin", snoozeMin)

fun alarmFromJson(o: JSONObject): AlarmItem = AlarmItem(
    id = o.getLong("id"),
    hour = o.optInt("hour", 7),
    minute = o.optInt("minute", 0),
    label = o.optString("label", ""),
    days = o.optInt("days", 0),
    enabled = o.optBoolean("enabled", true),
    soundUri = o.optString("soundUri", ""),
    soundName = o.optString("soundName", ""),
    volume = o.optInt("volume", 80),
    gradual = o.optBoolean("gradual", true),
    vibrate = o.optBoolean("vibrate", true),
    snoozeMin = o.optInt("snoozeMin", 10)
)

fun CodeFile.toJson(): JSONObject = JSONObject()
    .put("id", id).put("name", name).put("language", language).put("modified", modified)

fun codeFromJson(o: JSONObject): CodeFile = CodeFile(
    id = o.getLong("id"),
    name = o.optString("name", "file.txt"),
    language = o.optString("language", "text"),
    modified = o.optLong("modified", System.currentTimeMillis())
)

fun <T> List<T>.toJsonArray(f: (T) -> JSONObject): JSONArray {
    val arr = JSONArray()
    for (item in this) arr.put(f(item))
    return arr
}

fun JSONArray.objects(): List<JSONObject> {
    val out = ArrayList<JSONObject>()
    for (i in 0 until length()) {
        val o = optJSONObject(i)
        if (o != null) out.add(o)
    }
    return out
}
