package app.morrow

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val AccentChoices: List<Int> = listOf(
    0xFFD81B2BL, 0xFFE8590CL, 0xFFF2A100L, 0xFF2E9E57L, 0xFF00897BL,
    0xFF1E88E5L, 0xFF5E35B1L, 0xFFC2185BL, 0xFF6D4C41L, 0xFF546E7AL
).map { it.toInt() }

@Composable
fun ThemesScreen() {
    val cs = MaterialTheme.colorScheme
    val extras = LocalExtras.current
    val systemDark = isSystemInDarkTheme()
    var showHex by remember { mutableStateOf(false) }
    val effectiveDark = when (Prefs.themeMode) {
        1 -> false
        2 -> true
        else -> systemDark
    }
    val dynamicAvailable = android.os.Build.VERSION.SDK_INT >= 31

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenHeader("Themes", "Лес, туман, дождь и немного OnePlus")

        MCard {
            SmallLabel("Режим")
            Spacer(Modifier.height(8.dp))
            ChipRow(listOf("Авто", "Светлый", "Тёмный"), Prefs.themeMode) { Prefs.updateThemeMode(it) }
            Spacer(Modifier.height(8.dp))
            Hint(
                "Авто следует системе: светлая тема «" + Prefs.lightTheme +
                    "», тёмная «" + Prefs.darkTheme + "»."
            )
        }

        MCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Цвета системы", color = cs.onSurface, style = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.Medium))
                    Hint(
                        if (dynamicAvailable) "Monet / Material You: палитра берётся из обоев"
                        else "Нужен Android 12 или новее"
                    )
                }
                Switch(
                    checked = Prefs.dynamic && dynamicAvailable,
                    onCheckedChange = { Prefs.updateDynamic(it) },
                    enabled = dynamicAvailable
                )
            }
        }

        MCard {
            SmallLabel("Акцентный цвет")
            Spacer(Modifier.height(10.dp))
            SwatchPicker(Prefs.accent, { Prefs.updateAccent(it) }, AccentChoices)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = Prefs.accent == 0,
                    onClick = { Prefs.updateAccent(0) },
                    label = { Text("Как в теме") }
                )
                AssistChip(onClick = { showHex = true }, label = { Text("Свой цвет…") })
            }
            if (Prefs.accent != 0) {
                Spacer(Modifier.height(6.dp))
                Hint("Если цвет плохо читается на фоне, он автоматически чуть затемняется или светлеет.")
            }
        }

        MCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Red One", color = cs.onSurface, style = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.Medium))
                    Text(
                        buildAnnotatedString {
                            append("Каждая цифра ")
                            pushStyle(androidx.compose.ui.text.SpanStyle(color = extras.red, fontWeight = FontWeight.Bold))
                            append("1")
                            pop()
                            append(" в заметках и коде становится красной")
                        },
                        color = cs.onSurfaceVariant,
                        style = TextStyle(fontSize = 13.sp)
                    )
                }
                Switch(checked = Prefs.redOne, onCheckedChange = { Prefs.updateRedOne(it) })
            }
        }

        for (group in PaletteGroups) {
            val items = Palettes.filter { it.group == group }
            SmallLabel(group, Modifier.padding(start = 4.dp, top = 6.dp))
            Row(
                Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                for (p in items) {
                    val selected = if (p.dark) Prefs.darkTheme == p.name else Prefs.lightTheme == p.name
                    PaletteTile(p, selected) {
                        if (p.dark) Prefs.updateDarkTheme(p.name) else Prefs.updateLightTheme(p.name)
                        Prefs.updateDynamic(false)
                        if (p.dark != effectiveDark) Prefs.updateThemeMode(if (p.dark) 2 else 1)
                    }
                }
            }
            if (group == GROUP_PNW) {
                Hint("Хвойные оттенки, туман и дождливые тона — для тихого вечера.", Modifier.padding(start = 4.dp))
            }
        }
        Spacer(Modifier.height(24.dp))
    }

    if (showHex) {
        var hex by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showHex = false },
            title = { Text("Свой цвет") },
            text = {
                OutlinedTextField(
                    value = hex,
                    onValueChange = { v -> hex = v.filter { it.isDigit() || it.lowercaseChar() in 'a'..'f' }.take(6).uppercase() },
                    prefix = { Text("#") },
                    label = { Text("HEX, например 3E8E6A") },
                    singleLine = true
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        val v = hex.toLongOrNull(16)
                        if (hex.length == 6 && v != null) {
                            Prefs.updateAccent((0xFF000000L or v).toInt())
                            showHex = false
                        }
                    },
                    enabled = hex.length == 6
                ) { Text("Применить") }
            },
            dismissButton = { TextButton(onClick = { showHex = false }) { Text("Отмена") } }
        )
    }
}

@Composable
private fun PaletteTile(p: Palette, selected: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(18.dp)
    Box(
        Modifier
            .width(132.dp)
            .clip(shape)
            .background(Color(p.bg))
            .border(
                if (selected) 2.dp else 1.dp,
                if (selected) cs.primary else cs.outlineVariant,
                shape
            )
            .clickable(onClick = onClick)
            .padding(12.dp)
    ) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier
                        .size(width = 44.dp, height = 22.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(p.surface))
                        .border(1.dp, Color(p.muted).copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                )
                Spacer(Modifier.width(8.dp))
                Box(
                    Modifier
                        .size(18.dp)
                        .clip(CircleShape)
                        .background(Color(p.accent))
                )
            }
            Spacer(Modifier.height(10.dp))
            Text("Aa 1", color = Color(p.text), style = TextStyle(fontSize = 20.sp, fontWeight = FontWeight.Medium))
            Text(p.name, color = Color(p.muted), style = TextStyle(fontSize = 12.sp), maxLines = 1)
        }
        if (selected) {
            Icon(
                Icons.Rounded.Check, null,
                tint = Color(p.accent),
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .size(18.dp)
            )
        }
    }
}
