package app.morrow

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate

data class Habit(
    val id: Long,
    val name: String,
    val color: Int,
    val days: Int = 0,          // 0 = every day, else bit mask Mon..Sun
    val goalWeek: Int = 7,
    val done: Set<Long> = emptySet()   // epoch days
)

data class JournalEntry(
    val id: Long,
    val epochDay: Long,
    val mood: Int,              // -1 none, 0..6 see Moods
    val text: String,
    val tags: String = "",
    val priv: Boolean = false,
    val modified: Long = 0L
)

data class Project(
    val id: Long,
    val name: String,
    val desc: String = "",
    val color: Int,
    val deadline: Long = -1L
)

data class PTask(val id: Long, val projectId: Long, val title: String, val status: Int = 0) // 0 todo 1 doing 2 done

data class Goal(val id: Long, val title: String, val period: Int = 0, val done: Boolean = false)

data class MediaItem(
    val id: Long,
    val kind: Int,              // 0 book 1 film/series 2 music 3 game
    val title: String,
    val author: String = "",
    val status: Int = 0,        // 0 want 1 in progress 2 done 3 paused
    val rating: Int = 0,
    val note: String = ""
)

val Moods = listOf("Отлично", "Хорошо", "Спокойно", "Нейтрально", "Грустно", "Устало", "Тревожно")
val MoodIcons = listOf("😄", "🙂", "😌", "😐", "😔", "😴", "😟")
val MediaKinds = listOf("Книга", "Фильм/сериал", "Музыка", "Игра")
val MediaStatuses = listOf("Хочу", "В процессе", "Завершено", "Отложено")
val GoalPeriods = listOf("День", "Неделя", "Месяц", "Год", "Долгосрочная")
val TaskStatuses = listOf("To Do", "In Progress", "Done")

/** Local-only store for the "life" modules. Persisted together with Repo's data.json. */
object Life {
    val habits = mutableStateListOf<Habit>()
    val journal = mutableStateListOf<JournalEntry>()
    val projects = mutableStateListOf<Project>()
    val ptasks = mutableStateListOf<PTask>()
    val goals = mutableStateListOf<Goal>()
    val media = mutableStateListOf<MediaItem>()
    val templates = mutableStateListOf<NoteTemplate>()
    var sleepBed by mutableIntStateOf(23 * 60)
    var sleepWake by mutableIntStateOf(7 * 60)
    var sleepRemind by mutableIntStateOf(30)

    fun maxId(): Long {
        var m = 0L
        for (x in habits) m = maxOf(m, x.id)
        for (x in journal) m = maxOf(m, x.id)
        for (x in projects) m = maxOf(m, x.id)
        for (x in ptasks) m = maxOf(m, x.id)
        for (x in goals) m = maxOf(m, x.id)
        for (x in media) m = maxOf(m, x.id)
        return m
    }

    private fun <T> upsert(list: MutableList<T>, item: T, idOf: (T) -> Long) {
        val i = list.indexOfFirst { idOf(it) == idOf(item) }
        if (i >= 0) list[i] = item else list.add(item)
        Repo.saveLater()
    }

    fun save(h: Habit) = upsert(habits, h) { it.id }
    fun save(j: JournalEntry) = upsert(journal, j.copy(modified = System.currentTimeMillis())) { it.id }
    fun save(p: Project) = upsert(projects, p) { it.id }
    fun save(t: PTask) = upsert(ptasks, t) { it.id }
    fun save(g: Goal) = upsert(goals, g) { it.id }
    fun save(m: MediaItem) = upsert(media, m) { it.id }

    fun removeHabit(id: Long) { habits.removeAll { it.id == id }; Repo.saveLater() }
    fun removeJournal(id: Long) { journal.removeAll { it.id == id }; Repo.saveLater() }
    fun removeProject(id: Long) {
        projects.removeAll { it.id == id }
        ptasks.removeAll { it.projectId == id }
        Repo.saveLater()
    }
    fun removeTask(id: Long) { ptasks.removeAll { it.id == id }; Repo.saveLater() }
    fun removeGoal(id: Long) { goals.removeAll { it.id == id }; Repo.saveLater() }
    fun removeMedia(id: Long) { media.removeAll { it.id == id }; Repo.saveLater() }

    // ---- habits
    fun isScheduled(h: Habit, epochDay: Long): Boolean {
        if (h.days == 0) return true
        val dow = LocalDate.ofEpochDay(epochDay).dayOfWeek.value - 1
        return (h.days shr dow) and 1 == 1
    }

    fun toggleHabit(id: Long, epochDay: Long) {
        val h = habits.firstOrNull { it.id == id } ?: return
        save(h.copy(done = if (epochDay in h.done) h.done - epochDay else h.done + epochDay))
    }

    /** Current streak of scheduled days; today may still be open without breaking it. */
    fun streak(h: Habit, today: Long): Int {
        var d = today
        if (d !in h.done) d -= 1
        var n = 0
        var guard = 0
        while (guard++ < 4000) {
            if (!isScheduled(h, d)) { d -= 1; continue }
            if (d in h.done) { n++; d -= 1 } else break
        }
        return n
    }

    fun weekCount(h: Habit, today: Long): Int {
        val monday = today - (LocalDate.ofEpochDay(today).dayOfWeek.value - 1)
        return h.done.count { it in monday..(monday + 6) }
    }

    /** Garden stage 0..4 from total completions. */
    fun stage(h: Habit): Int = when {
        h.done.size >= 60 -> 4
        h.done.size >= 30 -> 3
        h.done.size >= 12 -> 2
        h.done.isNotEmpty() -> 1
        else -> 0
    }

    // ---- json
    fun putJson(o: JSONObject, want: (String) -> Boolean) {
        if (want("media")) {
            o.put("templates", templates.toList().toJsonArray {
                JSONObject().put("name", it.name).put("title", it.title).put("body", it.body)
            })
            o.put("sleep", JSONObject().put("bed", sleepBed).put("wake", sleepWake).put("remind", sleepRemind))
        }
        if (want("habits")) o.put("habits", habits.toList().toJsonArray {
            JSONObject().put("id", it.id).put("name", it.name).put("color", it.color)
                .put("days", it.days).put("goalWeek", it.goalWeek)
                .put("done", JSONArray(it.done.sorted()))
        })
        if (want("journal")) o.put("journal", journal.toList().toJsonArray {
            JSONObject().put("id", it.id).put("epochDay", it.epochDay).put("mood", it.mood)
                .put("text", it.text).put("tags", it.tags).put("priv", it.priv)
                .put("modified", it.modified)
        })
        if (want("projects")) {
            o.put("projects", projects.toList().toJsonArray {
                JSONObject().put("id", it.id).put("name", it.name).put("desc", it.desc)
                    .put("color", it.color).put("deadline", it.deadline)
            })
            o.put("ptasks", ptasks.toList().toJsonArray {
                JSONObject().put("id", it.id).put("projectId", it.projectId)
                    .put("title", it.title).put("status", it.status)
            })
            o.put("goals", goals.toList().toJsonArray {
                JSONObject().put("id", it.id).put("title", it.title)
                    .put("period", it.period).put("done", it.done)
            })
        }
        if (want("media")) o.put("media", media.toList().toJsonArray {
            JSONObject().put("id", it.id).put("kind", it.kind).put("title", it.title)
                .put("author", it.author).put("status", it.status)
                .put("rating", it.rating).put("note", it.note)
        })
    }

    fun applyJson(o: JSONObject, replace: Boolean) {
        o.optJSONArray("templates")?.let { arr ->
            if (replace) templates.clear()
            for (x in arr.objects()) templates.add(NoteTemplate(x.optString("name", "?"),
                x.optString("title", ""), x.optString("body", "")))
        }
        o.optJSONObject("sleep")?.let { s ->
            sleepBed = s.optInt("bed", 23 * 60)
            sleepWake = s.optInt("wake", 7 * 60)
            sleepRemind = s.optInt("remind", 30)
        }
        o.optJSONArray("habits")?.let { arr ->
            if (replace) habits.clear()
            for (x in arr.objects()) {
                val ds = HashSet<Long>()
                val da = x.optJSONArray("done")
                if (da != null) for (i in 0 until da.length()) ds.add(da.optLong(i))
                habits.add(Habit(x.getLong("id"), x.optString("name", "?"), x.optInt("color", Swatches[0]),
                    x.optInt("days", 0), x.optInt("goalWeek", 7), ds))
            }
        }
        o.optJSONArray("journal")?.let { arr ->
            if (replace) journal.clear()
            for (x in arr.objects()) journal.add(JournalEntry(x.getLong("id"), x.optLong("epochDay"),
                x.optInt("mood", -1), x.optString("text", ""), x.optString("tags", ""),
                x.optBoolean("priv", false), x.optLong("modified", 0L)))
        }
        o.optJSONArray("projects")?.let { arr ->
            if (replace) projects.clear()
            for (x in arr.objects()) projects.add(Project(x.getLong("id"), x.optString("name", "?"),
                x.optString("desc", ""), x.optInt("color", Swatches[0]), x.optLong("deadline", -1L)))
        }
        o.optJSONArray("ptasks")?.let { arr ->
            if (replace) ptasks.clear()
            for (x in arr.objects()) ptasks.add(PTask(x.getLong("id"), x.optLong("projectId"),
                x.optString("title", ""), x.optInt("status", 0)))
        }
        o.optJSONArray("goals")?.let { arr ->
            if (replace) goals.clear()
            for (x in arr.objects()) goals.add(Goal(x.getLong("id"), x.optString("title", ""),
                x.optInt("period", 0), x.optBoolean("done", false)))
        }
        o.optJSONArray("media")?.let { arr ->
            if (replace) media.clear()
            for (x in arr.objects()) media.add(MediaItem(x.getLong("id"), x.optInt("kind", 0),
                x.optString("title", ""), x.optString("author", ""), x.optInt("status", 0),
                x.optInt("rating", 0), x.optString("note", "")))
        }
    }
}
