package app.morrow

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun AlarmScreen() {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val alarms = Repo.alarms.sortedWith(compareBy({ it.hour }, { it.minute }))
    val next = Scheduler.nextAlarm()
    val now = System.currentTimeMillis()

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            ScreenHeader(
                "Alarm",
                if (next == null) "Все будильники выключены" else "Ближайший " + relativeIn(next.second - now)
            )
            NotificationPermissionCard(Modifier.padding(horizontal = 16.dp))
            if (alarms.isEmpty()) {
                Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.TopCenter) {
                    Hint("Будильников пока нет. Нажмите «Будильник», чтобы создать первый.")
                }
            } else {
                LazyColumn(
                    Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 96.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(alarms, key = { it.id }) { a ->
                        MCard(onClick = { Nav.route = Route.AlarmEdit(a.id) }) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(
                                        pad2(a.hour) + ":" + pad2(a.minute),
                                        style = TextStyle(fontSize = 40.sp, fontWeight = FontWeight.Light),
                                        color = if (a.enabled) cs.onSurface else cs.onSurfaceVariant
                                    )
                                    Text(
                                        (if (a.label.isBlank()) "" else a.label + " · ") + daysSummary(a.days),
                                        style = TextStyle(fontSize = 14.sp),
                                        color = cs.onSurfaceVariant,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    if (a.enabled) {
                                        Text(
                                            relativeIn(Scheduler.nextAlarmTime(a, now) - now),
                                            style = TextStyle(fontSize = 12.sp),
                                            color = cs.primary
                                        )
                                    }
                                }
                                Switch(
                                    checked = a.enabled,
                                    onCheckedChange = { on ->
                                        Repo.upsertAlarm(a.copy(enabled = on))
                                        Scheduler.rescheduleAll(ctx)
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
        ExtendedFloatingActionButton(
            onClick = { Nav.route = Route.AlarmEdit(0L) },
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(16.dp),
            containerColor = cs.primary,
            contentColor = cs.onPrimary,
            icon = { Icon(Icons.Rounded.Add, null) },
            text = { Text("Будильник") }
        )
    }
}

@Composable
fun AlarmEditor(id: Long, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val existing = remember(id) { Repo.alarms.firstOrNull { it.id == id } }

    var hour by remember { mutableIntStateOf(existing?.hour ?: 7) }
    var minute by remember { mutableIntStateOf(existing?.minute ?: 0) }
    var label by remember { mutableStateOf(existing?.label ?: "") }
    var days by remember { mutableIntStateOf(existing?.days ?: 0) }
    var soundUri by remember { mutableStateOf(existing?.soundUri ?: "") }
    var soundName by remember { mutableStateOf(existing?.soundName ?: "") }
    var volume by remember { mutableIntStateOf(existing?.volume ?: 80) }
    var gradual by remember { mutableStateOf(existing?.gradual ?: true) }
    var vibrate by remember { mutableStateOf(existing?.vibrate ?: true) }
    var snooze by remember { mutableIntStateOf(existing?.snoozeMin ?: 10) }

    var showTime by remember { mutableStateOf(false) }
    var showSound by remember { mutableStateOf(false) }
    var showDelete by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) {
            }
            soundUri = uri.toString()
            soundName = Sounds.displayName(ctx, uri)
            SoundPreview.stop()
        }
    }

    DisposableEffect(Unit) {
        onDispose { SoundPreview.stop() }
    }

    fun draft(): AlarmItem = AlarmItem(
        id = existing?.id ?: 0L,
        hour = hour, minute = minute, label = label.trim(), days = days, enabled = true,
        soundUri = soundUri, soundName = soundName, volume = volume,
        gradual = gradual, vibrate = vibrate, snoozeMin = snooze
    )

    fun save() {
        val d = draft()
        val a = if (d.id == 0L) d.copy(id = Repo.newId()) else d
        Repo.upsertAlarm(a)
        Scheduler.rescheduleAll(ctx)
        ctx.toast("Будильник сработает " + relativeIn(Scheduler.nextAlarmTime(a, System.currentTimeMillis()) - System.currentTimeMillis()))
        onClose()
    }

    EditorFrame {
        TopBarRow(if (existing == null) "Новый будильник" else "Будильник", onClose) {
            if (existing != null) {
                IconButton(onClick = { showDelete = true }) { Icon(Icons.Rounded.Delete, "Удалить") }
            }
            TextButton(onClick = { save() }) { Text("Сохранить") }
        }
        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            MCard(onClick = { showTime = true }) {
                Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        pad2(hour) + ":" + pad2(minute),
                        style = TextStyle(fontSize = 64.sp, fontWeight = FontWeight.Light),
                        color = cs.onSurface
                    )
                    val t = Scheduler.nextAlarmTime(draft(), System.currentTimeMillis())
                    Hint("Сработает " + relativeIn(t - System.currentTimeMillis()))
                }
            }
            OutlinedTextField(
                value = label,
                onValueChange = { label = it },
                label = { Text("Название") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            SmallLabel("Повтор")
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                for (i in 0 until 7) {
                    val on = ((days shr i) and 1) == 1
                    Box(
                        Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(if (on) cs.primary else cs.surfaceVariant)
                            .clickable { days = days xor (1 shl i) },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            DayNamesShort[i],
                            style = TextStyle(fontSize = 13.sp, fontWeight = FontWeight.Medium),
                            color = if (on) cs.onPrimary else cs.onSurface
                        )
                    }
                }
            }
            ChipRow(
                listOf("Один раз", "Каждый день", "По будням", "По выходным"),
                when (days) {
                    0 -> 0
                    127 -> 1
                    31 -> 2
                    96 -> 3
                    else -> -1
                }
            ) { i -> days = listOf(0, 127, 31, 96)[i] }

            SmallLabel("Звук")
            MCard(onClick = { showSound = true }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.MusicNote, null, tint = cs.primary)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            if (soundName.isBlank()) "По умолчанию" else soundName,
                            color = cs.onSurface,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Hint(if (soundName.isBlank()) "Системный звук будильника" else "Нажмите, чтобы изменить")
                    }
                }
            }
            val playing = SoundPreview.playingKey == "editor"
            OutlinedButton(onClick = { SoundPreview.toggle(ctx, "editor", soundUri, volume / 100f) }) {
                Icon(if (playing) Icons.Rounded.Stop else Icons.Rounded.PlayArrow, null)
                Spacer(Modifier.width(6.dp))
                Text(if (playing) "Остановить" else "Прослушать")
            }

            SmallLabel("Громкость · $volume%")
            Slider(
                value = volume.toFloat(),
                onValueChange = { volume = it.toInt() },
                valueRange = 5f..100f
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Постепенное нарастание", color = cs.onBackground)
                    Hint("Громкость растёт в течение 30 секунд")
                }
                Switch(checked = gradual, onCheckedChange = { gradual = it })
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Вибрация", Modifier.weight(1f), color = cs.onBackground)
                Switch(checked = vibrate, onCheckedChange = { vibrate = it })
            }
            SmallLabel("Повтор сигнала через")
            val snoozeOptions = listOf(5, 10, 15, 20, 30)
            ChipRow(snoozeOptions.map { "$it мин" }, snoozeOptions.indexOf(snooze)) { snooze = snoozeOptions[it] }
            Spacer(Modifier.height(24.dp))
        }
    }

    if (showTime) {
        TimePickerDialogM(hour, minute, { showTime = false }) { h, m ->
            hour = h
            minute = m
            showTime = false
        }
    }
    if (showSound) {
        SoundPickerDialog(
            currentUri = soundUri,
            currentName = soundName,
            volume = volume / 100f,
            onPick = { uri, name ->
                soundUri = uri
                soundName = name
                SoundPreview.stop()
                showSound = false
            },
            onPickFile = {
                showSound = false
                picker.launch(arrayOf("audio/*"))
            },
            onDismiss = {
                SoundPreview.stop()
                showSound = false
            }
        )
    }
    if (showDelete && existing != null) {
        ConfirmDialog(
            title = "Удалить будильник?",
            text = "Будильник на " + pad2(existing.hour) + ":" + pad2(existing.minute) + " будет удалён.",
            confirmLabel = "Удалить",
            onConfirm = {
                Scheduler.cancelAlarm(ctx, existing.id)
                Repo.deleteAlarm(existing.id)
                showDelete = false
                onClose()
            },
            onDismiss = { showDelete = false }
        )
    }
}

@Composable
private fun SoundPickerDialog(
    currentUri: String,
    currentName: String,
    volume: Float,
    onPick: (String, String) -> Unit,
    onPickFile: () -> Unit,
    onDismiss: () -> Unit
) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val system = remember { Sounds.systemAlarmSounds(ctx) }
    val isCustom = currentUri.isNotEmpty() && system.none { it.uri == currentUri }

    @Composable
    fun Option(key: String, title: String, uri: String, selected: Boolean) {
        Row(
            Modifier
                .fillMaxWidth()
                .clickable { onPick(uri, if (uri.isEmpty()) "" else title) },
            verticalAlignment = Alignment.CenterVertically
        ) {
            RadioButton(selected = selected, onClick = { onPick(uri, if (uri.isEmpty()) "" else title) })
            Text(
                title,
                Modifier.weight(1f),
                color = cs.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            val playing = SoundPreview.playingKey == key
            IconButton(onClick = { SoundPreview.toggle(ctx, key, uri, volume) }) {
                Icon(if (playing) Icons.Rounded.Stop else Icons.Rounded.PlayArrow, "Прослушать")
            }
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Звук будильника") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Option("default", "По умолчанию", "", currentUri.isEmpty())
                if (isCustom) {
                    Option("custom", currentName.ifBlank { "Свой звук" }, currentUri, true)
                }
                if (system.isNotEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    SmallLabel("Звуки телефона")
                }
                for (s in system) {
                    Option("sys:" + s.uri, s.title, s.uri, currentUri == s.uri)
                }
                Spacer(Modifier.height(8.dp))
                TextButton(onClick = onPickFile) { Text("Выбрать свой файл…") }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Закрыть") } }
    )
}
