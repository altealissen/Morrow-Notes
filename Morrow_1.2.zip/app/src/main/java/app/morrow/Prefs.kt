package app.morrow

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import org.json.JSONObject

private val Context.settingsStore by preferencesDataStore(name = "morrow_settings")

val TodayBlocks = listOf("greeting", "next", "plan", "reminders", "alarm", "notes", "stats")

/** Prefs kept in Jetpack DataStore, mirrored into Compose state. */
object Prefs {
    private var app: Context? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    var themeMode by mutableStateOf(0)            // 0 = system, 1 = light, 2 = dark
    var lightTheme by mutableStateOf("Ivory")
    var darkTheme by mutableStateOf("Midnight")
    var dynamic by mutableStateOf(false)
    var accent by mutableStateOf(0)               // 0 = palette default, otherwise ARGB
    var redOne by mutableStateOf(true)
    var todayOrder by mutableStateOf(TodayBlocks.joinToString(","))
    var todayHidden by mutableStateOf("")
    var codeFontSize by mutableStateOf(14)
    var codeWrap by mutableStateOf(false)
    var plannerView by mutableStateOf(0)          // 0 = month, 1 = week

    // values left behind by Morrow 0.2 (read once, used for migration)
    var legacyNote = ""
    var legacyPlan = ""
    var legacyCode = ""

    private val kMode = intPreferencesKey("theme_mode")
    private val kLight = stringPreferencesKey("light_theme")
    private val kDark = stringPreferencesKey("dark_theme")
    private val kDynamic = booleanPreferencesKey("dynamic")
    private val kAccent = intPreferencesKey("accent")
    private val kRed = booleanPreferencesKey("red_one")
    private val kOrder = stringPreferencesKey("today_order")
    private val kHidden = stringPreferencesKey("today_hidden")
    private val kFont = intPreferencesKey("code_font")
    private val kWrap = booleanPreferencesKey("code_wrap")
    private val kView = intPreferencesKey("planner_view")
    private val kOldTheme = stringPreferencesKey("theme")
    private val kOldNote = stringPreferencesKey("note")
    private val kOldPlan = stringPreferencesKey("plan")
    private val kOldCode = stringPreferencesKey("code")

    fun load(context: Context) {
        val c = context.applicationContext
        app = c
        val p: Preferences = try {
            runBlocking { c.settingsStore.data.first() }
        } catch (e: Exception) {
            return
        }
        themeMode = p[kMode] ?: 0
        lightTheme = p[kLight] ?: "Ivory"
        darkTheme = p[kDark] ?: "Midnight"
        dynamic = p[kDynamic] ?: false
        accent = p[kAccent] ?: 0
        redOne = p[kRed] ?: true
        todayOrder = p[kOrder] ?: TodayBlocks.joinToString(",")
        todayHidden = p[kHidden] ?: ""
        codeFontSize = p[kFont] ?: 14
        codeWrap = p[kWrap] ?: false
        plannerView = p[kView] ?: 0
        legacyNote = p[kOldNote] ?: ""
        legacyPlan = p[kOldPlan] ?: ""
        legacyCode = p[kOldCode] ?: ""
        // 0.2 stored a single palette name
        val old = p[kOldTheme]
        if (old != null && p[kLight] == null && p[kDark] == null) {
            val pal = Palettes.find { it.name == old }
            if (pal != null) {
                if (pal.dark) {
                    darkTheme = pal.name
                    themeMode = 2
                } else {
                    lightTheme = pal.name
                    themeMode = 1
                }
            }
        }
    }

    /** Called once the legacy 0.2 values were turned into real notes. */
    fun clearLegacy() {
        legacyNote = ""
        legacyPlan = ""
        legacyCode = ""
        val c = app ?: return
        scope.launch {
            try {
                c.settingsStore.edit {
                    it.remove(kOldNote)
                    it.remove(kOldPlan)
                    it.remove(kOldCode)
                    it.remove(kOldTheme)
                }
            } catch (_: Exception) {
            }
        }
    }

    private fun <T> put(key: Preferences.Key<T>, value: T) {
        val c = app ?: return
        scope.launch {
            try {
                c.settingsStore.edit { it[key] = value }
            } catch (_: Exception) {
            }
        }
    }

    fun updateThemeMode(v: Int) { themeMode = v; put(kMode, v) }
    fun updateLightTheme(v: String) { lightTheme = v; put(kLight, v) }
    fun updateDarkTheme(v: String) { darkTheme = v; put(kDark, v) }
    fun updateDynamic(v: Boolean) { dynamic = v; put(kDynamic, v) }
    fun updateAccent(v: Int) { accent = v; put(kAccent, v) }
    fun updateRedOne(v: Boolean) { redOne = v; put(kRed, v) }
    fun updateTodayOrder(v: String) { todayOrder = v; put(kOrder, v) }
    fun updateTodayHidden(v: String) { todayHidden = v; put(kHidden, v) }
    fun updateCodeFontSize(v: Int) { codeFontSize = v.coerceIn(9, 28); put(kFont, codeFontSize) }
    fun updateCodeWrap(v: Boolean) { codeWrap = v; put(kWrap, v) }
    fun updatePlannerView(v: Int) { plannerView = v; put(kView, v) }

    fun orderedBlocks(): List<String> {
        val saved = todayOrder.split(",").filter { it in TodayBlocks }.distinct()
        return saved + TodayBlocks.filter { it !in saved }
    }

    fun hiddenBlocks(): Set<String> = todayHidden.split(",").filter { it.isNotEmpty() }.toSet()

    fun resetToday() {
        updateTodayOrder(TodayBlocks.joinToString(","))
        updateTodayHidden("")
    }

    fun toJson(): JSONObject = JSONObject()
        .put("themeMode", themeMode).put("lightTheme", lightTheme).put("darkTheme", darkTheme)
        .put("dynamic", dynamic).put("accent", accent).put("redOne", redOne)
        .put("todayOrder", todayOrder).put("todayHidden", todayHidden)
        .put("codeFontSize", codeFontSize).put("codeWrap", codeWrap)
        .put("plannerView", plannerView)

    fun restore(o: JSONObject) {
        updateThemeMode(o.optInt("themeMode", themeMode))
        updateLightTheme(o.optString("lightTheme", lightTheme))
        updateDarkTheme(o.optString("darkTheme", darkTheme))
        updateDynamic(o.optBoolean("dynamic", dynamic))
        updateAccent(o.optInt("accent", accent))
        updateRedOne(o.optBoolean("redOne", redOne))
        updateTodayOrder(o.optString("todayOrder", todayOrder))
        updateTodayHidden(o.optString("todayHidden", todayHidden))
        updateCodeFontSize(o.optInt("codeFontSize", codeFontSize))
        updateCodeWrap(o.optBoolean("codeWrap", codeWrap))
        updatePlannerView(o.optInt("plannerView", plannerView))
    }
}
