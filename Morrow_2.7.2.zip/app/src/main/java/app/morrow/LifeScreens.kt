package app.morrow

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.animateFloat
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate

private val Plants = listOf("🌰", "🌱", "🌿", "🪴", "🌳")

@Composable
fun LifeScreen() {
    val section = UiState.lifeSection
    BackHandler(enabled = section.isNotEmpty()) { UiState.lifeSection = "" }
    when (section) {
        "habits" -> Section("Привычки", "Спокойный сад: растения растут сами") { HabitsBody() }
        "journal" -> Section("Дневник", "Записи хранятся только на телефоне") { JournalBody() }
        "projects" -> Section("Проекты", "Доска задач") { ProjectsBody() }
        "goals" -> Section("Цели", "На день, неделю, месяц, год") { GoalsBody() }
        "library" -> Section("Библиотека", "Книги, фильмы, музыка, игры") { LibraryBody() }
        "stats" -> Section("Статистика", "Без давления: просто взгляд назад") { StatsBody() }
        "search" -> Section("Поиск", "По всему Morrow") { SearchBody() }
        "sleep" -> Section("Сон", "Тихий режим на ночь") { SleepBody() }
        "focus" -> Section("Фокус", "Таймер без отвлечений") { FocusBody() }
        "countdown" -> Section("Отсчёт", "Сколько дней осталось") { CountdownBody() }
        "about" -> Section("О приложении", "Morrow") { AboutCard() }
        "profile" -> Section("Имя", "Для приветствия на главном экране") { ProfileBody() }
        "weather" -> Section("Погода", "Open-Meteo, без аккаунта") { WeatherBody() }
        else -> Hub()
    }
}

@Composable
private fun Hub() {
    val today = LocalDate.now().toEpochDay()
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenHeader("Life", "Всё остальное в одном месте")
        val doneToday = Life.habits.count { today in it.done }
        val items = listOf(
            Triple("focus", "🎧 Фокус", "Сегодня сессий: " + Life.focusLog.count { it == today }),
            Triple("countdown", "⏳ Отсчёт", "Событий: " + Life.countdowns.size),
            Triple("about", "ℹ️ О приложении", "Версия, авторы"),
            Triple("profile", "👤 Имя", if (Life.userName.isBlank()) "Как к тебе обращаться?" else Life.userName),
            Triple("habits", "🌱 Привычки", "Сегодня: $doneToday из ${Life.habits.size}"),
            Triple("journal", "📖 Дневник", "Записей: ${Life.journal.size}"),
            Triple("projects", "🗂 Проекты", "Проектов: ${Life.projects.size}"),
            Triple("goals", "🎯 Цели", "Не выполнено: ${Life.goals.count { !it.done }}"),
            Triple("library", "📚 Библиотека", "Позиций: ${Life.media.size}"),
            Triple("stats", "📊 Статистика", "Неделя, месяц, активность"),
            Triple("search", "🔎 Поиск", "Заметки, события, дневник, файлы"),
            Triple("weather", "🌤 Погода", Life.weather?.let { Weather.tempLabel(it.temp) + " · " + it.city } ?: "Выбери город"),
            Triple("sleep", "🌙 Сон", "Отбой " + fmtTime(Life.sleepBed) + ", подъём " + fmtTime(Life.sleepWake))
        )
        LaunchedEffect(Unit) {
            kotlinx.coroutines.delay(1200)
            UiState.hubAnimated = true
        }
        items.forEachIndexed { i, it ->
            Appear(i, UiState.hubAnimated) {
                MCard(onClick = { UiState.lifeSection = it.first }) {
                    Text(it.second, color = MaterialTheme.colorScheme.onSurface,
                        style = AppStyle(fontSize = 18.sp, fontWeight = FontWeight.Medium))
                    Hint(it.third)
                }
            }
        }
        MCard(onClick = { Nav.tab = "Themes" }) {
            Text("🎨 Темы", color = MaterialTheme.colorScheme.onSurface,
                style = AppStyle(fontSize = 18.sp, fontWeight = FontWeight.Medium))
            Hint("Палитры, Monet, акцент, Red One")
        }
        MCard(onClick = { Nav.route = Route.SettingsScreen }) {
            Text("⚙ Настройки", color = MaterialTheme.colorScheme.onSurface,
                style = AppStyle(fontSize = 18.sp, fontWeight = FontWeight.Medium))
            Hint("Резервные копии, экспорт, уведомления")
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun Section(title: String, subtitle: String, body: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        TextButton(onClick = { UiState.lifeSection = "" }) { Text("‹ Life") }
        ScreenHeader(title, subtitle)
        body()
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun FormDialog(
    title: String,
    onDismiss: () -> Unit,
    onSave: () -> Unit,
    onDelete: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                content()
            }
        },
        confirmButton = { TextButton(onClick = onSave) { Text("Сохранить") } },
        dismissButton = {
            Row {
                if (onDelete != null) {
                    IconButton(onClick = onDelete) { Icon(Icons.Rounded.Delete, contentDescription = "Удалить") }
                }
                TextButton(onClick = onDismiss) { Text("Отмена") }
            }
        }
    )
}

@Composable
private fun AddRow(label: String, onClick: () -> Unit) {
    FilledTonalButton(onClick = onClick) {
        Icon(Icons.Rounded.Add, contentDescription = null)
        Spacer(Modifier.width(6.dp))
        Text(label)
    }
}

// ------------------------------------------------------------------ habits

@Composable
private fun HabitsBody() {
    val today = LocalDate.now().toEpochDay()
    var edit by remember { mutableStateOf<Habit?>(null) }
    AddRow("Новая привычка") { edit = Habit(Repo.newId(), "", Swatches[0]) }
    if (Life.habits.isEmpty()) Hint("Пока пусто. Начни с одной маленькой привычки: вода, прогулка, чтение.")
    for (h in Life.habits.toList()) {
        MCard(onClick = { edit = h }) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(Plants[Life.stage(h)], fontSize = 30.sp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(h.name, color = MaterialTheme.colorScheme.onSurface,
                        style = AppStyle(fontSize = 16.sp, fontWeight = FontWeight.Medium))
                    Hint("Серия: ${Life.streak(h, today)} · неделя: ${Life.weekCount(h, today)}/${h.goalWeek} · всего: ${h.done.size}")
                }
                Checkbox(checked = today in h.done, onCheckedChange = { Life.toggleHabit(h.id, today) })
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                for (i in 6 downTo 0) {
                    val d = today - i
                    val on = d in h.done
                    Box(
                        Modifier.size(width = 28.dp, height = 8.dp)
                            .background(if (on) Color(h.color) else MaterialTheme.colorScheme.outlineVariant,
                                RoundedCornerShape(4.dp))
                    )
                }
            }
        }
    }
    val e = edit
    if (e != null) {
        var name by remember(e.id) { mutableStateOf(e.name) }
        var color by remember(e.id) { mutableStateOf(e.color) }
        var days by remember(e.id) { mutableStateOf(e.days) }
        var goal by remember(e.id) { mutableStateOf(e.goalWeek) }
        val exists = Life.habits.any { it.id == e.id }
        FormDialog(
            "Привычка", { edit = null },
            onSave = {
                if (name.isNotBlank()) {
                    Life.save(e.copy(name = name.trim(), color = color, days = days, goalWeek = goal))
                    edit = null
                }
            },
            onDelete = if (exists) ({ Life.removeHabit(e.id); edit = null }) else null
        ) {
            OutlinedTextField(name, { name = it }, label = { Text("Название") }, singleLine = true)
            SwatchPicker(color, { color = it })
            SmallLabel("Дни (пусто = каждый день)")
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                for (i in 0..6) {
                    FilterChip(
                        selected = (days shr i) and 1 == 1,
                        onClick = { days = days xor (1 shl i) },
                        label = { Text(DayNamesShort[i], fontSize = 11.sp) }
                    )
                }
            }
            SmallLabel("Цель на неделю: $goal")
            Slider(goal.toFloat(), { goal = it.toInt() }, valueRange = 1f..7f, steps = 5)
        }
    }
}

// ------------------------------------------------------------------ journal

@Composable
private fun JournalBody() {
    var query by remember { mutableStateOf("") }
    var edit by remember { mutableStateOf<JournalEntry?>(null) }
    var revealed by remember { mutableStateOf(setOf<Long>()) }
    val today = LocalDate.now().toEpochDay()
    AddRow("Новая запись") {
        val existing = Life.journal.firstOrNull { it.epochDay == today }
        edit = existing ?: JournalEntry(Repo.newId(), today, -1, "")
    }
    // mood strip for the last 14 days
    MCard {
        SmallLabel("Настроение · 14 дней")
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
            for (i in 13 downTo 0) {
                val m = Life.journal.firstOrNull { it.epochDay == today - i }?.mood ?: -1
                Text(if (m >= 0) MoodIcons[m] else "·", fontSize = 16.sp, modifier = Modifier.width(22.dp))
            }
        }
    }
    OutlinedTextField(query, { query = it }, label = { Text("Поиск по записям и тегам") },
        singleLine = true, modifier = Modifier.fillMaxWidth())
    val q = query.trim().lowercase()
    val list = Life.journal.sortedByDescending { it.epochDay }.filter {
        q.isEmpty() || it.tags.lowercase().contains(q) || (!it.priv && it.text.lowercase().contains(q))
    }
    if (list.isEmpty()) Hint("Записей нет. Одной строки в день достаточно.")
    var limit by remember { mutableIntStateOf(30) }
    for (j in list.take(limit)) {
        val hidden = j.priv && j.id !in revealed
        MCard(onClick = { edit = j }) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(if (j.mood >= 0) MoodIcons[j.mood] else "📝", fontSize = 22.sp)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(fmtLongDate(LocalDate.ofEpochDay(j.epochDay)), color = MaterialTheme.colorScheme.onSurface,
                        style = AppStyle(fontSize = 15.sp, fontWeight = FontWeight.Medium))
                    if (j.tags.isNotBlank()) Hint(j.tags)
                }
                if (j.priv) {
                    TextButton(onClick = { revealed = if (j.id in revealed) revealed - j.id else revealed + j.id }) {
                        Text(if (hidden) "Показать" else "Скрыть")
                    }
                }
            }
            if (!hidden && j.photo.isNotEmpty()) {
                Spacer(Modifier.height(6.dp))
                PhotoThumb(j.photo, 140)
            }
            Spacer(Modifier.height(4.dp))
            Text(
                if (hidden) "🔒 Приватная запись" else j.text,
                color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 4,
                style = AppStyle(fontSize = 14.sp)
            )
        }
    }
    if (list.size > limit) {
        TextButton(onClick = { limit += 30 }) { Text("Показать ещё (" + (list.size - limit) + ")") }
    }
    val e = edit
    if (e != null) {
        var text by remember(e.id) { mutableStateOf(e.text) }
        var tags by remember(e.id) { mutableStateOf(e.tags) }
        var mood by remember(e.id) { mutableStateOf(e.mood) }
        var day by remember(e.id) { mutableStateOf(e.epochDay) }
        var priv by remember(e.id) { mutableStateOf(e.priv) }
        var photo by remember(e.id) { mutableStateOf(e.photo) }
        val jctx = androidx.compose.ui.platform.LocalContext.current
        val photoPicker = androidx.activity.compose.rememberLauncherForActivityResult(
            androidx.activity.result.contract.ActivityResultContracts.OpenDocument()
        ) { uri ->
            if (uri != null) {
                try {
                    jctx.contentResolver.takePersistableUriPermission(
                        uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                } catch (_: Exception) {
                }
                photo = uri.toString()
            }
        }
        var pick by remember { mutableStateOf(false) }
        val exists = Life.journal.any { it.id == e.id }
        FormDialog(
            "Запись", { edit = null },
            onSave = {
                Life.save(e.copy(epochDay = day, mood = mood, text = text, tags = tags.trim(), priv = priv, photo = photo))
                edit = null
            },
            onDelete = if (exists) ({ Life.removeJournal(e.id); edit = null }) else null
        ) {
            OutlinedButton(onClick = { pick = true }) { Text(fmtLongDate(LocalDate.ofEpochDay(day))) }
            SmallLabel("Настроение")
            ChipRow(Moods.mapIndexed { i, s -> MoodIcons[i] + " " + s }, mood) { mood = if (mood == it) -1 else it }
            OutlinedTextField(text, { text = it }, label = { Text("Как прошёл день") }, minLines = 5,
                modifier = Modifier.fillMaxWidth())
            OutlinedTextField(tags, { tags = it }, label = { Text("Теги через пробел") }, singleLine = true)
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { photoPicker.launch(arrayOf("image/*")) }) {
                    Text(if (photo.isEmpty()) "Добавить фото" else "Заменить фото")
                }
                if (photo.isNotEmpty()) TextButton(onClick = { photo = "" }) { Text("Убрать") }
            }
            if (photo.isNotEmpty()) PhotoThumb(photo, 160)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Приватная", Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurface)
                Switch(priv, { priv = it })
            }
        }
        if (pick) DatePickerDialogM(day, { pick = false }) { day = it; pick = false }
    }
}

// ------------------------------------------------------------------ projects

@Composable
private fun ProjectsBody() {
    var edit by remember { mutableStateOf<Project?>(null) }
    val open = UiState.openProject
    val proj = Life.projects.firstOrNull { it.id == open }
    if (proj == null) {
        AddRow("Новый проект") { edit = Project(Repo.newId(), "", "", Swatches[1]) }
        if (Life.projects.isEmpty()) Hint("Проектов нет. Создай первый и разбей его на задачи.")
        for (p in Life.projects.toList()) {
            val ts = Life.ptasks.filter { it.projectId == p.id }
            val done = ts.count { it.status == 2 }
            MCard(onClick = { UiState.openProject = p.id }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    ColorDot(p.color)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(p.name, color = MaterialTheme.colorScheme.onSurface,
                            style = AppStyle(fontSize = 17.sp, fontWeight = FontWeight.Medium))
                        if (p.desc.isNotBlank()) Hint(p.desc)
                    }
                    Text("$done/${ts.size}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Spacer(Modifier.height(8.dp))
                LinearProgressIndicator(
                    progress = { if (ts.isEmpty()) 0f else done.toFloat() / ts.size },
                    modifier = Modifier.fillMaxWidth(), color = Color(p.color)
                )
                if (p.deadline >= 0) Hint("Дедлайн: " + fmtDayMonth(LocalDate.ofEpochDay(p.deadline)))
            }
        }
    } else {
        var newTask by remember { mutableStateOf("") }
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { UiState.openProject = -1L }) { Text("‹ Проекты") }
            Spacer(Modifier.weight(1f))
            TextButton(onClick = { edit = proj }) { Text("Изменить") }
        }
        Text(proj.name, color = MaterialTheme.colorScheme.onBackground,
            style = AppStyle(fontSize = 22.sp, fontWeight = FontWeight.Medium))
        if (proj.desc.isNotBlank()) Hint(proj.desc)
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(newTask, { newTask = it }, label = { Text("Новая задача") },
                singleLine = true, modifier = Modifier.weight(1f))
            FilledTonalButton(onClick = {
                if (newTask.isNotBlank()) {
                    Life.save(PTask(Repo.newId(), proj.id, newTask.trim(), 0))
                    newTask = ""
                }
            }) { Text("+") }
        }
        Hint("Свайп карточки вправо или влево двигает её между колонками.")
        for (st in 0..2) {
            val col = Life.ptasks.filter { it.projectId == proj.id && it.status == st }
            SmallLabel(TaskStatuses[st] + " · " + col.size)
            if (col.isEmpty()) Hint("—")
            for (t in col) {
                MCard(
                    modifier = Modifier.pointerInput(t.id, t.status) {
                        var dx = 0f
                        detectHorizontalDragGestures(
                            onDragStart = { dx = 0f },
                            onDragEnd = {
                                if (dx > 140f && t.status < 2) Life.save(t.copy(status = t.status + 1))
                                else if (dx < -140f && t.status > 0) Life.save(t.copy(status = t.status - 1))
                            },
                            onHorizontalDrag = { _, d -> dx += d }
                        )
                    },
                    padding = 10.dp
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        TextButton(onClick = { Life.save(t.copy(status = t.status - 1)) }, enabled = st > 0) { Text("←") }
                        Text(t.title, Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurface)
                        TextButton(onClick = { Life.save(t.copy(status = t.status + 1)) }, enabled = st < 2) { Text("→") }
                        IconButton(onClick = { Life.removeTask(t.id) }) {
                            Icon(Icons.Rounded.Delete, contentDescription = "Удалить")
                        }
                    }
                }
            }
        }
    }
    val e = edit
    if (e != null) {
        var name by remember(e.id) { mutableStateOf(e.name) }
        var desc by remember(e.id) { mutableStateOf(e.desc) }
        var color by remember(e.id) { mutableStateOf(e.color) }
        var deadline by remember(e.id) { mutableStateOf(e.deadline) }
        var pick by remember { mutableStateOf(false) }
        val exists = Life.projects.any { it.id == e.id }
        FormDialog(
            "Проект", { edit = null },
            onSave = {
                if (name.isNotBlank()) {
                    Life.save(e.copy(name = name.trim(), desc = desc.trim(), color = color, deadline = deadline))
                    edit = null
                }
            },
            onDelete = if (exists) ({ Life.removeProject(e.id); UiState.openProject = -1L; edit = null }) else null
        ) {
            OutlinedTextField(name, { name = it }, label = { Text("Название") }, singleLine = true)
            OutlinedTextField(desc, { desc = it }, label = { Text("Описание") })
            SwatchPicker(color, { color = it })
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedButton(onClick = { pick = true }) {
                    Text(if (deadline >= 0) "Дедлайн: " + fmtDayMonth(LocalDate.ofEpochDay(deadline)) else "Без дедлайна")
                }
                if (deadline >= 0) TextButton(onClick = { deadline = -1L }) { Text("Сбросить") }
            }
        }
        if (pick) DatePickerDialogM(if (deadline >= 0) deadline else LocalDate.now().toEpochDay(), { pick = false }) {
            deadline = it; pick = false
        }
    }
}

// ------------------------------------------------------------------ goals

@Composable
private fun GoalsBody() {
    var edit by remember { mutableStateOf<Goal?>(null) }
    AddRow("Новая цель") { edit = Goal(Repo.newId(), "", 0) }
    if (Life.goals.isEmpty()) Hint("Целей нет. Хватит одной на неделю.")
    for (p in GoalPeriods.indices) {
        val gs = Life.goals.filter { it.period == p }
        if (gs.isEmpty()) continue
        SmallLabel(GoalPeriods[p] + " · " + gs.count { it.done } + "/" + gs.size)
        for (g in gs) {
            MCard(padding = 10.dp, onClick = { edit = g }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(g.done, { Life.save(g.copy(done = it)) })
                    Text(g.title, color = MaterialTheme.colorScheme.onSurface)
                }
            }
        }
    }
    val e = edit
    if (e != null) {
        var title by remember(e.id) { mutableStateOf(e.title) }
        var period by remember(e.id) { mutableStateOf(e.period) }
        val exists = Life.goals.any { it.id == e.id }
        FormDialog(
            "Цель", { edit = null },
            onSave = {
                if (title.isNotBlank()) { Life.save(e.copy(title = title.trim(), period = period)); edit = null }
            },
            onDelete = if (exists) ({ Life.removeGoal(e.id); edit = null }) else null
        ) {
            OutlinedTextField(title, { title = it }, label = { Text("Цель") })
            ChipRow(GoalPeriods, period) { period = it }
        }
    }
}

// ------------------------------------------------------------------ library

@Composable
private fun LibraryBody() {
    var filter by remember { mutableStateOf(-1) }
    var edit by remember { mutableStateOf<MediaItem?>(null) }
    AddRow("Добавить") { edit = MediaItem(Repo.newId(), if (filter >= 0) filter else 0, "") }
    ChipRow(listOf("Все") + MediaKinds, filter + 1) { filter = it - 1 }
    val list = Life.media.filter { filter < 0 || it.kind == filter }
    if (list.isEmpty()) Hint("Здесь будут книги, фильмы, музыка и игры с твоими оценками.")
    for (m in list) {
        MCard(onClick = { edit = m }) {
            Text(m.title, color = MaterialTheme.colorScheme.onSurface,
                style = AppStyle(fontSize = 16.sp, fontWeight = FontWeight.Medium))
            Hint(MediaKinds[m.kind] + " · " + MediaStatuses[m.status] +
                (if (m.author.isNotBlank()) " · " + m.author else "") +
                (if (m.rating > 0) " · " + "★".repeat(m.rating) else ""))
            if (m.note.isNotBlank()) Text(m.note, color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 2, style = AppStyle(fontSize = 13.sp))
        }
    }
    val e = edit
    if (e != null) {
        var title by remember(e.id) { mutableStateOf(e.title) }
        var author by remember(e.id) { mutableStateOf(e.author) }
        var kind by remember(e.id) { mutableStateOf(e.kind) }
        var status by remember(e.id) { mutableStateOf(e.status) }
        var rating by remember(e.id) { mutableStateOf(e.rating) }
        var note by remember(e.id) { mutableStateOf(e.note) }
        val exists = Life.media.any { it.id == e.id }
        FormDialog(
            "Позиция", { edit = null },
            onSave = {
                if (title.isNotBlank()) {
                    Life.save(e.copy(kind = kind, title = title.trim(), author = author.trim(),
                        status = status, rating = rating, note = note))
                    edit = null
                }
            },
            onDelete = if (exists) ({ Life.removeMedia(e.id); edit = null }) else null
        ) {
            ChipRow(MediaKinds, kind) { kind = it }
            OutlinedTextField(title, { title = it }, label = { Text("Название") }, singleLine = true)
            OutlinedTextField(author, { author = it }, label = { Text("Автор / студия") }, singleLine = true)
            ChipRow(MediaStatuses, status) { status = it }
            SmallLabel("Рейтинг: $rating")
            Slider(rating.toFloat(), { rating = it.toInt() }, valueRange = 0f..5f, steps = 4)
            OutlinedTextField(note, { note = it }, label = { Text("Впечатления") }, minLines = 3)
        }
    }
}

// ------------------------------------------------------------------ stats

@Composable
private fun StatsBody() {
    val today = LocalDate.now().toEpochDay()
    val cs = MaterialTheme.colorScheme
    MCard {
        SmallLabel("Привычки · 7 дней")
        val counts = (6 downTo 0).map { i -> Life.habits.count { (today - i) in it.done } }
        BarChart(counts, Life.habits.size.coerceAtLeast(1), cs.primary, cs.outlineVariant)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            for (i in 6 downTo 0) {
                val d = LocalDate.ofEpochDay(today - i)
                Text(DayNamesShort[d.dayOfWeek.value - 1], fontSize = 10.sp, color = cs.onSurfaceVariant)
            }
        }
    }
    MCard {
        SmallLabel("Активность · 5 недель")
        Spacer(Modifier.height(6.dp))
        val monday = today - (LocalDate.ofEpochDay(today).dayOfWeek.value - 1)
        for (w in 4 downTo 0) {
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.padding(vertical = 2.dp)) {
                for (d in 0..6) {
                    val day = monday - w * 7 + d
                    val n = Life.habits.count { day in it.done } +
                        Repo.events.count { it.epochDay == day && it.done } +
                        Life.journal.count { it.epochDay == day }
                    val a = when { day > today -> 0.05f; n == 0 -> 0.12f; n == 1 -> 0.4f; n == 2 -> 0.65f; else -> 1f }
                    Box(Modifier.size(34.dp).background(cs.primary.copy(alpha = a), RoundedCornerShape(6.dp)))
                }
            }
        }
    }
    MCard {
        SmallLabel("Сводка")
        Spacer(Modifier.height(6.dp))
        val moods = Life.journal.filter { it.epochDay > today - 30 && it.mood >= 0 }
        val top = moods.groupBy { it.mood }.maxByOrNull { it.value.size }?.key
        val lines = listOf(
            "Выполненных событий: " + Repo.events.count { it.done },
            "Заметок: " + Repo.notes.count { it.trashedAt == 0L },
            "Задач проектов закрыто: " + Life.ptasks.count { it.status == 2 } + " из " + Life.ptasks.size,
            "Целей выполнено: " + Life.goals.count { it.done } + " из " + Life.goals.size,
            "Прочитано/просмотрено: " + Life.media.count { it.status == 2 },
            "Частое настроение за 30 дней: " + (if (top != null) MoodIcons[top] + " " + Moods[top] else "нет данных")
        )
        for (l in lines) Text(l, color = cs.onSurface, modifier = Modifier.padding(vertical = 2.dp))
    }
    Hint("Статистика нужна, чтобы увидеть картину, а не чтобы себя подгонять.")
}

@Composable
private fun BarChart(values: List<Int>, max: Int, bar: Color, track: Color) {
    Canvas(Modifier.fillMaxWidth().height(90.dp).padding(vertical = 6.dp)) {
        val n = values.size
        val gap = 10.dp.toPx()
        val w = (size.width - gap * (n - 1)) / n
        for (i in 0 until n) {
            val x = i * (w + gap)
            drawRoundRect(track, Offset(x, 0f), Size(w, size.height), CornerRadius(6.dp.toPx()))
            val h = size.height * values[i].toFloat() / max
            if (h > 0f) drawRoundRect(bar, Offset(x, size.height - h), Size(w, h), CornerRadius(6.dp.toPx()))
        }
    }
}

// ------------------------------------------------------------------ search

@Composable
private fun SearchBody() {
    var q by remember { mutableStateOf("") }
    MCard {
        SmallLabel("Сводка дня")
        Spacer(Modifier.height(4.dp))
        Text(LocalAssistant.daySummary(), color = MaterialTheme.colorScheme.onSurface)
    }
    OutlinedTextField(q, { q = it }, label = { Text("Что ищем?") }, singleLine = true,
        modifier = Modifier.fillMaxWidth())
    val s = q.trim().lowercase()
    if (s.length < 2) { Hint("Введи хотя бы два символа."); return }
    fun has(t: String) = t.lowercase().contains(s)
    @Composable
    fun Hit(kind: String, title: String, onClick: () -> Unit) {
        MCard(padding = 12.dp, onClick = onClick) {
            Hint(kind)
            Text(title, color = MaterialTheme.colorScheme.onSurface, maxLines = 2)
        }
    }
    var count = 0
    for (n in Repo.notes) if (n.trashedAt == 0L && (has(n.title) || has(n.body))) {
        count++; Hit("Заметка", n.title.ifBlank { "Без названия" }) { Nav.route = Route.NoteEdit(n.id) }
    }
    for (e in Repo.events) if (has(e.title) || has(e.description)) {
        count++; Hit("Событие · " + fmtDayMonth(e.date), e.title) { Nav.route = Route.EventEdit(e.id, e.epochDay) }
    }
    for (j in Life.journal) if (has(j.tags) || (!j.priv && has(j.text))) {
        count++; Hit("Дневник · " + fmtDayMonth(LocalDate.ofEpochDay(j.epochDay)), if (j.priv) "🔒 Приватная запись" else j.text) {
            UiState.lifeSection = "journal"
        }
    }
    for (p in Life.projects) if (has(p.name) || has(p.desc)) {
        count++; Hit("Проект", p.name) { UiState.openProject = p.id; UiState.lifeSection = "projects" }
    }
    for (t in Life.ptasks) if (has(t.title)) {
        count++; Hit("Задача · " + TaskStatuses[t.status], t.title) { UiState.openProject = t.projectId; UiState.lifeSection = "projects" }
    }
    for (h in Life.habits) if (has(h.name)) {
        count++; Hit("Привычка", h.name) { UiState.lifeSection = "habits" }
    }
    for (m in Life.media) if (has(m.title) || has(m.author) || has(m.note)) {
        count++; Hit(MediaKinds[m.kind], m.title) { UiState.lifeSection = "library" }
    }
    for (c in Repo.codeFiles) if (has(c.name)) {
        count++; Hit("Файл кода", c.name) { Nav.route = Route.CodeEdit(c.id) }
    }
    if (count == 0) Hint("Ничего не найдено.")
}

// ------------------------------------------------------------------ sleep

@Composable
private fun SleepBody() {
    var pickBed by remember { mutableStateOf(false) }
    var pickWake by remember { mutableStateOf(false) }
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val cs = MaterialTheme.colorScheme
    MCard {
        SmallLabel("Расписание")
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedButton(onClick = { pickBed = true }) { Text("Отбой " + fmtTime(Life.sleepBed)) }
            OutlinedButton(onClick = { pickWake = true }) { Text("Подъём " + fmtTime(Life.sleepWake)) }
        }
        val mins = ((Life.sleepWake - Life.sleepBed) + 1440) % 1440
        Spacer(Modifier.height(6.dp))
        Hint("Длительность сна: " + fmtDuration(mins))
        Spacer(Modifier.height(8.dp))
        SmallLabel("Подготовка ко сну за " + Life.sleepRemind + " мин")
        Slider(Life.sleepRemind.toFloat(), { Life.sleepRemind = it.toInt() }, valueRange = 0f..90f, steps = 5,
            onValueChangeFinished = { Repo.saveNow(); Automation.schedule(ctx) })
        if (isBedtimeSoon()) {
            Text("🌙 Пора готовиться ко сну: экраны вниз, свет приглушить.", color = cs.primary)
        }
    }
    MCard {
        SmallLabel("Автоматизация")
        Spacer(Modifier.height(6.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Вечерняя подготовка", color = cs.onSurface)
                Hint("Уведомление за " + Life.sleepRemind + " мин до отбоя (" + fmtTime(Life.sleepBed) +
                    "). По нажатию включается режим сна.")
            }
            Switch(Life.autoBedtime, { Life.autoBedtime = it; Repo.saveNow(); Automation.schedule(ctx) })
        }
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Утренняя сводка", color = cs.onSurface)
                Hint("В " + fmtTime(Life.sleepWake) + " приходит уведомление: события, привычки, задачи.")
            }
            Switch(Life.autoMorning, { Life.autoMorning = it; Repo.saveNow(); Automation.schedule(ctx) })
        }
    }
    MCard {
        Text("Режим сна", color = cs.onSurface, style = AppStyle(fontSize = 16.sp, fontWeight = FontWeight.Medium))
        Hint("Тёмный экран с часами, без уведомлений внутри Morrow. Будильники продолжают работать.")
        Spacer(Modifier.height(8.dp))
        Button(onClick = { UiState.sleepOn = true }) { Text("Включить") }
    }
    if (pickBed) TimePickerDialogM(Life.sleepBed / 60, Life.sleepBed % 60, { pickBed = false }) { h, m ->
        Life.sleepBed = h * 60 + m; Repo.saveNow(); Automation.schedule(ctx); pickBed = false
    }
    if (pickWake) TimePickerDialogM(Life.sleepWake / 60, Life.sleepWake % 60, { pickWake = false }) { h, m ->
        Life.sleepWake = h * 60 + m; Repo.saveNow(); Automation.schedule(ctx); pickWake = false
    }
}

private fun isBedtimeSoon(): Boolean {
    val now = java.time.LocalTime.now()
    val cur = now.hour * 60 + now.minute
    val diff = (Life.sleepBed - cur + 1440) % 1440
    return diff <= Life.sleepRemind && Life.sleepRemind > 0
}

@Composable
fun SleepOverlay(onExit: () -> Unit) {
    BackHandler { onExit() }
    val view = androidx.compose.ui.platform.LocalView.current
    DisposableEffect(Unit) {
        view.keepScreenOn = true
        onDispose { view.keepScreenOn = false }
    }
    var now by remember { mutableStateOf(java.time.LocalTime.now()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = java.time.LocalTime.now()
            kotlinx.coroutines.delay(15_000)
        }
    }
    val dim = Color(0xFF8A9A90)
    Column(
        Modifier.fillMaxSize().background(Color.Black).systemBarsPadding().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(fmtTime(now.hour * 60 + now.minute), color = dim, style = AppStyle(fontSize = 72.sp, fontWeight = FontWeight.ExtraLight))
        Spacer(Modifier.height(8.dp))
        val next = Scheduler.nextAlarm()
        Text(
            if (next != null) "Будильник: " + fmtTime(next.first.hour * 60 + next.first.minute)
            else "Подъём по плану: " + fmtTime(Life.sleepWake),
            color = dim
        )
        Spacer(Modifier.height(48.dp))
        OutlinedButton(onClick = onExit) { Text("Выйти из режима сна", color = dim) }
    }
}

@Composable
private fun PhotoThumb(uriString: String, heightDp: Int) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val bmp by produceState<androidx.compose.ui.graphics.ImageBitmap?>(ThumbCache.get(uriString), uriString) {
        if (value != null) return@produceState
        value = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            try {
                val uri = android.net.Uri.parse(uriString)
                val bounds = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
                ctx.contentResolver.openInputStream(uri)?.use { android.graphics.BitmapFactory.decodeStream(it, null, bounds) }
                var sample = 1
                while (bounds.outWidth / sample > 720) sample *= 2
                val opts = android.graphics.BitmapFactory.Options().apply { inSampleSize = sample }
                val decoded = ctx.contentResolver.openInputStream(uri)?.use {
                    android.graphics.BitmapFactory.decodeStream(it, null, opts)?.asImageBitmap()
                }
                if (decoded != null) ThumbCache.put(uriString, decoded)
                decoded
            } catch (_: Exception) {
                null
            }
        }
    }
    val b = bmp
    if (b != null) {
        androidx.compose.foundation.Image(
            bitmap = b,
            contentDescription = "Фото",
            contentScale = androidx.compose.ui.layout.ContentScale.Crop,
            modifier = Modifier.fillMaxWidth().height(heightDp.dp).clip(RoundedCornerShape(12.dp))
        )
    } else {
        Hint("Фото недоступно")
    }
}

/** Soft falling rain drawn above the Today tab. Purely decorative. */
@Composable
fun RainOverlay() {
    val transition = androidx.compose.animation.core.rememberInfiniteTransition(label = "rain")
    val t by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = androidx.compose.animation.core.infiniteRepeatable(
            androidx.compose.animation.core.tween(1400, easing = androidx.compose.animation.core.LinearEasing)
        ),
        label = "rainT"
    )
    val color = MaterialTheme.colorScheme.primary.copy(alpha = 0.22f)
    Canvas(Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        val len = 16.dp.toPx()
        for (i in 0 until 70) {
            val x = ((i * 37) % 100) / 100f * w
            val speed = 0.7f + ((i * 13) % 10) / 20f
            val y = (((t * speed) + i * 0.137f) % 1f) * (h + len) - len
            drawLine(color, Offset(x, y), Offset(x - len * 0.25f, y + len), strokeWidth = 1.5.dp.toPx())
        }
    }
}

@Composable
private fun WeatherBody() {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var city by remember { mutableStateOf(Life.weatherCity) }
    var status by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    val w = Life.weather
    MCard {
        SmallLabel("Город")
        Spacer(Modifier.height(6.dp))
        OutlinedTextField(city, { city = it }, label = { Text("Например, Москва") }, singleLine = true,
            modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        Button(
            enabled = city.isNotBlank() && !loading,
            onClick = {
                loading = true
                status = ""
                Life.weatherCity = city.trim()
                Weather.refresh(ctx, city) { err ->
                    loading = false
                    status = err ?: "Обновлено"
                    Repo.saveNow()
                }
            }
        ) { Text(if (loading) "Загружаю…" else "Показать погоду") }
        if (status.isNotEmpty()) Hint(status)
    }
    if (w != null) {
        MCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(Weather.icon(w.code), fontSize = 44.sp)
                Spacer(Modifier.width(14.dp))
                Column {
                    Text(Weather.tempLabel(w.temp) + " · " + Weather.text(w.code),
                        color = MaterialTheme.colorScheme.onSurface,
                        style = AppStyle(fontSize = 22.sp, fontWeight = FontWeight.Medium))
                    Hint(w.city + ", сегодня " + Weather.tempLabel(w.min) + "…" + Weather.tempLabel(w.max))
                    Hint("Обновлено " + fmtStamp(w.updated))
                }
            }
        }
    }
    Hint("Наружу уходят только название города и его координаты. Данные Morrow остаются на телефоне.")
}

@Composable
private fun ProfileBody() {
    var name by remember { mutableStateOf(Life.userName) }
    MCard {
        OutlinedTextField(name, { name = it.take(30) }, label = { Text("Твоё имя") }, singleLine = true,
            modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        Hint("Приветствие: " + greetingFor(java.time.LocalTime.now().hour) +
            (if (name.isNotBlank()) ", " + name.trim() else ""))
        Spacer(Modifier.height(8.dp))
        Button(onClick = {
            Life.userName = name.trim()
            Repo.saveNow()
            UiState.greeted = false
        }) { Text("Сохранить") }
    }
    Hint("Имя хранится только на телефоне.")
}

// ------------------------------------------------------------------ focus

@Composable
private fun FocusBody() {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val haptic = androidx.compose.ui.platform.LocalHapticFeedback.current
    val today = LocalDate.now().toEpochDay()
    var minutes by remember { mutableStateOf(25) }
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    val end = UiState.focusEnd
    val running = end > 0L && now < end
    LaunchedEffect(end) {
        while (true) {
            now = System.currentTimeMillis()
            val e = UiState.focusEnd
            if (e > 0L && now >= e) {
                UiState.focusEnd = 0L
                Life.focusLog.add(today)
                Repo.saveLater()
                UiSounds.done()
                haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.LongPress)
                break
            }
            kotlinx.coroutines.delay(250)
        }
    }
    val cs = MaterialTheme.colorScheme
    MCard {
        val left = if (running) ((end - now) / 1000L).toInt().coerceAtLeast(0) else minutes * 60
        Text(
            pad2(left / 60) + ":" + pad2(left % 60),
            color = cs.onSurface,
            modifier = Modifier.fillMaxWidth(),
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            style = AppStyle(fontSize = 64.sp, fontWeight = FontWeight.ExtraLight)
        )
        Spacer(Modifier.height(8.dp))
        if (!running) {
            ChipRow(listOf("15 мин", "25 мин", "45 мин", "60 мин"), listOf(15, 25, 45, 60).indexOf(minutes)) {
                minutes = listOf(15, 25, 45, 60)[it]
            }
            Spacer(Modifier.height(10.dp))
            Button(onClick = {
                val e = System.currentTimeMillis() + minutes * 60_000L
                UiState.focusEnd = e
                Automation.scheduleFocus(ctx, e)
            }) { Text("Начать") }
        } else {
            OutlinedButton(onClick = {
                UiState.focusEnd = 0L
                Automation.cancelFocus(ctx)
            }) { Text("Остановить") }
        }
    }
    Hint("Сегодня завершено сессий: " + Life.focusLog.count { it == today } +
        ". Когда время выйдет, придёт уведомление, даже если приложение закрыто.")
}

// ------------------------------------------------------------------ countdown

@Composable
private fun CountdownBody() {
    var edit by remember { mutableStateOf<Countdown?>(null) }
    val today = LocalDate.now().toEpochDay()
    AddRow("Новый отсчёт") { edit = Countdown(Repo.newId(), "", today + 7) }
    if (Life.countdowns.isEmpty()) Hint("День рождения, отпуск, дедлайн — добавь дату и смотри, сколько осталось.")
    for (c in Life.countdowns.sortedBy { it.epochDay }) {
        val d = c.epochDay - today
        MCard(onClick = { edit = c }) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(c.title, color = MaterialTheme.colorScheme.onSurface,
                        style = AppStyle(fontSize = 16.sp, fontWeight = FontWeight.Medium))
                    Hint(fmtLongDate(LocalDate.ofEpochDay(c.epochDay)))
                }
                Text(
                    when {
                        d == 0L -> "Сегодня"
                        d > 0 -> "$d дн."
                        else -> "прошло " + (-d) + " дн."
                    },
                    color = MaterialTheme.colorScheme.primary,
                    style = AppStyle(fontSize = 20.sp, fontWeight = FontWeight.Medium)
                )
            }
        }
    }
    val e = edit
    if (e != null) {
        var title by remember(e.id) { mutableStateOf(e.title) }
        var day by remember(e.id) { mutableStateOf(e.epochDay) }
        var pick by remember { mutableStateOf(false) }
        val exists = Life.countdowns.any { it.id == e.id }
        FormDialog(
            "Отсчёт", { edit = null },
            onSave = {
                if (title.isNotBlank()) { Life.save(e.copy(title = title.trim(), epochDay = day)); edit = null }
            },
            onDelete = if (exists) ({ Life.removeCountdown(e.id); edit = null }) else null
        ) {
            OutlinedTextField(title, { title = it }, label = { Text("Название") }, singleLine = true)
            OutlinedButton(onClick = { pick = true }) { Text(fmtLongDate(LocalDate.ofEpochDay(day))) }
        }
        if (pick) DatePickerDialogM(day, { pick = false }) { day = it; pick = false }
    }
}

/** About card: version, credits, what the app is. Used in Life and in Settings. */
@Composable
fun AboutCard() {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val cs = MaterialTheme.colorScheme
    val version = try {
        ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: ""
    } catch (_: Exception) {
        ""
    }
    MCard {
        Row(verticalAlignment = Alignment.Bottom) {
            Text("morrow", color = cs.onSurface, style = AppStyle(fontSize = 34.sp, fontWeight = FontWeight.Light))
            Text(
                "1", color = Color(0xFFE5192B),
                modifier = Modifier.padding(start = 3.dp, bottom = 2.dp),
                style = AppStyle(fontSize = 24.sp, fontWeight = FontWeight.Bold)
            )
        }
        Spacer(Modifier.height(2.dp))
        Hint("Версия $version")
        Spacer(Modifier.height(10.dp))
        Text(
            "Уютный органайзер в духе OnePlus и Pacific Northwest: календарь, заметки, привычки, дневник, " +
                "проекты, будильники, редактор кода и темы.",
            color = cs.onSurface, style = AppStyle(fontSize = 14.sp)
        )
    }
    MCard {
        SmallLabel("Авторы")
        Spacer(Modifier.height(8.dp))
        Text(
            "Разработано Alte Alissen из компании Anora Tears и Claude by Anthropic.",
            color = cs.onSurface,
            style = AppStyle(fontSize = 16.sp, fontWeight = FontWeight.Medium)
        )
        Spacer(Modifier.height(10.dp))
        Hint("Kotlin · Jetpack Compose · Material 3")
        Hint("Все данные хранятся только на твоём устройстве. Наружу уходит лишь запрос погоды, если ты её включил.")
    }
}

/** Small in-memory cache so scrolling the journal does not decode the same photos again. */
private object ThumbCache {
    private val cache = android.util.LruCache<String, androidx.compose.ui.graphics.ImageBitmap>(16)
    fun get(k: String): androidx.compose.ui.graphics.ImageBitmap? = cache.get(k)
    fun put(k: String, v: androidx.compose.ui.graphics.ImageBitmap) { cache.put(k, v) }
}
