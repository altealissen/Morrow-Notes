package app.morrow

import android.Manifest
import android.app.Application
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Alarm
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.Code
import androidx.compose.material.icons.rounded.EditNote
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Spa
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.TextButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.sp
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import java.time.LocalDate

class MorrowApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        Prefs.load(this)
        Repo.init(this)
        AppFont.loadCustom(this)
        Scheduler.ensureChannels(this)
    }
}

sealed class Route {
    object Home : Route()
    data class EventEdit(val id: Long, val epochDay: Long) : Route()
    data class NoteEdit(val id: Long) : Route()
    data class AlarmEdit(val id: Long) : Route()
    data class CodeEdit(val id: Long) : Route()
    object SettingsScreen : Route()
}

/** Very small navigation state: the selected tab plus an optional full screen route. */
object Nav {
    var tab by mutableStateOf("Today")
    var route: Route by mutableStateOf<Route>(Route.Home)
    fun home() {
        route = Route.Home
    }
}

/** UI state that should survive switching between tabs and editors. */
object UiState {
    var plannerDay by mutableLongStateOf(LocalDate.now().toEpochDay())
    var plannerMonthDay by mutableLongStateOf(LocalDate.now().withDayOfMonth(1).toEpochDay())
    var notesQuery by mutableStateOf("")
    var notesSort by mutableStateOf(0)
    var lifeSection by mutableStateOf("")
    var sleepOn by mutableStateOf(false)
    var greeted by mutableStateOf(false)
    var focusEnd by mutableLongStateOf(0L)
    var todayAnimated by mutableStateOf(false)
    var hubAnimated by mutableStateOf(false)
    val codeTabs = androidx.compose.runtime.mutableStateListOf<Long>()
    var openProject by mutableLongStateOf(-1L)
    var notesFilter by mutableLongStateOf(0L)   // 0 = all, -1 = trash, otherwise category id
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        askNotificationPermissionOnce()
        handleIntent(intent)
        setContent {
            MorrowTheme {
                MorrowRoot()
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    override fun dispatchTouchEvent(ev: android.view.MotionEvent?): Boolean {
        RefreshRate.touch(this)
        return super.dispatchTouchEvent(ev)
    }

    override fun onResume() {
        super.onResume()
        RefreshRate.update(this)
        Repo.rollRecurring()
        Weather.refreshIfStale(applicationContext)
    }

    override fun onPause() {
        RefreshRate.stop()
        Repo.saveNow()

        super.onPause()
    }

    private fun handleIntent(i: Intent?) {
        if (i?.action == Intent.ACTION_SEND && (i.type ?: "").startsWith("text/")) {
            val text = i.getStringExtra(Intent.EXTRA_TEXT) ?: ""
            val subject = i.getStringExtra(Intent.EXTRA_SUBJECT) ?: ""
            i.action = Intent.ACTION_MAIN
            if (text.isNotBlank() || subject.isNotBlank()) {
                val n = Repo.newNote(0L, text)
                if (subject.isNotBlank()) Repo.updateNote(n.id) { it.copy(title = subject.take(80)) }
                Nav.tab = "Notes"
                Nav.route = Route.NoteEdit(n.id)
                return
            }
        }
        val quick = i?.getStringExtra("quick")
        if (quick != null) i?.removeExtra("quick")
        when (quick) {
            "note" -> {
                val n = Repo.newNote()
                Nav.tab = "Notes"
                Nav.route = Route.NoteEdit(n.id)
                return
            }
            "event" -> {
                Nav.tab = "Planner"
                Nav.route = Route.EventEdit(0L, LocalDate.now().toEpochDay())
                return
            }
            "alarm" -> {
                Nav.tab = "Alarm"
                Nav.route = Route.AlarmEdit(0L)
                return
            }
            "sleep" -> {
                Nav.tab = "Life"
                Nav.route = Route.Home
                UiState.sleepOn = true
                return
            }
            "habits" -> {
                Nav.tab = "Life"
                UiState.lifeSection = "habits"
                Nav.route = Route.Home
                return
            }
        }
        val tab = i?.getStringExtra(Scheduler.EXTRA_TAB) ?: return
        Nav.tab = tab
        Nav.route = Route.Home
    }

    private fun askNotificationPermissionOnce() {
        if (Build.VERSION.SDK_INT < 33) return
        if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) return
        val prefs = getSharedPreferences("morrow_flags", Context.MODE_PRIVATE)
        if (prefs.getBoolean("asked_notifications", false)) return
        prefs.edit().putBoolean("asked_notifications", true).apply()
        requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 81)
    }
}

@Composable
fun MorrowRoot() {
    val route = Nav.route
    BackHandler(enabled = route != Route.Home) { Nav.home() }
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var welcome by remember {
        mutableStateOf(
            try {
                !ctx.getSharedPreferences("morrow_flags", Context.MODE_PRIVATE).getBoolean("onboarded", false)
            } catch (_: Exception) { false }
        )
    }
    if (welcome) {
        WelcomeScreen { n ->
            Life.userName = n
            Repo.saveNow()
            try {
                ctx.getSharedPreferences("morrow_flags", Context.MODE_PRIVATE)
                    .edit().putBoolean("onboarded", true).apply()
            } catch (_: Exception) {
            }
            welcome = false
        }
        return
    }
    if (UiState.sleepOn) {
        SleepOverlay { UiState.sleepOn = false }
        return
    }
    Crossfade(targetState = route, animationSpec = tween(180), label = "route") { r ->
        when (r) {
            is Route.Home -> HomeScaffold()
            is Route.EventEdit -> EventEditor(r.id, r.epochDay) { Nav.home() }
            is Route.NoteEdit -> NoteEditor(r.id) { Nav.home() }
            is Route.AlarmEdit -> AlarmEditor(r.id) { Nav.home() }
            is Route.CodeEdit -> CodeEditor(r.id) { Nav.home() }
            is Route.SettingsScreen -> SettingsScreen { Nav.home() }
        }
    }
}

private class TabDef(val id: String, val icon: ImageVector)

@Composable
fun HomeScaffold() {
    val tabs = listOf(
        TabDef("Today", Icons.Rounded.Home),
        TabDef("Planner", Icons.Rounded.CalendarMonth),
        TabDef("Notes", Icons.Rounded.EditNote),
        TabDef("Alarm", Icons.Rounded.Alarm),
        TabDef("Code", Icons.Rounded.Code),
        TabDef("Life", Icons.Rounded.Spa)
    )
    BackHandler(enabled = Nav.tab == "Themes") { Nav.tab = "Life" }
    val haptic = LocalHapticFeedback.current
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                for (t in tabs) {
                    NavigationBarItem(
                        selected = Nav.tab == t.id,
                        onClick = {
                            if (Nav.tab != t.id) {
                                UiSounds.tap()
                                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            }
                            Nav.tab = t.id
                        },
                        icon = { Icon(t.icon, contentDescription = t.id) },
                        label = { Text(t.id, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Clip) }
                    )
                }
            }
        }
    ) { pad ->
        Box(
            Modifier
                .fillMaxSize()
                .padding(pad)
        ) {
            if (Life.rainOn && Nav.tab == "Today") RainOverlay()
            Crossfade(targetState = Nav.tab, animationSpec = tween(220), label = "tab") { t ->
                when (t) {
                    "Planner" -> PlannerScreen()
                    "Notes" -> NotesScreen()
                    "Alarm" -> AlarmScreen()
                    "Code" -> CodeScreen()
                    "Themes" -> ThemesScreen()
                    "Life" -> LifeScreen()
                    else -> TodayScreen()
                }
            }
        }
    }
}
