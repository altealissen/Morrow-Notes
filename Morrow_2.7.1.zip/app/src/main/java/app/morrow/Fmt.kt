package app.morrow

import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

val RU: Locale = Locale("ru", "RU")

private val dayMonthFormatter: DateTimeFormatter = DateTimeFormatter.ofPattern("d MMMM", RU)
private val longFormatter: DateTimeFormatter = DateTimeFormatter.ofPattern("EEEE, d MMMM", RU)

fun pad2(n: Int): String = if (n < 10) "0$n" else n.toString()

fun fmtTime(min: Int): String = pad2((min / 60) % 24) + ":" + pad2(min % 60)

fun fmtDuration(min: Int): String {
    val h = min / 60
    val m = min % 60
    return when {
        h == 0 -> "$m мин"
        m == 0 -> "$h ч"
        else -> "$h ч $m мин"
    }
}

fun remindLabel(min: Int): String = when {
    min < 0 -> "Без напоминания"
    min == 0 -> "В момент начала"
    min == 1440 -> "За 1 день"
    min % 1440 == 0 -> "За ${min / 1440} дн."
    min == 60 -> "За 1 час"
    min % 60 == 0 -> "За ${min / 60} ч"
    else -> "За $min мин"
}

val DayNamesShort = listOf("Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс")

fun daysSummary(mask: Int): String = when {
    mask == 0 -> "Один раз"
    mask == 127 -> "Каждый день"
    mask == 31 -> "По будням"
    mask == 96 -> "По выходным"
    else -> DayNamesShort.filterIndexed { i, _ -> ((mask shr i) and 1) == 1 }.joinToString(" ")
}

fun fmtDayMonth(d: LocalDate): String = d.format(dayMonthFormatter)
fun fmtLongDate(d: LocalDate): String = d.format(longFormatter).replaceFirstChar { it.uppercase() }

fun dateLabel(epochDay: Long, today: Long): String = when (epochDay - today) {
    0L -> "Сегодня"
    1L -> "Завтра"
    -1L -> "Вчера"
    else -> fmtDayMonth(LocalDate.ofEpochDay(epochDay))
}

/** "через 2 ч 10 мин" for a positive delta in milliseconds. */
fun relativeIn(deltaMs: Long): String {
    val totalMin = (deltaMs / 60_000L).coerceAtLeast(0L)
    val d = totalMin / 1440
    val h = (totalMin % 1440) / 60
    val m = totalMin % 60
    return when {
        d > 0 -> "через $d д ${h} ч"
        h > 0 -> "через $h ч $m мин"
        totalMin > 0 -> "через $m мин"
        else -> "меньше минуты"
    }
}

fun greetingFor(hour: Int): String = when (hour) {
    in 5..11 -> "Доброе утро"
    in 12..17 -> "Добрый день"
    in 18..22 -> "Добрый вечер"
    else -> "Тихой ночи"
}

fun fmtStamp(ms: Long): String {
    val z = Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault())
    return fmtDayMonth(z.toLocalDate()) + ", " + pad2(z.hour) + ":" + pad2(z.minute)
}
