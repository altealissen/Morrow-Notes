package app.morrow

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Handler
import android.os.Looper
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

/** Interface sounds that are synthesised on the fly, so no audio files (and no licences) are involved. */
object UiSounds {
    private const val RATE = 22050
    private val handler = Handler(Looper.getMainLooper())
    private var tapDrop: ShortArray? = null
    private var doneDrop: ShortArray? = null
    private var tapChime: ShortArray? = null
    private var doneChime: ShortArray? = null

    private fun tone(freqs: List<Pair<Double, Double>>, ms: Int, decay: Double, sweepTo: Double = 1.0): ShortArray {
        val n = RATE * ms / 1000
        val out = ShortArray(n)
        for (i in 0 until n) {
            val t = i.toDouble() / RATE
            val k = i.toDouble() / n
            val env = exp(-decay * t) * (if (i < 200) i / 200.0 else 1.0) * (if (n - i < 300) (n - i) / 300.0 else 1.0)
            var v = 0.0
            for ((f, amp) in freqs) {
                val fr = f * (1.0 + (sweepTo - 1.0) * k)
                v += amp * sin(2.0 * PI * fr * t)
            }
            out[i] = (v * env * 6000).toInt().coerceIn(-32000, 32000).toShort()
        }
        return out
    }

    private fun build(style: Int, done: Boolean): ShortArray {
        return if (style == 1) {
            // water drop: quick falling pitch
            if (done) {
                val a = tone(listOf(900.0 to 1.0), 90, 28.0, 0.6)
                val b = tone(listOf(1200.0 to 1.0), 120, 24.0, 0.6)
                a + ShortArray(RATE / 25) + b
            } else tone(listOf(760.0 to 1.0), 70, 34.0, 0.55)
        } else {
            // soft bell: fundamental plus a quiet overtone
            if (done) {
                val a = tone(listOf(659.0 to 1.0, 1318.0 to 0.25), 260, 9.0)
                val b = tone(listOf(988.0 to 1.0, 1976.0 to 0.25), 380, 8.0)
                a.copyOf(RATE / 8) + b
            } else tone(listOf(880.0 to 1.0, 1760.0 to 0.2), 160, 16.0)
        }
    }

    private fun sample(style: Int, done: Boolean): ShortArray {
        if (style == 1) {
            if (done) {
                if (doneDrop == null) doneDrop = build(1, true)
                return doneDrop!!
            }
            if (tapDrop == null) tapDrop = build(1, false)
            return tapDrop!!
        }
        if (done) {
            if (doneChime == null) doneChime = build(2, true)
            return doneChime!!
        }
        if (tapChime == null) tapChime = build(2, false)
        return tapChime!!
    }

    private fun play(done: Boolean) {
        val style = Life.uiSounds
        if (style == 0) return
        try {
            val data = sample(style, done)
            val track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(RATE)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(data.size * 2)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()
            track.write(data, 0, data.size)
            track.play()
            val ms = data.size * 1000L / RATE + 200L
            handler.postDelayed({ try { track.release() } catch (_: Exception) { } }, ms)
        } catch (_: Exception) {
        }
    }

    fun tap() = play(false)
    fun done() = play(true)
}
