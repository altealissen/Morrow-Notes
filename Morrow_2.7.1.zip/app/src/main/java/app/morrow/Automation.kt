package app.morrow

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZonedDateTime

/** Two transparent rules: bedtime reminder and morning summary. No hidden behaviour. */
object Automation {
    const val KIND_BED = "bed"
    const val KIND_MORNING = "morning"
    const val EXTRA_KIND = "kind"

    private fun nextAt(minuteOfDay: Int): Long {
        val zone = ZoneId.systemDefault()
        val now = ZonedDateTime.now(zone)
        var t = ZonedDateTime.of(now.toLocalDate(), LocalTime.of((minuteOfDay / 60) % 24, minuteOfDay % 60), zone)
        if (!t.isAfter(now.plusSeconds(2))) t = t.plusDays(1)
        return t.toInstant().toEpochMilli()
    }

    private fun pi(ctx: Context, kind: String, code: Int): PendingIntent =
        PendingIntent.getBroadcast(
            ctx, code,
            Intent(ctx, AutoReceiver::class.java)
                .setData(Uri.parse("morrow://auto/$kind"))
                .putExtra(EXTRA_KIND, kind),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

    private fun arm(ctx: Context, kind: String, code: Int, enabled: Boolean, minuteOfDay: Int) {
        val am = ctx.getSystemService(AlarmManager::class.java) ?: return
        val p = pi(ctx, kind, code)
        if (!enabled) {
            am.cancel(p)
            return
        }
        try {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, nextAt(minuteOfDay), p)
        } catch (_: Exception) {
        }
    }

    fun schedule(ctx: Context) {
        val c = ctx.applicationContext
        val bedAt = ((Life.sleepBed - Life.sleepRemind) % 1440 + 1440) % 1440
        arm(c, KIND_BED, 7101, Life.autoBedtime, bedAt)
        arm(c, KIND_MORNING, 7102, Life.autoMorning, Life.sleepWake)
    }

    const val KIND_FOCUS = "focus"

    fun scheduleFocus(ctx: Context, endMillis: Long) {
        val am = ctx.getSystemService(AlarmManager::class.java) ?: return
        val p = pi(ctx.applicationContext, KIND_FOCUS, 7103)
        try {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, endMillis, p)
        } catch (_: SecurityException) {
            try {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, endMillis, p)
            } catch (_: Exception) {
            }
        }
    }

    fun cancelFocus(ctx: Context) {
        val am = ctx.getSystemService(AlarmManager::class.java) ?: return
        am.cancel(pi(ctx.applicationContext, KIND_FOCUS, 7103))
    }

    fun fire(ctx: Context, kind: String) {
        Scheduler.ensureChannels(ctx)
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        val intent = Intent(ctx, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val title: String
        val text: String
        if (kind == KIND_FOCUS) {
            title = "Фокус завершён"
            text = "Сделай паузу: встань, вода, глубокий вдох."
            intent.putExtra(Scheduler.EXTRA_TAB, "Today")
        } else if (kind == KIND_BED) {
            title = "Пора готовиться ко сну"
            text = "Отбой в " + fmtTime(Life.sleepBed) + ". Нажми, чтобы включить режим сна."
            intent.putExtra("quick", "sleep")
        } else {
            title = "Доброе утро"
            text = LocalAssistant.daySummary()
            intent.putExtra(Scheduler.EXTRA_TAB, "Today")
        }
        val open = PendingIntent.getActivity(ctx, if (kind == KIND_BED) 7111 else if (kind == KIND_FOCUS) 7113 else 7112, intent, flags)
        val n = NotificationCompat.Builder(ctx, Scheduler.CH_REMINDER)
            .setSmallIcon(R.drawable.ic_stat_morrow)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .setContentIntent(open)
            .build()
        try {
            NotificationManagerCompat.from(ctx).notify(if (kind == KIND_BED) 7121 else if (kind == KIND_FOCUS) 7123 else 7122, n)
        } catch (_: SecurityException) {
        }
    }
}

class AutoReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        Repo.init(context)
        val kind = intent?.getStringExtra(Automation.EXTRA_KIND) ?: return
        if (kind == Automation.KIND_FOCUS) {
            Automation.fire(context, kind)
            return
        }
        val enabled = if (kind == Automation.KIND_BED) Life.autoBedtime else Life.autoMorning
        if (enabled) Automation.fire(context, kind)
        Automation.schedule(context)
    }
}

/** Second widget: today at a glance. */
class TodayWidget : android.appwidget.AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: android.appwidget.AppWidgetManager, ids: IntArray) {
        for (id in ids) manager.updateAppWidget(id, build(context))
    }

    companion object {
        fun build(context: Context): android.widget.RemoteViews {
            val rv = android.widget.RemoteViews(context.packageName, R.layout.widget_next)
            rv.setTextViewText(R.id.widget_label, "Morrow · сегодня")
            rv.setTextViewText(R.id.widget_title, fmtLongDate(java.time.LocalDate.now()))
            rv.setTextViewText(R.id.widget_time, LocalAssistant.daySummary())
            val open = Intent(context, MainActivity::class.java).putExtra(Scheduler.EXTRA_TAB, "Today")
            rv.setOnClickPendingIntent(
                R.id.widget_root,
                PendingIntent.getActivity(context, 7002, open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            )
            return rv
        }

        fun refresh(context: Context) {
            try {
                val mgr = android.appwidget.AppWidgetManager.getInstance(context)
                val ids = mgr.getAppWidgetIds(android.content.ComponentName(context, TodayWidget::class.java))
                for (id in ids) mgr.updateAppWidget(id, build(context))
            } catch (_: Exception) {
            }
        }
    }
}

private fun glanceViews(ctx: Context, label: String, title: String, body: String, tab: String, code: Int): android.widget.RemoteViews {
    val rv = android.widget.RemoteViews(ctx.packageName, R.layout.widget_next)
    rv.setTextViewText(R.id.widget_label, label)
    rv.setTextViewText(R.id.widget_title, title)
    rv.setTextViewText(R.id.widget_time, body)
    val open = Intent(ctx, MainActivity::class.java).putExtra(Scheduler.EXTRA_TAB, tab)
    rv.setOnClickPendingIntent(
        R.id.widget_root,
        PendingIntent.getActivity(ctx, code, open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    )
    return rv
}

private fun refreshAll(ctx: Context, cls: Class<*>, build: (Context) -> android.widget.RemoteViews) {
    try {
        val mgr = android.appwidget.AppWidgetManager.getInstance(ctx)
        for (id in mgr.getAppWidgetIds(android.content.ComponentName(ctx, cls))) mgr.updateAppWidget(id, build(ctx))
    } catch (_: Exception) {
    }
}

/** Habits widget: how many habits are done today. */
class HabitsWidget : android.appwidget.AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: android.appwidget.AppWidgetManager, ids: IntArray) {
        for (id in ids) manager.updateAppWidget(id, build(context))
    }

    companion object {
        fun build(ctx: Context): android.widget.RemoteViews {
            val today = java.time.LocalDate.now().toEpochDay()
            val list = Life.habits.filter { Life.isScheduled(it, today) }
            val done = list.count { today in it.done }
            val left = list.filter { today !in it.done }.take(3).joinToString(", ") { it.name }
            return glanceViews(
                ctx, "Morrow · привычки",
                if (list.isEmpty()) "Привычек нет" else "Сегодня $done из ${list.size}",
                if (left.isEmpty()) "Всё на сегодня закрыто" else "Осталось: $left", "Life", 7003
            )
        }

        fun refresh(ctx: Context) = refreshAll(ctx, HabitsWidget::class.java) { build(it) }
    }
}

/** Notes widget: the latest note. */
class NotesWidget : android.appwidget.AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: android.appwidget.AppWidgetManager, ids: IntArray) {
        for (id in ids) manager.updateAppWidget(id, build(context))
    }

    companion object {
        fun build(ctx: Context): android.widget.RemoteViews {
            val n = Repo.notes.filter { it.trashedAt == 0L }.maxByOrNull { it.modified }
            return glanceViews(
                ctx, "Morrow · заметки",
                if (n == null) "Заметок пока нет" else n.title.ifBlank { "Без названия" },
                if (n == null) "Нажми, чтобы создать" else n.body.take(120), "Notes", 7004
            )
        }

        fun refresh(ctx: Context) = refreshAll(ctx, NotesWidget::class.java) { build(it) }
    }
}

/** Tasks widget: open project tasks. */
class TasksWidget : android.appwidget.AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: android.appwidget.AppWidgetManager, ids: IntArray) {
        for (id in ids) manager.updateAppWidget(id, build(context))
    }

    companion object {
        fun build(ctx: Context): android.widget.RemoteViews {
            val open = Life.ptasks.filter { it.status != 2 }
            val first = open.sortedByDescending { it.status }.take(3).joinToString("\n") { "• " + it.title }
            return glanceViews(
                ctx, "Morrow · задачи",
                if (open.isEmpty()) "Всё сделано" else "Открыто задач: " + open.size,
                if (first.isEmpty()) "Можно отдыхать" else first, "Life", 7005
            )
        }

        fun refresh(ctx: Context) = refreshAll(ctx, TasksWidget::class.java) { build(it) }
    }
}

/** Calendar widget: the next few events. */
class CalendarWidget : android.appwidget.AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: android.appwidget.AppWidgetManager, ids: IntArray) {
        for (id in ids) manager.updateAppWidget(id, build(context))
    }

    companion object {
        fun build(ctx: Context): android.widget.RemoteViews {
            val now = System.currentTimeMillis()
            val today = java.time.LocalDate.now().toEpochDay()
            val next = Repo.events.filter { !it.done && it.endMillis() >= now }.sortedBy { it.startMillis() }.take(3)
            val lines = next.joinToString("\n") {
                dateLabel(it.epochDay, today) + " " + fmtTime(it.startMin) + " · " + it.title.ifBlank { "Без названия" }
            }
            return glanceViews(
                ctx, "Morrow · календарь",
                fmtLongDate(java.time.LocalDate.now()),
                if (lines.isEmpty()) "Событий впереди нет" else lines, "Planner", 7006
            )
        }

        fun refresh(ctx: Context) = refreshAll(ctx, CalendarWidget::class.java) { build(it) }
    }
}
