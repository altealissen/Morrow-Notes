package app.morrow

import android.app.Activity
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Display
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import kotlin.math.abs

/**
 * Adaptive refresh rate. Compose already follows whatever rate the window gets, so the job here is to ask for it:
 * 0 = auto (highest rate while the screen is touched, 60 Hz after a few idle seconds),
 * 1 = always 60 Hz, 2 = always the highest rate the panel supports.
 */
object RefreshRate {
    private const val IDLE_MS = 4000L
    private val handler = Handler(Looper.getMainLooper())
    private var high: Boolean? = null
    private var idle: Runnable? = null
    private var lastTouch = 0L

    /** Highest refresh rate of the panel at its current resolution, for display in settings. */
    var maxHz by mutableIntStateOf(60)
        private set

    @Suppress("DEPRECATION")
    private fun display(a: Activity): Display? = try {
        if (Build.VERSION.SDK_INT >= 30) a.display else a.windowManager.defaultDisplay
    } catch (_: Exception) {
        null
    }

    private fun modesOf(a: Activity): List<Display.Mode> {
        val d = display(a) ?: return emptyList()
        val cur = d.mode
        return d.supportedModes.filter {
            it.physicalWidth == cur.physicalWidth && it.physicalHeight == cur.physicalHeight
        }
    }

    private fun applyRate(a: Activity, wantHigh: Boolean) {
        if (high == wantHigh) return
        try {
            val modes = modesOf(a)
            if (modes.isEmpty()) return
            val top = modes.maxByOrNull { it.refreshRate } ?: return
            maxHz = Math.round(top.refreshRate)
            val target = if (wantHigh) top else (modes.minByOrNull { abs(it.refreshRate - 60f) } ?: top)
            val lp = a.window.attributes
            lp.preferredDisplayModeId = target.modeId
            lp.preferredRefreshRate = target.refreshRate
            a.window.attributes = lp
            high = wantHigh
        } catch (_: Exception) {
        }
    }

    /** Applies the chosen mode; call on resume and whenever the setting changes. */
    fun update(a: Activity) {
        idle?.let { handler.removeCallbacks(it) }
        when (Life.refreshMode) {
            1 -> applyRate(a, false)
            2 -> applyRate(a, true)
            else -> {
                applyRate(a, true)
                scheduleIdle(a)
            }
        }
    }

    private fun scheduleIdle(a: Activity) {
        idle?.let { handler.removeCallbacks(it) }
        val r = Runnable { if (Life.refreshMode == 0) applyRate(a, false) }
        idle = r
        handler.postDelayed(r, IDLE_MS)
    }

    /** Any touch wakes the high rate up in auto mode. */
    fun touch(a: Activity) {
        if (Life.refreshMode != 0) return
        val now = android.os.SystemClock.uptimeMillis()
        if (high == true && now - lastTouch < 700L) return   // touch events come ~120 times a second
        lastTouch = now
        applyRate(a, true)
        scheduleIdle(a)
    }

    fun stop() {
        idle?.let { handler.removeCallbacks(it) }
        high = null
    }
}
