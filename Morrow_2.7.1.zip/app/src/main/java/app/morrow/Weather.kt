package app.morrow

import android.content.Context
import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class WeatherInfo(
    val city: String,
    val lat: Double,
    val lon: Double,
    val temp: Int,
    val min: Int,
    val max: Int,
    val code: Int,
    val updated: Long
)

/** Weather from Open-Meteo (no key, no account). Only the city name and coordinates leave the phone. */
object Weather {
    private val main = Handler(Looper.getMainLooper())
    @Volatile private var busy = false

    fun icon(code: Int): String = when (code) {
        0 -> "☀️"
        1, 2 -> "🌤"
        3 -> "☁️"
        45, 48 -> "🌫"
        in 51..57 -> "🌦"
        in 61..67 -> "🌧"
        in 71..77 -> "❄️"
        in 80..82 -> "🌧"
        85, 86 -> "❄️"
        in 95..99 -> "⛈"
        else -> "🌡"
    }

    fun text(code: Int): String = when (code) {
        0 -> "Ясно"
        1, 2 -> "Малооблачно"
        3 -> "Пасмурно"
        45, 48 -> "Туман"
        in 51..57 -> "Морось"
        in 61..67 -> "Дождь"
        in 71..77 -> "Снег"
        in 80..82 -> "Ливень"
        85, 86 -> "Снегопад"
        in 95..99 -> "Гроза"
        else -> "Погода"
    }

    fun tempLabel(t: Int): String = (if (t > 0) "+" else "") + t + "°"

    private fun get(url: String): JSONObject {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 8000
        try {
            return JSONObject(c.inputStream.bufferedReader().use { it.readText() })
        } finally {
            c.disconnect()
        }
    }

    /** Looks the city up (or reuses saved coordinates) and loads today's weather. [done] runs on the main thread. */
    fun refresh(ctx: Context, city: String, done: (String?) -> Unit = {}) {
        if (busy) return
        val name = city.trim()
        if (name.isEmpty()) {
            done("Введи город")
            return
        }
        busy = true
        val app = ctx.applicationContext
        Thread {
            var error: String? = null
            try {
                val old = Life.weather
                var lat: Double
                var lon: Double
                var label: String
                if (old != null && old.city.equals(name, ignoreCase = true)) {
                    lat = old.lat; lon = old.lon; label = old.city
                } else {
                    val g = get("https://geocoding-api.open-meteo.com/v1/search?name=" +
                        URLEncoder.encode(name, "UTF-8") + "&count=1&language=ru&format=json")
                    val r = g.optJSONArray("results")?.optJSONObject(0)
                    if (r == null) {
                        error = "Город не найден"
                        lat = 0.0; lon = 0.0; label = name
                    } else {
                        lat = r.getDouble("latitude"); lon = r.getDouble("longitude")
                        label = r.optString("name", name)
                    }
                }
                if (error == null) {
                    val f = get("https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
                        "&current=temperature_2m,weather_code&daily=temperature_2m_max,temperature_2m_min" +
                        "&timezone=auto&forecast_days=1")
                    val cur = f.getJSONObject("current")
                    val daily = f.getJSONObject("daily")
                    val info = WeatherInfo(
                        label, lat, lon,
                        Math.round(cur.getDouble("temperature_2m")).toInt(),
                        Math.round(daily.getJSONArray("temperature_2m_min").getDouble(0)).toInt(),
                        Math.round(daily.getJSONArray("temperature_2m_max").getDouble(0)).toInt(),
                        cur.optInt("weather_code", -1),
                        System.currentTimeMillis()
                    )
                    main.post {
                        Life.weather = info
                        Repo.saveNow()
                    }
                }
            } catch (e: Exception) {
                error = "Нет связи с сервисом погоды"
            }
            busy = false
            main.post {
                if (error == null) Widgets.refreshAll(app)
                done(error)
            }
        }.start()
    }

    fun refreshIfStale(ctx: Context) {
        val w = Life.weather ?: return
        if (System.currentTimeMillis() - w.updated > 30 * 60 * 1000L) refresh(ctx, w.city)
    }
}

object Widgets {
    fun refreshAll(ctx: Context) {
        val c = ctx.applicationContext
        NextEventWidget.refresh(c)
        TodayWidget.refresh(c)
        HabitsWidget.refresh(c)
        NotesWidget.refresh(c)
        TasksWidget.refresh(c)
        CalendarWidget.refresh(c)
        WeatherWidget.refresh(c)
    }
}

class WeatherWidget : android.appwidget.AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: android.appwidget.AppWidgetManager, ids: IntArray) {
        for (id in ids) manager.updateAppWidget(id, build(context))
        Repo.init(context)
        Weather.refreshIfStale(context)
    }

    companion object {
        fun build(ctx: Context): android.widget.RemoteViews {
            val rv = android.widget.RemoteViews(ctx.packageName, R.layout.widget_next)
            val w = Life.weather
            rv.setTextViewText(R.id.widget_label, "Morrow · погода")
            if (w == null) {
                rv.setTextViewText(R.id.widget_title, "Город не выбран")
                rv.setTextViewText(R.id.widget_time, "Открой Life → Погода")
            } else {
                rv.setTextViewText(R.id.widget_title, Weather.icon(w.code) + " " + Weather.tempLabel(w.temp) + " · " + w.city)
                rv.setTextViewText(
                    R.id.widget_time,
                    Weather.text(w.code) + ", " + Weather.tempLabel(w.min) + "…" + Weather.tempLabel(w.max)
                )
            }
            val open = android.content.Intent(ctx, MainActivity::class.java).putExtra(Scheduler.EXTRA_TAB, "Life")
            rv.setOnClickPendingIntent(
                R.id.widget_root,
                android.app.PendingIntent.getActivity(
                    ctx, 7007, open,
                    android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
                )
            )
            return rv
        }

        fun refresh(ctx: Context) {
            try {
                val mgr = android.appwidget.AppWidgetManager.getInstance(ctx)
                for (id in mgr.getAppWidgetIds(android.content.ComponentName(ctx, WeatherWidget::class.java))) {
                    mgr.updateAppWidget(id, build(ctx))
                }
            } catch (_: Exception) {
            }
        }
    }
}
