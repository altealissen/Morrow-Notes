package app.morrow

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import kotlin.math.pow

data class Palette(
    val name: String,
    val group: String,
    val dark: Boolean,
    val bg: Long,
    val surface: Long,
    val text: Long,
    val muted: Long,
    val accent: Long
)

private fun P(n: String, g: String, d: Boolean, bg: Long, su: Long, tx: Long, mu: Long, ac: Long) =
    Palette(n, g, d, bg, su, tx, mu, ac)

const val GROUP_LIGHT = "Светлые"
const val GROUP_DARK = "Тёмные"
const val GROUP_ONEPLUS = "OnePlus"
const val GROUP_PNW = "Pacific Northwest"
const val GROUP_SEASON = "Сезонные"

/** All contrast ratios (text/muted/accent on bg and surface) were checked to be >= 4.5. */
val Palettes: List<Palette> = listOf(
    P("Ivory", GROUP_LIGHT, false, 0xFFF4F0E6, 0xFFFFFFFF, 0xFF2F3A33, 0xFF626C66, 0xFFC9252F),
    P("Lavender", GROUP_LIGHT, false, 0xFFEAE3F4, 0xFFF7F3FC, 0xFF3B2F55, 0xFF675E7F, 0xFF774CB2),
    P("Pistachio", GROUP_LIGHT, false, 0xFFE6EFDC, 0xFFF6FAF1, 0xFF2E4430, 0xFF596B5A, 0xFF397134),
    P("Mist", GROUP_LIGHT, false, 0xFFE4EAEA, 0xFFF5F8F8, 0xFF33454A, 0xFF57656A, 0xFF476778),
    P("Cream", GROUP_LIGHT, false, 0xFFFFF4D6, 0xFFFFFBEE, 0xFF4A3E26, 0xFF796A49, 0xFFA4561A),
    P("Soft Blue", GROUP_LIGHT, false, 0xFFE1EDF8, 0xFFF5FAFE, 0xFF2B4560, 0xFF52667D, 0xFF2D69AF),
    P("Rose", GROUP_LIGHT, false, 0xFFF8E4E8, 0xFFFFF6F8, 0xFF53343E, 0xFF7D5B65, 0xFFB23857),
    P("Peach", GROUP_LIGHT, false, 0xFFFFE8DB, 0xFFFFF6F0, 0xFF5A3A2E, 0xFF815E4F, 0xFFB04028),

    P("Midnight", GROUP_DARK, true, 0xFF0F1620, 0xFF1A2432, 0xFFE6ECF3, 0xFF9DAEC0, 0xFF8AB4F8),
    P("Forest", GROUP_DARK, true, 0xFF16241C, 0xFF21342A, 0xFFE4EEE2, 0xFFA3B8A6, 0xFF7FD18B),
    P("Rain", GROUP_DARK, true, 0xFF1B2428, 0xFF27343A, 0xFFE3EDF0, 0xFFA0B4BB, 0xFF6EC1D6),
    P("Deep Ocean", GROUP_DARK, true, 0xFF0A1B2A, 0xFF132E45, 0xFFDCEBF7, 0xFF94B1C9, 0xFF4FC3F7),
    P("Charcoal", GROUP_DARK, true, 0xFF1C1C1E, 0xFF2A2A2D, 0xFFEDEDED, 0xFFA8A8AD, 0xFFF2A65A),
    P("Dark Lavender", GROUP_DARK, true, 0xFF1E1829, 0xFF2B2339, 0xFFECE6F7, 0xFFB0A5C8, 0xFFC4A1FF),
    P("OnePlus Dark", GROUP_DARK, true, 0xFF0B0B0B, 0xFF1A1A1A, 0xFFF2F2F2, 0xFFA6A6A6, 0xFFFF4B55),

    P("Minimal Light", GROUP_ONEPLUS, false, 0xFFF7F7F7, 0xFFFFFFFF, 0xFF1B1B1B, 0xFF666666, 0xFFD70026),
    P("Minimal Dark", GROUP_ONEPLUS, true, 0xFF0E0E0E, 0xFF1C1C1C, 0xFFF0F0F0, 0xFFA3A3A3, 0xFFFF5360),
    P("Vivid OnePlus", GROUP_ONEPLUS, true, 0xFF160A0C, 0xFF2C1216, 0xFFFFEFEF, 0xFFE3AEB2, 0xFFFF4455),
    P("Soft OnePlus", GROUP_ONEPLUS, false, 0xFFFCEFEF, 0xFFFFFFFF, 0xFF2E1C1E, 0xFF806266, 0xFFCC1F2D),

    P("Fog", GROUP_PNW, false, 0xFFE6E8E5, 0xFFF7F8F6, 0xFF3A4540, 0xFF5C6560, 0xFF396F5A),
    P("Cedar", GROUP_PNW, false, 0xFFE9DDD0, 0xFFF8F0E7, 0xFF4A3A2D, 0xFF705C49, 0xFF984A26),
    P("Evergreen", GROUP_PNW, true, 0xFF1F2D25, 0xFF2B3E33, 0xFFE5EBDD, 0xFFAFC0AF, 0xFF9ED58B),
    P("Moss", GROUP_PNW, true, 0xFF2B3828, 0xFF394A35, 0xFFEAF0E2, 0xFFB8C6B0, 0xFFB5D96B),

    P("Autumn", GROUP_SEASON, false, 0xFFF6E6D2, 0xFFFFF6EA, 0xFF3D2A1A, 0xFF6B543E, 0xFFA3401C),
    P("Blossom", GROUP_SEASON, false, 0xFFF8E7EC, 0xFFFFF5F8, 0xFF4A2A35, 0xFF7A5560, 0xFFB01E5B),
    P("Winter", GROUP_SEASON, true, 0xFF17212B, 0xFF22313F, 0xFFE6EEF5, 0xFFA9BBCB, 0xFF8CC8F0),
    P("Summer Night", GROUP_SEASON, true, 0xFF1D1A2E, 0xFF2A2640, 0xFFEEEAF9, 0xFFB6B0D3, 0xFFFFB36B)
)

val PaletteGroups = listOf(GROUP_LIGHT, GROUP_DARK, GROUP_ONEPLUS, GROUP_PNW, GROUP_SEASON)

fun findPalette(name: String, dark: Boolean): Palette =
    Palettes.firstOrNull { it.name == name && it.dark == dark }
        ?: Palettes.first { it.dark == dark }

// ---------- contrast helpers ----------

fun luminance(c: Color): Double {
    fun ch(v: Float): Double {
        val d = v.toDouble()
        return if (d <= 0.03928) d / 12.92 else ((d + 0.055) / 1.055).pow(2.4)
    }
    return 0.2126 * ch(c.red) + 0.7152 * ch(c.green) + 0.0722 * ch(c.blue)
}

fun contrastRatio(a: Color, b: Color): Double {
    val l1 = luminance(a)
    val l2 = luminance(b)
    return (maxOf(l1, l2) + 0.05) / (minOf(l1, l2) + 0.05)
}

fun onColorFor(bg: Color): Color {
    val dark = Color(0xFF111111)
    return if (contrastRatio(Color.White, bg) >= contrastRatio(dark, bg)) Color.White else dark
}

/** Moves [fg] towards black or white until it reaches [min] contrast on all [backgrounds]. */
fun ensureContrast(fg: Color, backgrounds: List<Color>, min: Double): Color {
    var c = fg
    val avgLum = backgrounds.map { luminance(it) }.average()
    val target = if (avgLum > 0.4) Color.Black else Color.White
    var guard = 0
    while (backgrounds.any { contrastRatio(c, it) < min } && guard < 40) {
        c = lerp(c, target, 0.06f)
        guard++
    }
    return c
}

fun mix(a: Color, b: Color, t: Float): Color = lerp(a, b, t)

fun buildScheme(p: Palette, accentOverride: Int): ColorScheme {
    val bg = Color(p.bg)
    val surface = Color(p.surface)
    val text = Color(p.text)
    val muted = Color(p.muted)
    val rawAccent = if (accentOverride != 0) Color(accentOverride) else Color(p.accent)
    val primary = ensureContrast(rawAccent, listOf(bg, surface), 4.5)
    val onPrimary = onColorFor(primary)
    val primaryContainer = mix(surface, primary, 0.20f)
    val secondaryContainer = mix(surface, primary, 0.14f)
    val surfaceVariant = mix(surface, text, 0.07f)
    val outline = mix(bg, muted, 0.85f)
    val outlineVariant = mix(bg, text, 0.14f)
    val error = if (p.dark) Color(0xFFFFB4AB) else Color(0xFFB3261E)
    val onError = if (p.dark) Color(0xFF690005) else Color.White
    val errorContainer = if (p.dark) Color(0xFF93000A) else Color(0xFFF9DEDC)
    val onErrorContainer = if (p.dark) Color(0xFFFFDAD6) else Color(0xFF410E0B)

    return if (p.dark) {
        darkColorScheme(
            primary = primary, onPrimary = onPrimary,
            primaryContainer = primaryContainer, onPrimaryContainer = text,
            inversePrimary = mix(primary, Color.Black, 0.3f),
            secondary = muted, onSecondary = onColorFor(muted),
            secondaryContainer = secondaryContainer, onSecondaryContainer = text,
            tertiary = primary, onTertiary = onPrimary,
            background = bg, onBackground = text,
            surface = surface, onSurface = text,
            surfaceVariant = surfaceVariant, onSurfaceVariant = muted,
            surfaceTint = primary,
            inverseSurface = text, inverseOnSurface = bg,
            error = error, onError = onError,
            errorContainer = errorContainer, onErrorContainer = onErrorContainer,
            outline = outline, outlineVariant = outlineVariant,
            scrim = Color.Black,
            surfaceBright = mix(surface, text, 0.08f), surfaceDim = bg,
            surfaceContainerLowest = bg, surfaceContainerLow = mix(bg, surface, 0.5f),
            surfaceContainer = surface, surfaceContainerHigh = mix(surface, text, 0.05f),
            surfaceContainerHighest = mix(surface, text, 0.09f)
        )
    } else {
        lightColorScheme(
            primary = primary, onPrimary = onPrimary,
            primaryContainer = primaryContainer, onPrimaryContainer = text,
            inversePrimary = mix(primary, Color.White, 0.4f),
            secondary = muted, onSecondary = onColorFor(muted),
            secondaryContainer = secondaryContainer, onSecondaryContainer = text,
            tertiary = primary, onTertiary = onPrimary,
            background = bg, onBackground = text,
            surface = surface, onSurface = text,
            surfaceVariant = surfaceVariant, onSurfaceVariant = muted,
            surfaceTint = primary,
            inverseSurface = text, inverseOnSurface = bg,
            error = error, onError = onError,
            errorContainer = errorContainer, onErrorContainer = onErrorContainer,
            outline = outline, outlineVariant = outlineVariant,
            scrim = Color.Black,
            surfaceBright = surface, surfaceDim = mix(bg, text, 0.06f),
            surfaceContainerLowest = Color.White, surfaceContainerLow = mix(bg, surface, 0.5f),
            surfaceContainer = surface, surfaceContainerHigh = mix(surface, text, 0.05f),
            surfaceContainerHighest = mix(surface, text, 0.09f)
        )
    }
}

class CodeColors(
    val keyword: Color,
    val string: Color,
    val number: Color,
    val type: Color,
    val tag: Color,
    val attr: Color,
    val comment: Color
)

class MorrowExtras(
    val dark: Boolean,
    val red: Color,
    val code: CodeColors
)

private val LightCode = CodeColors(
    keyword = Color(0xFF8E24AA), string = Color(0xFF2E7D32), number = Color(0xFFA15C00),
    type = Color(0xFF00629E), tag = Color(0xFFB3261E), attr = Color(0xFF8A4B00),
    comment = Color(0xFF6B7570)
)
private val DarkCode = CodeColors(
    keyword = Color(0xFFD9A8E8), string = Color(0xFFA5D66F), number = Color(0xFFFFB968),
    type = Color(0xFF86D4FF), tag = Color(0xFFFF9A8F), attr = Color(0xFFFFCC80),
    comment = Color(0xFF9AA6A0)
)

val LocalExtras = staticCompositionLocalOf {
    MorrowExtras(false, Color(0xFFD81B2B), LightCode)
}

@Composable
fun MorrowTheme(content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    val systemDark = isSystemInDarkTheme()
    val dark = when (Prefs.themeMode) {
        1 -> false
        2 -> true
        else -> systemDark
    }
    val palette = findPalette(if (dark) Prefs.darkTheme else Prefs.lightTheme, dark)
    var scheme: ColorScheme =
        if (Prefs.dynamic && Build.VERSION.SDK_INT >= 31) {
            if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        } else {
            buildScheme(palette, Prefs.accent)
        }
    if (Prefs.dynamic && Build.VERSION.SDK_INT >= 31 && Prefs.accent != 0) {
        val a = ensureContrast(
            Color(Prefs.accent), listOf(scheme.background, scheme.surface), 4.5
        )
        scheme = scheme.copy(primary = a, onPrimary = onColorFor(a))
    }
    val extras = MorrowExtras(
        dark = dark,
        red = if (dark) Color(0xFFFF5C5C) else Color(0xFFD81B2B),
        code = if (dark) DarkCode else LightCode
    )

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                WindowCompat.setDecorFitsSystemWindows(window, false)
                val controller = WindowCompat.getInsetsController(window, view)
                controller.isAppearanceLightStatusBars = !dark
                controller.isAppearanceLightNavigationBars = !dark
            }
        }
    }

    CompositionLocalProvider(LocalExtras provides extras) {
        MaterialTheme(colorScheme = scheme, typography = fontTypography(), content = content)
    }
}
