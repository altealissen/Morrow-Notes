package app.morrow

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

/** Full screen alarm screen, shown over the lock screen. */
class AlarmRingActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val id = intent.getLongExtra(Scheduler.EXTRA_ID, -1L)
        setContent {
            MorrowTheme {
                RingScreen(id) { finish() }
            }
        }
    }
}

private fun sendToService(ctx: Context, action: String, id: Long) {
    val i = Intent(ctx, AlarmService::class.java).setAction(action).putExtra(Scheduler.EXTRA_ID, id)
    try {
        ctx.startService(i)
    } catch (_: Exception) {
    }
}

@Composable
private fun RingScreen(id: Long, onFinish: () -> Unit) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val alarm = Repo.alarms.firstOrNull { it.id == id }

    // close the screen as soon as the service stops ringing
    LaunchedEffect(Unit) {
        delay(1500)
        while (AlarmService.ringingId != -1L) delay(500)
        onFinish()
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            if (alarm != null) pad2(alarm.hour) + ":" + pad2(alarm.minute) else "Будильник",
            fontSize = 72.sp,
            fontWeight = FontWeight.Light,
            color = MaterialTheme.colorScheme.onBackground
        )
        Spacer(Modifier.height(8.dp))
        Text(
            alarm?.label?.ifBlank { null } ?: "Доброе утро",
            fontSize = 22.sp,
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(64.dp))
        Button(
            onClick = {
                sendToService(ctx, AlarmService.ACTION_STOP, id)
                onFinish()
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(64.dp)
        ) { Text("Стоп", fontSize = 20.sp) }
        Spacer(Modifier.height(16.dp))
        OutlinedButton(
            onClick = {
                sendToService(ctx, AlarmService.ACTION_SNOOZE, id)
                onFinish()
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
        ) { Text("Отложить на ${alarm?.snoozeMin ?: 10} мин", fontSize = 16.sp) }
    }
}
