package app.morrow

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import java.time.LocalDate

/** Home screen widget: the next unfinished event. */
class NextEventWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        for (id in ids) manager.updateAppWidget(id, build(context))
    }

    companion object {
        fun build(context: Context): RemoteViews {
            val rv = RemoteViews(context.packageName, R.layout.widget_next)
            val now = System.currentTimeMillis()
            val next = Repo.events.filter { !it.done && it.endMillis() >= now }.minByOrNull { it.startMillis() }
            rv.setTextViewText(R.id.widget_label, "Morrow · ближайшее")
            if (next == null) {
                rv.setTextViewText(R.id.widget_title, "Свободно")
                rv.setTextViewText(R.id.widget_time, "Событий впереди нет")
            } else {
                val today = LocalDate.now().toEpochDay()
                rv.setTextViewText(R.id.widget_title, next.title.ifBlank { "Без названия" })
                rv.setTextViewText(
                    R.id.widget_time,
                    dateLabel(next.epochDay, today) + ", " + fmtTime(next.startMin)
                )
            }
            val open = Intent(context, MainActivity::class.java)
                .putExtra(Scheduler.EXTRA_TAB, "Planner")
            val pi = PendingIntent.getActivity(
                context, 7001, open,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            rv.setOnClickPendingIntent(R.id.widget_root, pi)
            return rv
        }

        fun refresh(context: Context) {
            try {
                val mgr = AppWidgetManager.getInstance(context)
                val ids = mgr.getAppWidgetIds(ComponentName(context, NextEventWidget::class.java))
                for (id in ids) mgr.updateAppWidget(id, build(context))
            } catch (_: Exception) {
            }
        }
    }
}

/** Architecture hook for a future local assistant. Nothing here talks to a network. */
interface AssistantProvider {
    fun answer(query: String): String
}

object LocalAssistant : AssistantProvider {
    /** Short plain-text summary of the day, built only from local data. */
    fun daySummary(): String {
        val today = LocalDate.now().toEpochDay()
        val evs = Repo.eventsOn(today).filter { !it.done }
        val habitsLeft = Life.habits.filter { Life.isScheduled(it, today) && today !in it.done }
        val sb = StringBuilder()
        sb.append(if (evs.isEmpty()) "Событий на сегодня нет." else "Событий сегодня: " + evs.size +
            ", ближайшее в " + fmtTime(evs.first().startMin) + ".")
        sb.append(" ")
        sb.append(if (habitsLeft.isEmpty()) "Привычки на сегодня закрыты." else "Привычек осталось: " + habitsLeft.size + ".")
        val open = Life.ptasks.count { it.status != 2 }
        if (open > 0) sb.append(" Открытых задач проектов: ").append(open).append(".")
        return sb.toString()
    }

    override fun answer(query: String): String {
        val q = query.trim().lowercase()
        return when {
            q.contains("сводк") || q.contains("сегодня") -> daySummary()
            else -> "Пока я умею только сводку дня. Поиск по данным — в Life → Поиск."
        }
    }
}

/** Built-in note templates. */
data class NoteTemplate(val name: String, val title: String, val body: String)

val BuiltinTemplates: List<NoteTemplate> = listOf(
    NoteTemplate("Обычная", "", ""),
    NoteTemplate("Идея", "Идея", "# Идея\n\n**Суть:** \n\n## Зачем\n- \n\n## Первый шаг\n- [ ] "),
    NoteTemplate("Дневниковая запись", "Дневник", "# Сегодня\n\n## Что было\n\n## Что порадовало\n\n## Что завтра\n- [ ] "),
    NoteTemplate("Список покупок", "Покупки", "# Покупки\n\n- [ ] \n- [ ] \n- [ ] "),
    NoteTemplate("Конспект", "Конспект", "# Тема\n\n## Главное\n- \n\n## Термины\n- \n\n## Вопросы\n- "),
    NoteTemplate("План проекта", "План проекта", "# Проект\n\n## Цель\n\n## Этапы\n- [ ] \n- [ ] \n\n## Риски\n- "),
    NoteTemplate("Встреча", "Встреча", "# Встреча\n\n**Участники:** \n**Дата:** \n\n## Повестка\n- \n\n## Решения\n- \n\n## Задачи\n- [ ] "),
    NoteTemplate("Книга", "Книга", "# Название\n\n**Автор:** \n**Оценка:** \n\n## Цитаты\n- \n\n## Впечатления\n"),
    NoteTemplate("Фильм", "Фильм", "# Название\n\n**Год:** \n**Оценка:** \n\n## Впечатления\n"),
    NoteTemplate("Путешествие", "Путешествие", "# Куда\n\n**Даты:** \n\n## Маршрут\n- \n\n## Взять с собой\n- [ ] \n\n## Бюджет\n")
)
