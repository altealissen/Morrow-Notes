package app.morrow

import android.content.Context
import android.net.Uri
import androidx.compose.material3.Typography
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.font.Typeface
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.TextUnit
import java.io.File

val FontChoices = listOf("Системный", "Times", "Lora", "Пиксельный", "Свой файл")

/** The interface font. 0 system, 1 Times-like serif, 2 Lora, 3 pixel, 4 the user's own file. */
object AppFont {
    var choice by mutableIntStateOf(0)
    var customName by mutableStateOf("")
    private var custom by mutableStateOf<FontFamily?>(null)

    private val times = FontFamily(
        Font(R.font.liberation_serif, FontWeight.Normal),
        Font(R.font.liberation_serif_bold, FontWeight.Bold),
        Font(R.font.liberation_serif_italic, FontWeight.Normal, FontStyle.Italic)
    )
    private val lora = FontFamily(Font(R.font.lora, FontWeight.Normal))
    private val pixel = FontFamily(Font(R.font.morrow_pixel, FontWeight.Normal))

    /** null means the system default. */
    val family: FontFamily?
        get() = when (choice) {
            1 -> times
            2 -> lora
            3 -> pixel
            4 -> custom
            else -> null
        }

    private fun customFile(ctx: Context) = File(File(ctx.filesDir, "fonts").also { it.mkdirs() }, "custom.ttf")

    fun loadCustom(ctx: Context) {
        try {
            val f = customFile(ctx)
            if (f.exists()) custom = FontFamily(Typeface(android.graphics.Typeface.createFromFile(f)))
        } catch (_: Exception) {
        }
    }

    /** Copies a .ttf/.otf chosen by the user into the app. Returns an error text or null. */
    fun importCustom(ctx: Context, uri: Uri, displayName: String): String? {
        return try {
            val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return "Не удалось открыть файл"
            if (bytes.size < 64 || bytes.size > 20_000_000) return "Файл слишком большой или пустой"
            val sig = String(bytes, 0, 4, Charsets.ISO_8859_1)
            val ok = (bytes[0].toInt() == 0 && bytes[1].toInt() == 1 && bytes[2].toInt() == 0 && bytes[3].toInt() == 0) ||
                sig == "OTTO" || sig == "true" || sig == "ttcf"
            if (!ok) return "Это не файл шрифта (нужен .ttf или .otf)"
            customFile(ctx).writeBytes(bytes)
            loadCustom(ctx)
            customName = displayName
            choice = 4
            Repo.saveLater()
            null
        } catch (_: Exception) {
            "Не удалось загрузить шрифт"
        }
    }
}

/** Same as TextStyle(...) but with the chosen interface font as the default. */
fun AppStyle(
    fontSize: TextUnit = TextUnit.Unspecified,
    fontWeight: FontWeight? = null,
    fontStyle: FontStyle? = null,
    fontFamily: FontFamily? = null,
    color: Color = Color.Unspecified,
    letterSpacing: TextUnit = TextUnit.Unspecified,
    lineHeight: TextUnit = TextUnit.Unspecified,
    textAlign: TextAlign = TextAlign.Unspecified,
    textDecoration: TextDecoration? = null
): TextStyle = TextStyle(
    color = color,
    fontSize = fontSize,
    fontWeight = fontWeight,
    fontStyle = fontStyle,
    fontFamily = fontFamily ?: AppFont.family,
    letterSpacing = letterSpacing,
    lineHeight = lineHeight,
    textAlign = textAlign,
    textDecoration = textDecoration
)

/** Material typography with the chosen font in every style (buttons, dialogs, default text). */
fun fontTypography(): Typography {
    val b = Typography()
    val f = AppFont.family ?: return b
    return Typography(
        displayLarge = b.displayLarge.copy(fontFamily = f),
        displayMedium = b.displayMedium.copy(fontFamily = f),
        displaySmall = b.displaySmall.copy(fontFamily = f),
        headlineLarge = b.headlineLarge.copy(fontFamily = f),
        headlineMedium = b.headlineMedium.copy(fontFamily = f),
        headlineSmall = b.headlineSmall.copy(fontFamily = f),
        titleLarge = b.titleLarge.copy(fontFamily = f),
        titleMedium = b.titleMedium.copy(fontFamily = f),
        titleSmall = b.titleSmall.copy(fontFamily = f),
        bodyLarge = b.bodyLarge.copy(fontFamily = f),
        bodyMedium = b.bodyMedium.copy(fontFamily = f),
        bodySmall = b.bodySmall.copy(fontFamily = f),
        labelLarge = b.labelLarge.copy(fontFamily = f),
        labelMedium = b.labelMedium.copy(fontFamily = f),
        labelSmall = b.labelSmall.copy(fontFamily = f)
    )
}
