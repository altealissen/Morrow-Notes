package app.morrow

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ChevronLeft
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Today
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.TextStyle as JTextStyle

private fun monthTitle(d: LocalDate): String =
    d.month.getDisplayName(JTextStyle.FULL_STANDALONE, RU).replaceFirstChar { it.uppercase() } + " " + d.year

private fun monthFirstOf(epochDay: Long): LocalDate = LocalDate.ofEpochDay(epochDay).withDayOfMonth(1)

@Composable
fun PlannerScreen() {
    val todayDay = LocalDate.now().toEpochDay()
    val selected = UiState.plannerDay
    val monthFirst = monthFirstOf(UiState.plannerMonthDay)
    val weekMode = Prefs.plannerView == 1
    val byDay = Repo.events.groupBy { it.epochDay }

    fun select(day: Long) {
        UiState.plannerDay = day
        UiState.plannerMonthDay = monthFirstOf(day).toEpochDay()
    }

    Box(Modifier.fillMaxSize()) {
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp)
        ) {
            ScreenHeader(
                "Planner",
                if (weekMode) "Неделя" else monthTitle(monthFirst),
                trailing = {
                    IconButton(onClick = { select(todayDay) }) { Icon(Icons.Rounded.Today, "Сегодня", tint = MaterialTheme.colorScheme.primary) }
                }
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = {
                    if (weekMode) select(selected - 7)
                    else UiState.plannerMonthDay = monthFirst.minusMonths(1).toEpochDay()
                }) { Icon(Icons.Rounded.ChevronLeft, "Назад") }
                Text(
                    if (weekMode) weekTitle(selected) else monthTitle(monthFirst),
                    modifier = Modifier.weight(1f),
                    textAlign = TextAlign.Center,
                    style = AppStyle(fontSize = 17.sp, fontWeight = FontWeight.Medium),
                    color = MaterialTheme.colorScheme.onBackground
                )
                IconButton(onClick = {
                    if (weekMode) select(selected + 7)
                    else UiState.plannerMonthDay = monthFirst.plusMonths(1).toEpochDay()
                }) { Icon(Icons.Rounded.ChevronRight, "Вперёд") }
            }
            ChipRow(listOf("Месяц", "Неделя"), Prefs.plannerView) { Prefs.updatePlannerView(it) }
            Spacer(Modifier.height(10.dp))

            if (weekMode) {
                WeekList(selected, todayDay, byDay) { select(it) }
            } else {
                MCard(padding = 8.dp) {
                    MonthGrid(monthFirst, selected, todayDay, byDay) { select(it) }
                }
                Spacer(Modifier.height(14.dp))
                DayEvents(selected, todayDay)
            }
            Spacer(Modifier.height(96.dp))
        }
        ExtendedFloatingActionButton(
            onClick = { Nav.route = Route.EventEdit(0L, selected) },
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(16.dp),
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary,
            icon = { Icon(Icons.Rounded.Add, null) },
            text = { Text("Событие") }
        )
    }
}

private fun weekTitle(selected: Long): String {
    val d = LocalDate.ofEpochDay(selected)
    val monday = d.minusDays((d.dayOfWeek.value - 1).toLong())
    val sunday = monday.plusDays(6)
    return fmtDayMonth(monday) + " – " + fmtDayMonth(sunday)
}

@Composable
private fun MonthGrid(
    monthFirst: LocalDate,
    selected: Long,
    today: Long,
    byDay: Map<Long, List<Event>>,
    onSelect: (Long) -> Unit
) {
    val offset = monthFirst.dayOfWeek.value - 1
    val len = monthFirst.lengthOfMonth()
    val rows = (offset + len + 6) / 7
    Column {
        Row(Modifier.fillMaxWidth()) {
            for (d in DayNamesShort) {
                Text(
                    d,
                    modifier = Modifier
                        .weight(1f)
                        .padding(vertical = 6.dp),
                    textAlign = TextAlign.Center,
                    style = AppStyle(fontSize = 12.sp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        for (r in 0 until rows) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(54.dp)
            ) {
                for (c in 0 until 7) {
                    val dayNum = r * 7 + c - offset + 1
                    if (dayNum in 1..len) {
                        val epoch = monthFirst.toEpochDay() + dayNum - 1
                        DayCell(
                            Modifier.weight(1f),
                            dayNum,
                            epoch == selected,
                            epoch == today,
                            byDay[epoch] ?: emptyList()
                        ) { onSelect(epoch) }
                    } else {
                        Spacer(Modifier.weight(1f))
                    }
                }
            }
        }
    }
}

@Composable
private fun DayCell(
    modifier: Modifier,
    dayNum: Int,
    selected: Boolean,
    today: Boolean,
    events: List<Event>,
    onClick: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    Box(
        modifier
            .padding(2.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(if (selected) cs.primaryContainer else Color.Transparent)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                Modifier
                    .size(28.dp)
                    .clip(CircleShape)
                    .background(if (today) cs.primary else Color.Transparent),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    dayNum.toString(),
                    style = AppStyle(fontSize = 14.sp, fontWeight = if (today || selected) FontWeight.Bold else FontWeight.Normal),
                    color = if (today) cs.onPrimary else cs.onSurface
                )
            }
            Spacer(Modifier.height(3.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(2.dp), modifier = Modifier.height(6.dp)) {
                for (e in events.take(3)) {
                    ColorDot(e.color, 5.dp, Modifier.alpha(if (e.done) 0.4f else 1f))
                }
            }
        }
    }
}

@Composable
private fun WeekList(selected: Long, today: Long, byDay: Map<Long, List<Event>>, onSelect: (Long) -> Unit) {
    val d = LocalDate.ofEpochDay(selected)
    val monday = d.minusDays((d.dayOfWeek.value - 1).toLong())
    val cs = MaterialTheme.colorScheme
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        for (i in 0 until 7) {
            val date = monday.plusDays(i.toLong())
            val epoch = date.toEpochDay()
            val events = (byDay[epoch] ?: emptyList()).sortedBy { it.startMin }
            val isSel = epoch == selected
            val isToday = epoch == today
            MCard(
                onClick = { onSelect(epoch) },
                padding = 12.dp,
                containerColor = if (isSel) cs.primaryContainer else cs.surface
            ) {
                Row(verticalAlignment = Alignment.Top) {
                    Column(Modifier.width(48.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            DayNamesShort[i],
                            style = AppStyle(fontSize = 12.sp),
                            color = cs.onSurfaceVariant
                        )
                        Text(
                            date.dayOfMonth.toString(),
                            style = AppStyle(fontSize = 22.sp, fontWeight = if (isToday) FontWeight.Bold else FontWeight.Light),
                            color = if (isToday) cs.primary else cs.onSurface
                        )
                    }
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        if (events.isEmpty()) {
                            Hint("Свободно", Modifier.padding(top = 10.dp))
                        }
                        for (e in events) {
                            Row(
                                Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(Color(e.color).copy(alpha = 0.18f))
                                    .clickable { Nav.route = Route.EventEdit(e.id, e.epochDay) }
                                    .padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                ColorDot(e.color, 8.dp)
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    fmtTime(e.startMin) + "  " + e.title.ifBlank { "Без названия" },
                                    style = AppStyle(
                                        fontSize = 14.sp,
                                        textDecoration = if (e.done) TextDecoration.LineThrough else TextDecoration.None
                                    ),
                                    color = cs.onSurface,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DayEvents(selected: Long, today: Long) {
    val events = Repo.eventsOn(selected)
    Text(
        dateLabel(selected, today) + " · " + fmtLongDate(LocalDate.ofEpochDay(selected)),
        style = AppStyle(fontSize = 15.sp, fontWeight = FontWeight.Medium),
        color = MaterialTheme.colorScheme.onBackground
    )
    Spacer(Modifier.height(8.dp))
    if (events.isEmpty()) {
        MCard { Hint("В этот день пока ничего нет. Нажмите «Событие», чтобы добавить.") }
    } else {
        MCard(padding = 8.dp) {
            for (e in events) EventRow(e, showDate = false)
        }
    }
}

@Composable
fun EventRow(e: Event, showDate: Boolean) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable { Nav.route = Route.EventEdit(e.id, e.epochDay) }
            .padding(vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Checkbox(
            checked = e.done,
            onCheckedChange = {
                Repo.setEventDone(e, it)
                Scheduler.rescheduleAll(ctx)
            }
        )
        Box(
            Modifier
                .width(4.dp)
                .height(36.dp)
                .clip(RoundedCornerShape(2.dp))
                .background(Color(e.color))
        )
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(
                e.title.ifBlank { "Без названия" },
                style = AppStyle(
                    fontSize = 16.sp,
                    textDecoration = if (e.done) TextDecoration.LineThrough else TextDecoration.None
                ),
                color = if (e.done) cs.onSurfaceVariant else cs.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            val range = fmtTime(e.startMin) + "–" + fmtTime((e.startMin + e.durationMin) % (24 * 60))
            val remind = if (e.remindMin >= 0) " · 🔔" else ""
            Hint((if (showDate) fmtDayMonth(e.date) + ", " else "") + range + remind)
        }
    }
}

// =====================================================================================
//  Event editor
// =====================================================================================

@Composable
fun NumberInputDialog(
    title: String,
    hint: String,
    initial: Int,
    onDismiss: () -> Unit,
    onConfirm: (Int) -> Unit
) {
    var text by remember { mutableStateOf(if (initial > 0) initial.toString() else "") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { v -> text = v.filter { it.isDigit() }.take(6) },
                label = { Text(hint) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
            )
        },
        confirmButton = {
            TextButton(
                onClick = {
                    val n = text.toIntOrNull()
                    if (n != null && n > 0) onConfirm(n)
                },
                enabled = (text.toIntOrNull() ?: 0) > 0
            ) { Text("OK") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )
}

@Composable
private fun IntChips(
    values: List<Int>,
    selected: Int,
    label: (Int) -> String,
    onSelect: (Int) -> Unit,
    customLabel: String,
    onCustom: () -> Unit
) {
    val all = if (selected in values) values else values + selected
    Row(
        Modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        for (v in all) {
            FilterChip(selected = v == selected, onClick = { onSelect(v) }, label = { Text(label(v)) })
        }
        AssistChip(onClick = onCustom, label = { Text(customLabel) })
    }
}

@Composable
fun EventEditor(id: Long, epochDay: Long, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val existing = remember(id) { Repo.eventById(id) }
    val today = LocalDate.now().toEpochDay()
    val defaultStart = if (epochDay == today) (LocalTime.now().hour + 1).coerceAtMost(23) * 60 else 9 * 60

    var title by remember { mutableStateOf(existing?.title ?: "") }
    var desc by remember { mutableStateOf(existing?.description ?: "") }
    var day by remember { mutableLongStateOf(existing?.epochDay ?: epochDay) }
    var start by remember { mutableIntStateOf(existing?.startMin ?: defaultStart) }
    var duration by remember { mutableIntStateOf(existing?.durationMin ?: 60) }
    var color by remember { mutableIntStateOf(existing?.color ?: Swatches[0]) }
    var remind by remember { mutableIntStateOf(existing?.remindMin ?: 15) }
    var done by remember { mutableStateOf(existing?.done ?: false) }
    var repeat by remember { mutableIntStateOf(existing?.repeat ?: 0) }
    var repeatN by remember { mutableIntStateOf(existing?.repeatN ?: 1) }

    var showDate by remember { mutableStateOf(false) }
    var showTime by remember { mutableStateOf(false) }
    var showDelete by remember { mutableStateOf(false) }
    var showCustomDuration by remember { mutableStateOf(false) }
    var showCustomRemind by remember { mutableStateOf(false) }

    fun save() {
        val old = existing
        val keepFired = old != null && old.epochDay == day && old.startMin == start &&
            old.remindMin == remind && old.reminderFired
        val e = Event(
            id = old?.id ?: Repo.newId(),
            title = title.trim(),
            description = desc.trim(),
            epochDay = day,
            startMin = start,
            durationMin = duration,
            color = color,
            done = done,
            remindMin = remind,
            reminderFired = keepFired,
            repeat = repeat,
            repeatN = repeatN
        )
        Repo.upsertEvent(if (done && repeat != 0) Repo.advance(e) else e)
        Repo.saveNow()
        Scheduler.rescheduleAll(ctx)
        UiState.plannerDay = day
        UiState.plannerMonthDay = LocalDate.ofEpochDay(day).withDayOfMonth(1).toEpochDay()
        onClose()
    }

    EditorFrame {
        TopBarRow(if (existing == null) "Новое событие" else "Событие", onClose) {
            if (existing != null) {
                IconButton(onClick = { showDelete = true }) { Icon(Icons.Rounded.Delete, "Удалить") }
            }
            TextButton(onClick = { save() }, enabled = title.isNotBlank()) { Text("Сохранить") }
        }
        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("Название") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = desc,
                onValueChange = { desc = it },
                label = { Text("Описание") },
                minLines = 2,
                maxLines = 6,
                modifier = Modifier.fillMaxWidth()
            )
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MCard(Modifier.weight(1f), onClick = { showDate = true }) {
                    SmallLabel("Дата")
                    Spacer(Modifier.height(4.dp))
                    Text(
                        fmtDayMonth(LocalDate.ofEpochDay(day)),
                        style = AppStyle(fontSize = 18.sp),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
                MCard(Modifier.weight(1f), onClick = { showTime = true }) {
                    SmallLabel("Начало")
                    Spacer(Modifier.height(4.dp))
                    Text(
                        fmtTime(start),
                        style = AppStyle(fontSize = 18.sp),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
            SmallLabel("Продолжительность")
            IntChips(
                values = listOf(15, 30, 45, 60, 90, 120),
                selected = duration,
                label = { fmtDuration(it) },
                onSelect = { duration = it },
                customLabel = "Другая…",
                onCustom = { showCustomDuration = true }
            )
            Hint("Закончится в " + fmtTime((start + duration) % (24 * 60)))
            SmallLabel("Цвет")
            SwatchPicker(color, { color = it })
            SmallLabel("Повторение")
            val repeatKinds = listOf(0, 1, 2, 6, 3, 4, 5)
            ChipRow(
                listOf("Нет", "Каждый день", "Каждую неделю", "По дням", "Каждый месяц", "Каждый год", "Каждые N дней"),
                repeatKinds.indexOf(repeat).coerceAtLeast(0)
            ) {
                repeat = repeatKinds[it]
                if (repeat == 6 && repeatN <= 1) repeatN = 1 shl (LocalDate.ofEpochDay(day).dayOfWeek.value - 1)
                if (repeat == 5 && repeatN < 2) repeatN = 2
            }
            if (repeat == 6) {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    for (i in 0..6) {
                        FilterChip(
                            selected = (repeatN shr i) and 1 == 1,
                            onClick = { repeatN = repeatN xor (1 shl i) },
                            label = { Text(DayNamesShort[i], fontSize = 11.sp) }
                        )
                    }
                }
            }
            if (repeat == 5) {
                Hint("Раз в " + repeatN + " дн.")
                Slider(repeatN.toFloat(), { repeatN = it.toInt() }, valueRange = 2f..30f, steps = 27)
            }
            if (repeat != 0) Hint("В календаре показано ближайшее повторение: после выполнения событие переходит на следующую дату.")
            SmallLabel("Напоминание")
            IntChips(
                values = listOf(-1, 0, 5, 10, 15, 30, 60, 1440),
                selected = remind,
                label = { remindLabel(it) },
                onSelect = { remind = it },
                customLabel = "Свой интервал…",
                onCustom = { showCustomRemind = true }
            )
            if (existing != null) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "Выполнено",
                        Modifier.weight(1f),
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Switch(checked = done, onCheckedChange = { done = it })
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }

    if (showDate) {
        DatePickerDialogM(day, { showDate = false }) { day = it; showDate = false }
    }
    if (showTime) {
        TimePickerDialogM(start / 60, start % 60, { showTime = false }) { h, m ->
            start = h * 60 + m
            showTime = false
        }
    }
    if (showCustomDuration) {
        NumberInputDialog("Продолжительность", "Минут", duration, { showCustomDuration = false }) {
            duration = it.coerceAtMost(24 * 60 - 1)
            showCustomDuration = false
        }
    }
    if (showCustomRemind) {
        NumberInputDialog("Напомнить за", "Минут до начала", if (remind > 0) remind else 0, { showCustomRemind = false }) {
            remind = it
            showCustomRemind = false
        }
    }
    if (showDelete && existing != null) {
        ConfirmDialog(
            title = "Удалить событие?",
            text = "Событие «" + existing.title + "» будет удалено.",
            confirmLabel = "Удалить",
            onConfirm = {
                Repo.deleteEvent(existing.id)
                Repo.saveNow()
                Scheduler.rescheduleAll(ctx)
                showDelete = false
                onClose()
            },
            onDismiss = { showDelete = false }
        )
    }
}
