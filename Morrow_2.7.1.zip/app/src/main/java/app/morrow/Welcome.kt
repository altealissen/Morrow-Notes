package app.morrow

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.Box
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

/** First launch: animated welcome with the name prompt. */
@Composable
fun WelcomeScreen(onDone: (String) -> Unit) {
    var name by remember { mutableStateOf(Life.userName) }
    var step by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) {
        delay(250); step = 1
        delay(550); step = 2
        delay(550); step = 3
    }
    val logo by animateFloatAsState(
        if (step >= 1) 1f else 0f,
        spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow), label = "logo"
    )
    val line by animateFloatAsState(if (step >= 2) 1f else 0f, tween(700), label = "line")
    val form by animateFloatAsState(if (step >= 3) 1f else 0f, tween(700), label = "form")
    val cream = Color(0xFFF4F0E6)
    val fog = rememberInfiniteTransition(label = "fog")
    val drift by fog.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(16000, easing = LinearEasing)), label = "drift"
    )

    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF14201A), Color(0xFF1F2D25), Color(0xFF2B3E33))))
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            for (i in 0 until 3) {
                val phase = (drift + i / 3f) % 1f
                val x = w * (0.1f + 0.8f * phase)
                val y = h * (0.25f + 0.2f * i)
                drawCircle(
                    Brush.radialGradient(
                        listOf(Color(0x22DCE8DD), Color.Transparent),
                        center = Offset(x, y), radius = w * 0.55f
                    ),
                    radius = w * 0.55f, center = Offset(x, y)
                )
            }
        }
        Column(
            Modifier.fillMaxSize().systemBarsPadding().imePadding().padding(horizontal = 32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Row(
                verticalAlignment = Alignment.Bottom,
                modifier = Modifier.graphicsLayer { alpha = logo; scaleX = 0.7f + 0.3f * logo; scaleY = 0.7f + 0.3f * logo }
            ) {
                Text("morrow", color = cream, style = AppStyle(fontSize = 48.sp, fontWeight = FontWeight.Light))
                Text(
                    "1", color = Color(0xFFFF4455),
                    modifier = Modifier.padding(start = 4.dp, bottom = 4.dp),
                    style = AppStyle(fontSize = 34.sp, fontWeight = FontWeight.Bold)
                )
            }
            Spacer(Modifier.height(14.dp))
            Text(
                "Твой день, твои заметки, твой ритм.\nВсё остаётся на этом телефоне.",
                color = Color(0xFFB9C7BC), textAlign = TextAlign.Center,
                style = AppStyle(fontSize = 15.sp),
                modifier = Modifier.graphicsLayer { alpha = line; translationY = (1f - line) * 24f }
            )
            Spacer(Modifier.height(36.dp))
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.graphicsLayer { alpha = form; translationY = (1f - form) * 32f }
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it.take(30) },
                    label = { Text("Как к тебе обращаться?") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = cream, unfocusedTextColor = cream, cursorColor = cream,
                        focusedBorderColor = Color(0xFF9ED58B), unfocusedBorderColor = Color(0xFF5E6F64),
                        focusedLabelColor = Color(0xFF9ED58B), unfocusedLabelColor = Color(0xFFB9C7BC)
                    )
                )
                Spacer(Modifier.height(18.dp))
                Button(onClick = { onDone(name.trim()) }, enabled = step >= 3) {
                    Text(if (name.isBlank()) "Начать без имени" else "Начать")
                }
            }
        }
    }
}
