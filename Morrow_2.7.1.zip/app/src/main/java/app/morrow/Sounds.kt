package app.morrow

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.PowerManager
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

class SystemSound(val title: String, val uri: String)

object Sounds {
    /** Alarm tones that ship with the phone (on OnePlus these are the OnePlus alarm sounds). */
    fun systemAlarmSounds(ctx: Context): List<SystemSound> {
        val out = ArrayList<SystemSound>()
        try {
            val rm = RingtoneManager(ctx)
            rm.setType(RingtoneManager.TYPE_ALARM)
            val c = rm.cursor
            while (c.moveToNext()) {
                val title = c.getString(RingtoneManager.TITLE_COLUMN_INDEX) ?: "Звук"
                val uri = rm.getRingtoneUri(c.position)
                if (uri != null) out.add(SystemSound(title, uri.toString()))
            }
        } catch (_: Exception) {
        }
        return out
    }

    fun displayName(ctx: Context, uri: Uri): String {
        try {
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val n = c.getString(0)
                    if (!n.isNullOrBlank()) return n
                }
            }
        } catch (_: Exception) {
        }
        return "Свой звук"
    }

    /** Builds a prepared player for [uriStr], falling back to the default alarm / ringtone. */
    fun buildPlayer(ctx: Context, uriStr: String, loop: Boolean): MediaPlayer? {
        val candidates = ArrayList<Uri>()
        if (uriStr.isNotEmpty()) candidates.add(Uri.parse(uriStr))
        RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)?.let { candidates.add(it) }
        RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)?.let { candidates.add(it) }
        for (u in candidates) {
            val mp = MediaPlayer()
            try {
                mp.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                mp.setWakeMode(ctx, PowerManager.PARTIAL_WAKE_LOCK)
                mp.setDataSource(ctx, u)
                mp.isLooping = loop
                mp.prepare()
                return mp
            } catch (_: Exception) {
                try {
                    mp.release()
                } catch (_: Exception) {
                }
            }
        }
        return null
    }
}

/** Short preview used by the alarm editor. */
object SoundPreview {
    private var player: MediaPlayer? = null
    var playingKey by mutableStateOf("")

    fun toggle(ctx: Context, key: String, uri: String, volume: Float) {
        if (playingKey == key) {
            stop()
            return
        }
        stop()
        val mp = Sounds.buildPlayer(ctx.applicationContext, uri, false) ?: return
        mp.setVolume(volume, volume)
        mp.setOnCompletionListener { stop() }
        try {
            mp.start()
            player = mp
            playingKey = key
        } catch (_: Exception) {
            try {
                mp.release()
            } catch (_: Exception) {
            }
        }
    }

    fun stop() {
        try {
            player?.stop()
        } catch (_: Exception) {
        }
        try {
            player?.release()
        } catch (_: Exception) {
        }
        player = null
        playingKey = ""
    }
}
