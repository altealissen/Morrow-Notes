package app.morrow

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextDecoration

// =====================================================================================
//  Inline markup used by notes:  **bold**  *italic*  __underline__  [text](url)  https://...
//  Lines:  "# " "## " headings, "- " list, "- [ ] " / "- [x] " checklist
// =====================================================================================

enum class SpanKind { BOLD, ITALIC, UNDER, LINK, URL }

data class MSpan(
    val kind: SpanKind,
    val start: Int,
    val end: Int,
    val cStart: Int,
    val cEnd: Int,
    val url: String = ""
)

private val linkRe = Regex("""\[([^\]\n]+)\]\(([^)\s]+)\)""")
private val urlRe = Regex("""https?://[^\s)\]]+""")

fun parseInline(t: String): List<MSpan> {
    val out = ArrayList<MSpan>()
    var i = 0
    val n = t.length
    while (i < n) {
        val c = t[i]
        if (c == '*' && t.startsWith("**", i)) {
            val j = t.indexOf("**", i + 2)
            if (j > i + 2 && t.indexOf('\n', i) !in (i + 1) until j) {
                out.add(MSpan(SpanKind.BOLD, i, j + 2, i + 2, j))
                i = j + 2
                continue
            }
            i += 2
            continue
        }
        if (c == '_' && t.startsWith("__", i)) {
            val j = t.indexOf("__", i + 2)
            if (j > i + 2 && t.indexOf('\n', i) !in (i + 1) until j) {
                out.add(MSpan(SpanKind.UNDER, i, j + 2, i + 2, j))
                i = j + 2
                continue
            }
            i += 2
            continue
        }
        if (c == '*' && i + 1 < n && t[i + 1] != ' ' && t[i + 1] != '*') {
            val j = t.indexOf('*', i + 1)
            if (j > i + 1 && t.indexOf('\n', i) !in (i + 1) until j) {
                out.add(MSpan(SpanKind.ITALIC, i, j + 1, i + 1, j))
                i = j + 1
                continue
            }
            i++
            continue
        }
        if (c == '[') {
            val m = linkRe.find(t, i)
            if (m != null && m.range.first == i) {
                val textGroup = m.groups[1]
                val urlGroup = m.groups[2]
                if (textGroup != null && urlGroup != null) {
                    out.add(
                        MSpan(
                            SpanKind.LINK, i, m.range.last + 1,
                            textGroup.range.first, textGroup.range.last + 1, urlGroup.value
                        )
                    )
                    i = m.range.last + 1
                    continue
                }
            }
            i++
            continue
        }
        if (c == 'h' && (t.startsWith("http://", i) || t.startsWith("https://", i))) {
            val m = urlRe.find(t, i)
            if (m != null && m.range.first == i) {
                out.add(MSpan(SpanKind.URL, i, m.range.last + 1, i, m.range.last + 1, m.value))
                i = m.range.last + 1
                continue
            }
        }
        i++
    }
    return out
}

fun normalizeUrl(u: String): String =
    if (u.startsWith("http://") || u.startsWith("https://") || u.contains("://")) u else "https://$u"

/** Used inside the editor: markers stay in the text (dimmed) so offsets never change. */
class NoteTransformation(
    private val red: Boolean,
    private val redColor: Color,
    private val dim: Color,
    private val linkColor: Color,
    private val headingColor: Color
) : VisualTransformation {
    private var lastText: String? = null
    private var lastResult: TransformedText? = null

    override fun filter(text: AnnotatedString): TransformedText {
        val s = text.text
        val cached = lastResult
        if (cached != null && lastText == s) return cached
        val out = build(s)
        lastText = s
        lastResult = out
        return out
    }

    private fun build(s: String): TransformedText {
        val b = AnnotatedString.Builder(s)
        // line-level styles
        var pos = 0
        while (pos <= s.length) {
            var end = s.indexOf('\n', pos)
            if (end < 0) end = s.length
            if (s.startsWith("# ", pos) || s.startsWith("## ", pos)) {
                b.addStyle(SpanStyle(fontWeight = FontWeight.Bold, color = headingColor), pos, end)
            } else if (s.startsWith("- [x] ", pos)) {
                b.addStyle(SpanStyle(color = dim), pos, pos + 6)
                b.addStyle(SpanStyle(textDecoration = TextDecoration.LineThrough, color = dim), pos + 6, end)
            } else if (s.startsWith("- [ ] ", pos) || s.startsWith("- ", pos)) {
                val markerEnd = if (s.startsWith("- [ ] ", pos)) pos + 6 else pos + 2
                b.addStyle(SpanStyle(color = headingColor, fontWeight = FontWeight.Bold), pos, markerEnd)
            }
            if (end >= s.length) break
            pos = end + 1
        }
        for (sp in parseInline(s)) {
            when (sp.kind) {
                SpanKind.BOLD -> b.addStyle(SpanStyle(fontWeight = FontWeight.Bold), sp.cStart, sp.cEnd)
                SpanKind.ITALIC -> b.addStyle(SpanStyle(fontStyle = FontStyle.Italic), sp.cStart, sp.cEnd)
                SpanKind.UNDER -> b.addStyle(SpanStyle(textDecoration = TextDecoration.Underline), sp.cStart, sp.cEnd)
                SpanKind.LINK -> b.addStyle(
                    SpanStyle(color = linkColor, textDecoration = TextDecoration.Underline), sp.cStart, sp.cEnd
                )
                SpanKind.URL -> b.addStyle(
                    SpanStyle(color = linkColor, textDecoration = TextDecoration.Underline), sp.start, sp.end
                )
            }
            if (sp.kind != SpanKind.URL) {
                b.addStyle(SpanStyle(color = dim, fontWeight = FontWeight.Normal), sp.start, sp.cStart)
                b.addStyle(SpanStyle(color = dim, fontWeight = FontWeight.Normal), sp.cEnd, sp.end)
            }
        }
        if (red) {
            for (i in s.indices) {
                if (s[i] == '1') b.addStyle(SpanStyle(color = redColor), i, i + 1)
            }
        }
        return TransformedText(b.toAnnotatedString(), OffsetMapping.Identity)
    }
}

/** Only colors every digit 1 (used for titles and quick fields). */
class RedOneTransformation(
    private val red: Boolean,
    private val redColor: Color
) : VisualTransformation {
    override fun filter(text: AnnotatedString): TransformedText {
        val s = text.text
        val b = AnnotatedString.Builder(s)
        if (red) {
            for (i in s.indices) {
                if (s[i] == '1') b.addStyle(SpanStyle(color = redColor), i, i + 1)
            }
        }
        return TransformedText(b.toAnnotatedString(), OffsetMapping.Identity)
    }
}

/** Renders inline markup without markers; every digit 1 is red when [red] is set. */
fun renderInline(src: String, red: Boolean, redColor: Color, linkColor: Color): AnnotatedString {
    val b = AnnotatedString.Builder()
    var i = 0
    for (sp in parseInline(src)) {
        if (sp.start > i) b.append(src.substring(i, sp.start))
        val from = b.length
        b.append(src.substring(sp.cStart, sp.cEnd))
        val to = b.length
        when (sp.kind) {
            SpanKind.BOLD -> b.addStyle(SpanStyle(fontWeight = FontWeight.Bold), from, to)
            SpanKind.ITALIC -> b.addStyle(SpanStyle(fontStyle = FontStyle.Italic), from, to)
            SpanKind.UNDER -> b.addStyle(SpanStyle(textDecoration = TextDecoration.Underline), from, to)
            SpanKind.LINK, SpanKind.URL -> {
                b.addStyle(SpanStyle(color = linkColor, textDecoration = TextDecoration.Underline), from, to)
                b.addStringAnnotation("URL", normalizeUrl(sp.url), from, to)
            }
        }
        i = sp.end
    }
    if (i < src.length) b.append(src.substring(i))
    if (red) {
        val plain = b.toAnnotatedString().text
        for (k in plain.indices) {
            if (plain[k] == '1') b.addStyle(SpanStyle(color = redColor), k, k + 1)
        }
    }
    return b.toAnnotatedString()
}

sealed interface Block {
    data class Heading(val level: Int, val text: String) : Block
    data class Bullet(val text: String) : Block
    data class Check(val line: Int, val checked: Boolean, val text: String) : Block
    data class Para(val text: String) : Block
    object Blank : Block
}

fun parseBlocks(body: String): List<Block> {
    val out = ArrayList<Block>()
    body.split('\n').forEachIndexed { idx, line ->
        when {
            line.startsWith("## ") -> out.add(Block.Heading(2, line.substring(3)))
            line.startsWith("# ") -> out.add(Block.Heading(1, line.substring(2)))
            line.startsWith("- [x] ") -> out.add(Block.Check(idx, true, line.substring(6)))
            line.startsWith("- [ ] ") -> out.add(Block.Check(idx, false, line.substring(6)))
            line.startsWith("- ") -> out.add(Block.Bullet(line.substring(2)))
            line.isBlank() -> out.add(Block.Blank)
            else -> out.add(Block.Para(line))
        }
    }
    return out
}

fun toggleCheckLine(body: String, lineIndex: Int): String {
    val lines = body.split('\n').toMutableList()
    if (lineIndex !in lines.indices) return body
    val l = lines[lineIndex]
    lines[lineIndex] = when {
        l.startsWith("- [ ] ") -> "- [x] " + l.substring(6)
        l.startsWith("- [x] ") -> "- [ ] " + l.substring(6)
        else -> l
    }
    return lines.joinToString("\n")
}

/** Short plain-text preview for note cards (markers removed). */
fun previewText(body: String, maxLines: Int = 3): String {
    val lines = body.split('\n').filter { it.isNotBlank() }.take(maxLines)
    return lines.joinToString("\n") { l ->
        val stripped = when {
            l.startsWith("## ") -> l.substring(3)
            l.startsWith("# ") -> l.substring(2)
            l.startsWith("- [x] ") -> "☑ " + l.substring(6)
            l.startsWith("- [ ] ") -> "☐ " + l.substring(6)
            l.startsWith("- ") -> "• " + l.substring(2)
            else -> l
        }
        stripped
    }
}

// ----------------------------------------------------------------- formatting commands

fun TextFieldValue.wrapSelection(marker: String): TextFieldValue {
    val s = selection.min
    val e = selection.max
    val t = text
    val m = marker.length
    return if (s >= m && e + m <= t.length &&
        t.substring(s - m, s) == marker && t.substring(e, e + m) == marker
    ) {
        val nt = t.substring(0, s - m) + t.substring(s, e) + t.substring(e + m)
        copy(text = nt, selection = TextRange(s - m, e - m))
    } else {
        val nt = t.substring(0, s) + marker + t.substring(s, e) + marker + t.substring(e)
        copy(text = nt, selection = TextRange(s + m, e + m))
    }
}

private fun stripListPrefix(line: String): String = when {
    line.startsWith("- [ ] ") -> line.substring(6)
    line.startsWith("- [x] ") -> line.substring(6)
    line.startsWith("- ") -> line.substring(2)
    line.startsWith("## ") -> line.substring(3)
    line.startsWith("# ") -> line.substring(2)
    else -> line
}

private fun TextFieldValue.mapSelectedLines(transform: (List<String>) -> List<String>): TextFieldValue {
    val t = text
    val s = selection.min.coerceIn(0, t.length)
    val e = selection.max.coerceIn(0, t.length)
    val lineStart = if (s == 0) 0 else t.lastIndexOf('\n', s - 1) + 1
    var lineEnd = t.indexOf('\n', e)
    if (lineEnd < 0) lineEnd = t.length
    val block = t.substring(lineStart, lineEnd)
    val newBlock = transform(block.split('\n')).joinToString("\n")
    val nt = t.substring(0, lineStart) + newBlock + t.substring(lineEnd)
    return copy(text = nt, selection = TextRange(lineStart, lineStart + newBlock.length))
}

fun TextFieldValue.toggleLinePrefix(prefix: String): TextFieldValue = mapSelectedLines { lines ->
    val allHave = lines.all { it.startsWith(prefix) }
    if (allHave) lines.map { it.substring(prefix.length) }
    else lines.map { prefix + stripListPrefix(it) }
}

fun TextFieldValue.cycleHeading(): TextFieldValue = mapSelectedLines { lines ->
    val first = lines.firstOrNull() ?: ""
    when {
        first.startsWith("## ") -> lines.map { stripListPrefix(it) }
        first.startsWith("# ") -> lines.map { "## " + stripListPrefix(it) }
        else -> lines.map { "# " + stripListPrefix(it) }
    }
}

fun TextFieldValue.insertLink(): TextFieldValue {
    val s = selection.min
    val e = selection.max
    val t = text
    return if (s != e) {
        val sel = t.substring(s, e)
        val nt = t.substring(0, s) + "[" + sel + "](https://)" + t.substring(e)
        val urlStart = s + sel.length + 3
        copy(text = nt, selection = TextRange(urlStart, urlStart + 8))
    } else {
        val ins = "[текст](https://)"
        val nt = t.substring(0, s) + ins + t.substring(s)
        copy(text = nt, selection = TextRange(s + 1, s + 6))
    }
}

// =====================================================================================
//  Syntax highlighting for the code editor
// =====================================================================================

enum class Tok { KEYWORD, STRING, COMMENT, NUMBER, TYPE, TAG, ATTR }

data class Hl(val start: Int, val end: Int, val tok: Tok)

class Lang(val id: String, val title: String, val ext: List<String>)

val Languages = listOf(
    Lang("kotlin", "Kotlin", listOf("kt", "kts")),
    Lang("java", "Java", listOf("java")),
    Lang("python", "Python", listOf("py")),
    Lang("javascript", "JavaScript", listOf("js", "mjs", "ts")),
    Lang("html", "HTML", listOf("html", "htm")),
    Lang("css", "CSS", listOf("css")),
    Lang("json", "JSON", listOf("json")),
    Lang("xml", "XML", listOf("xml", "svg")),
    Lang("markdown", "Markdown", listOf("md", "markdown")),
    Lang("cpp", "C/C++", listOf("c", "h", "cpp", "hpp", "cc")),
    Lang("text", "Текст", listOf("txt", "log"))
)

fun languageTitle(id: String): String = Languages.firstOrNull { it.id == id }?.title ?: "Текст"

fun languageForName(name: String): String {
    val ext = name.substringAfterLast('.', "").lowercase()
    return Languages.firstOrNull { ext in it.ext }?.id ?: "text"
}

private fun words(s: String): Set<String> = s.split(' ').filter { it.isNotEmpty() }.toSet()

private val kotlinKw = words(
    "as break class continue do else false for fun if in interface is null object package return super this throw true try typealias val var when while by catch constructor delegate dynamic field file finally get import init param property receiver set setparam value where abstract actual annotation companion const crossinline data enum expect external final infix inline inner internal lateinit noinline open operator out override private protected public reified sealed suspend tailrec vararg"
)
private val javaKw = words(
    "abstract assert boolean break byte case catch char class const continue default do double else enum extends final finally float for goto if implements import instanceof int interface long native new package private protected public return short static strictfp super switch synchronized this throw throws transient try void volatile while true false null var record"
)
private val pyKw = words(
    "False None True and as assert async await break class continue def del elif else except finally for from global if import in is lambda nonlocal not or pass raise return try while with yield match case self"
)
private val jsKw = words(
    "break case catch class const continue debugger default delete do else export extends finally for function if import in instanceof let new return super switch this throw try typeof var void while with yield async await of true false null undefined static get set interface type enum implements"
)
private val cppKw = words(
    "alignas auto bool break case catch char class const constexpr continue default delete do double else enum explicit extern false float for friend goto if inline int long mutable namespace new noexcept nullptr operator private protected public register return short signed sizeof static struct switch template this throw true try typedef typename union unsigned using virtual void volatile while include define ifdef ifndef endif pragma"
)

private val cLikeRe = Regex(
    "//[^\\n]*" +
        "|/\\*[\\s\\S]*?(?:\\*/|$)" +
        "|\"\"\"[\\s\\S]*?(?:\"\"\"|$)" +
        "|\"(?:\\\\.|[^\"\\\\\\n])*\"?" +
        "|'(?:\\\\.|[^'\\\\\\n])*'?" +
        "|`(?:\\\\.|[^`\\\\])*`?" +
        "|0[xX][0-9a-fA-F_]+|\\b\\d[\\d_]*(?:\\.\\d+)?(?:[eE][+-]?\\d+)?[fFLuU]*" +
        "|@[A-Za-z_][A-Za-z_0-9]*" +
        "|#[A-Za-z_]+" +
        "|[A-Za-z_][A-Za-z_0-9]*"
)

private val pyRe = Regex(
    "#[^\\n]*" +
        "|\"\"\"[\\s\\S]*?(?:\"\"\"|$)" +
        "|'''[\\s\\S]*?(?:'''|$)" +
        "|\"(?:\\\\.|[^\"\\\\\\n])*\"?" +
        "|'(?:\\\\.|[^'\\\\\\n])*'?" +
        "|\\b\\d[\\d_]*(?:\\.\\d+)?(?:[eE][+-]?\\d+)?" +
        "|@[A-Za-z_][A-Za-z_0-9.]*" +
        "|[A-Za-z_][A-Za-z_0-9]*"
)

private val jsonRe = Regex(
    "\"(?:\\\\.|[^\"\\\\\\n])*\"" +
        "|-?\\b\\d+(?:\\.\\d+)?(?:[eE][+-]?\\d+)?\\b" +
        "|\\b(?:true|false|null)\\b"
)

private val markupRe = Regex(
    "<!--[\\s\\S]*?(?:-->|$)" +
        "|</?[A-Za-z][\\w:.-]*" +
        "|/?>" +
        "|[A-Za-z_:][\\w:.-]*(?=\\s*=)" +
        "|\"[^\"]*\"|'[^']*'"
)

private val cssRe = Regex(
    "/\\*[\\s\\S]*?(?:\\*/|$)" +
        "|\"(?:\\\\.|[^\"\\\\\\n])*\"?|'(?:\\\\.|[^'\\\\\\n])*'?" +
        "|#[0-9a-fA-F]{3,8}\\b" +
        "|-?\\b\\d+(?:\\.\\d+)?(?:[a-z%]+)?" +
        "|@[A-Za-z-]+" +
        "|[A-Za-z-]+(?=\\s*:)" +
        "|[.#][A-Za-z_][\\w-]*"
)

private val mdRe = Regex(
    "(?m)^#{1,6}\\s.*$" +
        "|\\*\\*[^*\\n]+\\*\\*" +
        "|`[^`\\n]+`" +
        "|\\[[^\\]\\n]*\\]\\([^)\\n]*\\)" +
        "|(?m)^\\s*(?:[-*+]|\\d+\\.)\\s"
)

fun highlight(text: String, lang: String): List<Hl> {
    if (text.length > 150_000 || lang == "text") return emptyList()
    val out = ArrayList<Hl>()
    when (lang) {
        "kotlin", "java", "javascript", "cpp" -> {
            val kw = when (lang) {
                "kotlin" -> kotlinKw
                "java" -> javaKw
                "javascript" -> jsKw
                else -> cppKw
            }
            for (m in cLikeRe.findAll(text)) {
                val v = m.value
                val tok: Tok? = when {
                    v.startsWith("//") || v.startsWith("/*") -> Tok.COMMENT
                    v[0] == '"' || v[0] == '\'' || v[0] == '`' -> Tok.STRING
                    v[0].isDigit() -> Tok.NUMBER
                    v[0] == '@' -> Tok.TYPE
                    v[0] == '#' -> if (lang == "cpp") Tok.KEYWORD else null
                    v in kw -> Tok.KEYWORD
                    v[0].isUpperCase() -> Tok.TYPE
                    else -> null
                }
                if (tok != null) out.add(Hl(m.range.first, m.range.last + 1, tok))
            }
        }
        "python" -> {
            for (m in pyRe.findAll(text)) {
                val v = m.value
                val tok: Tok? = when {
                    v[0] == '#' -> Tok.COMMENT
                    v[0] == '"' || v[0] == '\'' -> Tok.STRING
                    v[0].isDigit() -> Tok.NUMBER
                    v[0] == '@' -> Tok.TYPE
                    v in pyKw -> Tok.KEYWORD
                    v[0].isUpperCase() -> Tok.TYPE
                    else -> null
                }
                if (tok != null) out.add(Hl(m.range.first, m.range.last + 1, tok))
            }
        }
        "json" -> {
            for (m in jsonRe.findAll(text)) {
                val v = m.value
                val tok: Tok = when {
                    v[0] == '"' -> {
                        var k = m.range.last + 1
                        while (k < text.length && (text[k] == ' ' || text[k] == '\t')) k++
                        if (k < text.length && text[k] == ':') Tok.ATTR else Tok.STRING
                    }
                    v[0].isDigit() || v[0] == '-' -> Tok.NUMBER
                    else -> Tok.KEYWORD
                }
                out.add(Hl(m.range.first, m.range.last + 1, tok))
            }
        }
        "html", "xml" -> {
            for (m in markupRe.findAll(text)) {
                val v = m.value
                val tok: Tok = when {
                    v.startsWith("<!--") -> Tok.COMMENT
                    v[0] == '"' || v[0] == '\'' -> Tok.STRING
                    v[0] == '<' || v[0] == '/' || v[0] == '>' -> Tok.TAG
                    else -> Tok.ATTR
                }
                out.add(Hl(m.range.first, m.range.last + 1, tok))
            }
        }
        "css" -> {
            for (m in cssRe.findAll(text)) {
                val v = m.value
                val tok: Tok = when {
                    v.startsWith("/*") -> Tok.COMMENT
                    v[0] == '"' || v[0] == '\'' -> Tok.STRING
                    v[0] == '#' && v.length > 1 && v.substring(1).all { it.isLetterOrDigit() && it.lowercaseChar() in "0123456789abcdef" } -> Tok.NUMBER
                    v[0].isDigit() || v[0] == '-' && v.length > 1 && v[1].isDigit() -> Tok.NUMBER
                    v[0] == '@' -> Tok.KEYWORD
                    v[0] == '.' || v[0] == '#' -> Tok.TAG
                    else -> Tok.ATTR
                }
                out.add(Hl(m.range.first, m.range.last + 1, tok))
            }
        }
        "markdown" -> {
            for (m in mdRe.findAll(text)) {
                val v = m.value
                val tok: Tok = when {
                    v.startsWith("#") -> Tok.KEYWORD
                    v.startsWith("**") -> Tok.TYPE
                    v.startsWith("`") -> Tok.STRING
                    v.startsWith("[") -> Tok.TAG
                    else -> Tok.NUMBER
                }
                out.add(Hl(m.range.first, m.range.last + 1, tok))
            }
        }
    }
    return out
}

class CodeTransformation(
    private val lang: String,
    private val colors: CodeColors,
    private val red: Boolean,
    private val redColor: Color,
    private val query: String,
    private val matchBg: Color
) : VisualTransformation {
    private var lastText: String? = null
    private var lastResult: TransformedText? = null

    override fun filter(text: AnnotatedString): TransformedText {
        val s = text.text
        val cached = lastResult
        if (cached != null && lastText == s) return cached
        val out = build(s)
        lastText = s
        lastResult = out
        return out
    }

    private fun build(s: String): TransformedText {
        // very large files stay plain: highlighting is O(n) on every keystroke
        if (s.length > 120_000) {
            return TransformedText(AnnotatedString(s), OffsetMapping.Identity)
        }
        val b = AnnotatedString.Builder(s)
        for (h in highlight(s, lang)) {
            val c = when (h.tok) {
                Tok.KEYWORD -> colors.keyword
                Tok.STRING -> colors.string
                Tok.COMMENT -> colors.comment
                Tok.NUMBER -> colors.number
                Tok.TYPE -> colors.type
                Tok.TAG -> colors.tag
                Tok.ATTR -> colors.attr
            }
            b.addStyle(SpanStyle(color = c), h.start, h.end)
        }
        if (query.isNotEmpty()) {
            for (idx in findAllIndices(s, query)) {
                b.addStyle(SpanStyle(background = matchBg), idx, idx + query.length)
            }
        }
        if (red) {
            for (i in s.indices) {
                if (s[i] == '1') b.addStyle(SpanStyle(color = redColor), i, i + 1)
            }
        }
        return TransformedText(b.toAnnotatedString(), OffsetMapping.Identity)
    }
}

fun findAllIndices(text: String, query: String): List<Int> {
    if (query.isEmpty()) return emptyList()
    val out = ArrayList<Int>()
    var i = text.indexOf(query, 0, ignoreCase = true)
    while (i >= 0 && out.size < 5000) {
        out.add(i)
        i = text.indexOf(query, i + query.length, ignoreCase = true)
    }
    return out
}
