package app.morrow

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.io.File

@Composable
fun NotificationPermissionCard(modifier: Modifier = Modifier) {
    if (Build.VERSION.SDK_INT < 33) return
    val ctx = LocalContext.current
    var granted by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) ==
                PackageManager.PERMISSION_GRANTED
        )
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
    if (granted) return
    MCard(modifier) {
        Text(
            "Уведомления выключены",
            color = MaterialTheme.colorScheme.onSurface,
            style = AppStyle(fontSize = 16.sp, fontWeight = FontWeight.Medium)
        )
        Spacer(Modifier.height(4.dp))
        Hint("Без них не придут напоминания о событиях и экран будильника может не показаться поверх блокировки.")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TextButton(onClick = { launcher.launch(Manifest.permission.POST_NOTIFICATIONS) }) { Text("Разрешить") }
            TextButton(onClick = {
                val i = Intent(android.provider.Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                    .putExtra(android.provider.Settings.EXTRA_APP_PACKAGE, ctx.packageName)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                try {
                    ctx.startActivity(i)
                } catch (_: Exception) {
                }
            }) { Text("Настройки") }
        }
    }
}

private fun readText(ctx: Context, uri: Uri): String? = try {
    ctx.contentResolver.openInputStream(uri)?.use { String(it.readBytes(), Charsets.UTF_8) }
} catch (_: Exception) {
    null
}

private fun writeText(ctx: Context, uri: Uri, text: String): Boolean = try {
    ctx.contentResolver.openOutputStream(uri)?.use { it.write(text.toByteArray(Charsets.UTF_8)) }
    true
} catch (_: Exception) {
    false
}

private fun notesMarkdown(): String {
    val sb = StringBuilder()
    sb.append("# Morrow — заметки\n\n")
    val list = Repo.notes.filter { it.trashedAt == 0L }.sortedByDescending { it.modified }
    for (n in list) {
        sb.append("## ").append(n.title.ifBlank { "Без названия" }).append("\n\n")
        val cat = Repo.categoryById(n.categoryId)
        sb.append("*")
        if (cat != null) sb.append(cat.name).append(" · ")
        sb.append("изменено ").append(fmtStamp(n.modified)).append("*\n\n")
        sb.append(n.body.trimEnd()).append("\n\n---\n\n")
    }
    return sb.toString()
}

private fun countsOf(o: JSONObject): String {
    val parts = ArrayList<String>()
    o.optJSONArray("events")?.let { parts.add("событий: ${it.length()}") }
    o.optJSONArray("notes")?.let { parts.add("заметок: ${it.length()}") }
    o.optJSONArray("alarms")?.let { parts.add("будильников: ${it.length()}") }
    o.optJSONArray("code")?.let { parts.add("файлов кода: ${it.length()}") }
    if (o.has("settings")) parts.add("настройки")
    return if (parts.isEmpty()) "ничего" else parts.joinToString(", ")
}

@Composable
fun SettingsScreen(onClose: () -> Unit) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme

    var pendingText by remember { mutableStateOf<String?>(null) }
    var pendingRestore by remember { mutableStateOf<JSONObject?>(null) }
    var pendingSnapshot by remember { mutableStateOf<File?>(null) }

    val jsonSaver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        val t = pendingText
        if (uri != null && t != null) {
            ctx.toast(if (writeText(ctx, uri, t)) "Файл сохранён" else "Не удалось сохранить файл")
        }
        pendingText = null
    }
    val mdSaver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/markdown")) { uri ->
        val t = pendingText
        if (uri != null && t != null) {
            ctx.toast(if (writeText(ctx, uri, t)) "Файл сохранён" else "Не удалось сохранить файл")
        }
        pendingText = null
    }
    val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val text = readText(ctx, uri)
            try {
                val o = JSONObject(text ?: "")
                if (o.optString("type") != "morrow-backup") {
                    ctx.toast("Это не файл Morrow")
                } else {
                    pendingRestore = o
                }
            } catch (_: Exception) {
                ctx.toast("Не удалось прочитать файл")
            }
        }
    }

    fun stamp(): String = java.time.LocalDate.now().toString()
    fun exportJson(name: String, o: JSONObject) {
        Repo.saveNow()
        pendingText = o.toString(2)
        jsonSaver.launch(name)
    }

    val exactOk = Scheduler.canScheduleExact(ctx)
    val version = try {
        ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: "1.0"
    } catch (_: Exception) {
        "1.0"
    }

    EditorFrame {
        TopBarRow("Настройки", onClose)
        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            MCard {
                SmallLabel("Внешний вид")
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Red One — красная цифра 1", Modifier.weight(1f), color = cs.onSurface)
                    Switch(checked = Prefs.redOne, onCheckedChange = { Prefs.updateRedOne(it) })
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(onClick = {
                        Nav.tab = "Themes"
                        Nav.home()
                    }) { Text("Темы и цвета") }
                    TextButton(onClick = { Prefs.resetToday() }) { Text("Сбросить экран Today") }
                }
            }

            MCard {
                SmallLabel("Надёжность будильников и напоминаний")
                Spacer(Modifier.height(8.dp))
                Hint(
                    "Будильники ставятся системным будильником и переживают перезагрузку, смену часового пояса " +
                        "и перевод часов. На OnePlus ещё стоит выключить оптимизацию батареи для Morrow."
                )
                Spacer(Modifier.height(4.dp))
                if (!exactOk) {
                    Text("Точные напоминания не разрешены", color = cs.error)
                    TextButton(onClick = {
                        try {
                            ctx.startActivity(
                                Intent(android.provider.Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)
                                    .setData(Uri.parse("package:" + ctx.packageName))
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            )
                        } catch (_: Exception) {
                        }
                    }) { Text("Разрешить точные напоминания") }
                } else {
                    Text("Точные напоминания разрешены", color = cs.primary)
                }
                TextButton(onClick = {
                    try {
                        ctx.startActivity(
                            Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    } catch (_: Exception) {
                    }
                }) { Text("Оптимизация батареи") }
                NotificationPermissionCard()
            }

            MCard {
                SmallLabel("Данные и резервные копии")
                Spacer(Modifier.height(8.dp))
                Hint("Все данные хранятся только на телефоне. Копия создаётся автоматически раз в день, последние 7 сохраняются.")
                Spacer(Modifier.height(8.dp))
                FilledTonalButton(
                    onClick = { exportJson("morrow-backup-" + stamp() + ".json", Repo.toJson(all = true)) },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Полная резервная копия (JSON)") }
                OutlinedButton(
                    onClick = { exportJson("morrow-events-" + stamp() + ".json", Repo.toJson(all = true, sections = setOf("events"))) },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Экспорт событий (JSON)") }
                OutlinedButton(
                    onClick = { exportJson("morrow-notes-" + stamp() + ".json", Repo.toJson(all = true, sections = setOf("notes"))) },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Экспорт заметок (JSON)") }
                OutlinedButton(
                    onClick = {
                        pendingText = notesMarkdown()
                        mdSaver.launch("morrow-notes-" + stamp() + ".md")
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Экспорт заметок (Markdown)") }
                OutlinedButton(
                    onClick = { exportJson("morrow-settings-" + stamp() + ".json", Repo.toJson(all = true, sections = setOf("settings"))) },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Экспорт настроек (JSON)") }
                Spacer(Modifier.height(4.dp))
                Button(
                    onClick = { importer.launch(arrayOf("application/json", "text/plain", "*/*")) },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Восстановить из файла…") }
                Hint("Чтобы перенести данные на другой телефон: сохраните полную копию, передайте файл и восстановите его там.")

                val snaps = remember { Repo.snapshots() }
                if (snaps.isNotEmpty()) {
                    Spacer(Modifier.height(10.dp))
                    SmallLabel("Автоматические копии")
                    for (f in snaps) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                f.name.removePrefix("morrow-").removeSuffix(".json"),
                                Modifier.weight(1f),
                                color = cs.onSurface
                            )
                            TextButton(onClick = { pendingSnapshot = f }) { Text("Восстановить") }
                        }
                    }
                }
            }

            AboutCard()
            Spacer(Modifier.height(24.dp))
        }
    }

    val restoreObj = pendingRestore
    if (restoreObj != null) {
        ConfirmDialog(
            title = "Восстановить данные?",
            text = "В файле: " + countsOf(restoreObj) + ". Эти разделы заменят текущие данные на телефоне.",
            confirmLabel = "Восстановить",
            onConfirm = {
                pendingRestore = null
                try {
                    ctx.toast(Repo.restore(restoreObj))
                } catch (_: Exception) {
                    ctx.toast("Не удалось восстановить данные")
                }
            },
            onDismiss = { pendingRestore = null }
        )
    }
    val snap = pendingSnapshot
    if (snap != null) {
        ConfirmDialog(
            title = "Восстановить копию?",
            text = "Данные на телефоне будут заменены копией от " +
                snap.name.removePrefix("morrow-").removeSuffix(".json") + ".",
            confirmLabel = "Восстановить",
            onConfirm = {
                pendingSnapshot = null
                try {
                    ctx.toast(Repo.restore(JSONObject(snap.readText())))
                } catch (_: Exception) {
                    ctx.toast("Не удалось восстановить копию")
                }
            },
            onDismiss = { pendingSnapshot = null }
        )
    }
}
